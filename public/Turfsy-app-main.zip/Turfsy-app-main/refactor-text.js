const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) { 
      results = results.concat(walk(file));
    } else { 
      if (file.endsWith('.tsx') || file.endsWith('.ts') || file.endsWith('.jsx') || file.endsWith('.js')) results.push(file);
    }
  });
  return results;
}

const files = [...walk('app'), ...walk('src')];
files.forEach(file => {
  if (file.includes('AppText.tsx')) return;
  if (file.includes('themed-text.tsx')) return; // already handles its own logic or we can skip it
  
  let content = fs.readFileSync(file, 'utf8');
  let changed = false;
  
  const importRegex = /import\s+({[^}]*?})\s+from\s+['"]react-native['"]/g;
  
  content = content.replace(importRegex, (match, p1) => {
    const imports = p1.replace(/[{}]/g, '').split(',').map(s => s.trim()).filter(Boolean);
    
    const textIndex = imports.indexOf('Text');
    if (textIndex !== -1) {
      changed = true;
      imports.splice(textIndex, 1);
      
      let newStr = '';
      if (imports.length > 0) {
        newStr = `import { ${imports.join(', ')} } from 'react-native';\n`;
      }
      newStr += `import { AppText as Text } from '@/src/components/AppText';`;
      return newStr;
    }
    return match;
  });
  
  if (changed) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${file}`);
  }
});
