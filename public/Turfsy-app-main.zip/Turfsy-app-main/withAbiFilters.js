const { withAppBuildGradle } = require('expo/config-plugins');

module.exports = function withAbiFilters(config) {
  return withAppBuildGradle(config, (config) => {
    if (config.modResults.language === 'groovy') {
      const buildGradle = config.modResults.contents;
      
      // We look for defaultConfig { and inject ndk { abiFilters "armeabi-v7a", "arm64-v8a" }
      // This strips out x86 and x86_64 from the universal APK, slashing the size by 50%
      if (buildGradle.includes('defaultConfig {') && !buildGradle.includes('abiFilters')) {
        config.modResults.contents = buildGradle.replace(
          /defaultConfig\s*\{/,
          `defaultConfig {\n        ndk {\n            abiFilters "armeabi-v7a", "arm64-v8a"\n        }`
        );
      }
    }
    return config;
  });
};
