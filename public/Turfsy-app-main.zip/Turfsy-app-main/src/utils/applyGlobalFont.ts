import React from 'react';
import { TextInput, StyleSheet } from 'react-native';

export const applyGlobalFont = () => {
  const getFontFamily = (style: any) => {
    let fontWeight = '400';
    
    if (style && style.fontWeight) {
      fontWeight = style.fontWeight.toString();
    }
    
    // Some common maps
    if (fontWeight === 'bold' || fontWeight === '700') return 'Inter-Bold';
    if (fontWeight === 'normal' || fontWeight === '400') return 'Inter';
    if (fontWeight === '100') return 'Inter-Thin';
    if (fontWeight === '200') return 'Inter-ExtraLight';
    if (fontWeight === '300') return 'Inter-Light';
    if (fontWeight === '500') return 'Inter-Medium';
    if (fontWeight === '600') return 'Inter-SemiBold';
    if (fontWeight === '800') return 'Inter-ExtraBold';
    if (fontWeight === '900') return 'Inter-Black';
    
    return 'Inter';
  };

  const processStyle = (style: any) => {
    if (!style) return { fontFamily: 'Inter' };
    
    const flattenedStyle = StyleSheet.flatten(style) || {};
    const fontFamily = getFontFamily(flattenedStyle);
    
    // We remove fontWeight and fontStyle to prevent Android from trying to synthesize them
    // and causing it to drop our custom font family.
    const { fontWeight, fontStyle, ...restStyle } = flattenedStyle;
    
    return { ...restStyle, fontFamily };
  };


  const TextInputAny = TextInput as any;
  if (TextInputAny.render) {
    const oldTextInputRender = TextInputAny.render;
    TextInputAny.render = function (...args: any) {
      const origin = oldTextInputRender.call(this, ...args);
      return React.cloneElement(origin, {
        style: processStyle(origin.props.style),
      });
    };
  } else if (TextInputAny.defaultProps != null) {
    TextInputAny.defaultProps.style = {
      ...(TextInputAny.defaultProps.style || {}),
      fontFamily: 'Inter',
    };
  }
};
