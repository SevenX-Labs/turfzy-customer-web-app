/**
 * location.ts — Production-grade location utility for Turfsy
 *
 * Strategy:
 *  1. Ensure device location services are ON (prompt on Android).
 *  2. Request foreground permission.
 *  3. Take up to 3 GPS samples with BestForNavigation accuracy.
 *     - Discard samples worse than 50m accuracy (noisy fix).
 *     - Pick the sample with the best (lowest) accuracy figure.
 *  4. Reverse-geocode with Nominatim (OpenStreetMap) — free, no API key.
 *     - Retry once on network failure.
 *     - Fall back to expo-location's reverseGeocodeAsync if Nominatim fails.
 *  5. Build structured address fields:
 *       street     → house/building name + road
 *       area       → neighbourhood / suburb / district
 *       city       → city / town / village
 *       state      → state / province
 *       country    → country
 *       pincode    → postal/zip code
 *       displayLine1 → "Area, City"
 *       displayLine2 → "State, Country – Pincode"
 *       latLng       → "12.345678, 77.123456" (6dp)
 */

import { Alert, Platform } from 'react-native';
import * as Location from 'expo-location';

// ─── Public types ────────────────────────────────────────────────────────────

export type LocationAddress = {
  street: string;      // building / flat + road name
  area: string;        // neighbourhood / locality
  city: string;        // city / town / village
  state: string;       // state / province / region
  country: string;     // country full name
  pincode: string;     // postal / zip code
  displayLine1: string; // e.g. "Andheri West, Mumbai"
  displayLine2: string; // e.g. "Maharashtra, India – 400053"
  latLng: string;       // e.g. "19.119832, 72.846211"
};

export type PreciseLocationResult = {
  address: LocationAddress;
  coords: {
    lat: number;
    lng: number;
    accuracy: number | null; // metres — lower is better
  };
};

// ─── Internal helpers ────────────────────────────────────────────────────────

const wait = (ms: number) => new Promise<void>((res) => setTimeout(res, ms));

const clean = (v: string | null | undefined): string =>
  (v ?? '').replace(/\s+/g, ' ').trim();

/** Returns true when the string looks like a useless raw value
 *  (pure numbers, unnamed road, empty, etc.) */
const isJunk = (v: string): boolean => {
  if (!v) return true;
  const l = v.toLowerCase();
  return (
    /^\d+$/.test(v) ||
    l.includes('unnamed') ||
    l === 'null' ||
    v.length < 2
  );
};

const first = (...candidates: (string | null | undefined)[]): string => {
  for (const c of candidates) {
    const s = clean(c);
    if (s && !isJunk(s)) return s;
  }
  return '';
};

// ─── Nominatim types ─────────────────────────────────────────────────────────

type NominatimAddress = {
  house_number?: string;
  road?: string;
  building?: string;
  neighbourhood?: string;
  suburb?: string;
  quarter?: string;
  city_district?: string;
  residential?: string;
  hamlet?: string;
  village?: string;
  town?: string;
  city?: string;
  county?: string;
  state_district?: string;
  state?: string;
  postcode?: string;
  country?: string;
};

type NominatimResponse = {
  address?: NominatimAddress;
  name?: string;
  display_name?: string;
  error?: string;
};

// ─── Step 1 & 2: Permissions / services ──────────────────────────────────────

async function ensureServicesEnabled(): Promise<boolean> {
  if (Platform.OS === 'android') {
    try { await Location.enableNetworkProviderAsync(); } catch { /* user dismissed */ }
  }
  const enabled = await Location.hasServicesEnabledAsync();
  if (!enabled) {
    Alert.alert(
      'Location Services Off',
      'Please enable GPS / Location Services on your device to auto-detect your address.',
      [{ text: 'OK' }]
    );
    return false;
  }
  return true;
}

async function ensurePermission(): Promise<boolean> {
  const { status } = await Location.requestForegroundPermissionsAsync();
  if (status !== 'granted') {
    Alert.alert(
      'Permission Required',
      'Location permission is needed to fill your address automatically.',
      [{ text: 'OK' }]
    );
    return false;
  }
  return true;
}

// ─── Step 3: GPS sampling ─────────────────────────────────────────────────────

const GPS_SAMPLES    = 3;
const SAMPLE_GAP_MS  = 1200;    // gap between samples
const MIN_ACCURACY_M = 50;      // reject fixes coarser than 50 m

async function getBestGpsFix(): Promise<Location.LocationObject> {
  const fixes: Location.LocationObject[] = [];

  for (let i = 0; i < GPS_SAMPLES; i++) {
    if (i > 0) await wait(SAMPLE_GAP_MS);
    try {
      const fix = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.BestForNavigation,
        mayShowUserSettingsDialog: true,
      });
      fixes.push(fix);
    } catch { /* skip this sample */ }
  }

  if (fixes.length === 0) {
    // Last resort: single low-accuracy fix
    return Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.Balanced,
    });
  }

  // Filter out clearly noisy fixes
  const good = fixes.filter(
    (f) => (f.coords.accuracy ?? 9999) <= MIN_ACCURACY_M
  );
  const pool = good.length > 0 ? good : fixes;

  // Pick the best accuracy
  return pool.reduce((best, cur) =>
    (cur.coords.accuracy ?? 9999) < (best.coords.accuracy ?? 9999) ? cur : best
  );
}

// ─── Step 4: Reverse geocoding ────────────────────────────────────────────────

async function nominatimReverse(lat: number, lng: number): Promise<NominatimResponse | null> {
  const url =
    `https://nominatim.openstreetmap.org/reverse` +
    `?format=jsonv2&addressdetails=1&zoom=18` +
    `&lat=${lat}&lon=${lng}`;

  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const res = await fetch(url, {
        headers: {
          'Accept-Language': 'en-IN,en;q=0.9',
          'User-Agent': 'TurfsyApp/1.0',
        },
        signal: AbortSignal.timeout(6000),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as NominatimResponse;
      if (data.error) return null;
      return data;
    } catch {
      if (attempt < 2) await wait(1000);
    }
  }
  return null;
}

// ─── Step 5: Build structured address ────────────────────────────────────────

function buildFromNominatim(
  addr: NominatimAddress,
  fallbackName?: string
): Omit<LocationAddress, 'latLng'> {
  const houseNo = clean(addr.house_number);
  const road    = clean(addr.road);
  const street  = [houseNo, road].filter(Boolean).join(', ') || clean(addr.building) || '';

  const area = first(
    addr.neighbourhood,
    addr.suburb,
    addr.quarter,
    addr.city_district,
    addr.residential,
    addr.hamlet,
    fallbackName
  );

  const city = first(
    addr.city,
    addr.town,
    addr.village,
    addr.county,
    addr.state_district
  );

  const state   = clean(addr.state);
  const country = clean(addr.country);
  const pincode = clean(addr.postcode);

  const displayLine1 = [area, city].filter(Boolean).join(', ') || city || area || 'Current Location';
  const displayLine2Parts: string[] = [state, country].filter(Boolean);
  const displayLine2 = displayLine2Parts.join(', ') + (pincode ? ` – ${pincode}` : '');

  return { street, area, city, state, country, pincode, displayLine1, displayLine2 };
}

function buildFromExpo(
  info: Location.LocationGeocodedAddress
): Omit<LocationAddress, 'latLng'> {
  const houseNo = clean(info.streetNumber);
  const road    = clean(info.street);
  const street  = [houseNo, road].filter(Boolean).join(', ');

  const area    = first(info.district, info.name);
  const city    = first(info.city, info.subregion);
  const state   = clean(info.region);
  const country = clean(info.country);
  const pincode = clean(info.postalCode);

  const displayLine1 = [area, city].filter(Boolean).join(', ') || 'Current Location';
  const displayLine2Parts: string[] = [state, country].filter(Boolean);
  const displayLine2 = displayLine2Parts.join(', ') + (pincode ? ` – ${pincode}` : '');

  return { street, area, city, state, country, pincode, displayLine1, displayLine2 };
}

async function reverseGeocode(lat: number, lng: number): Promise<Omit<LocationAddress, 'latLng'>> {
  // Try Nominatim first (richer neighbourhood/area data)
  const nominatim = await nominatimReverse(lat, lng);
  if (nominatim?.address) {
    return buildFromNominatim(nominatim.address, nominatim.name);
  }

  // Fallback: expo-location built-in
  try {
    const results = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lng });
    if (results?.[0]) return buildFromExpo(results[0]);
  } catch { /* ignore */ }

  // Last resort: raw coords
  return {
    street: '',
    area: '',
    city: `${lat.toFixed(5)}, ${lng.toFixed(5)}`,
    state: '',
    country: '',
    pincode: '',
    displayLine1: `${lat.toFixed(5)}, ${lng.toFixed(5)}`,
    displayLine2: 'Location detected',
  };
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Single entry point.
 * Returns a fully structured address with accurate GPS coords,
 * or null if permissions / services are unavailable.
 */
export async function getPreciseUserLocation(): Promise<PreciseLocationResult | null> {
  try {
    if (!(await ensureServicesEnabled())) return null;
    if (!(await ensurePermission()))      return null;

    const fix = await getBestGpsFix();
    const { latitude: lat, longitude: lng, accuracy } = fix.coords;

    const partial = await reverseGeocode(lat, lng);

    const address: LocationAddress = {
      ...partial,
      latLng: `${lat.toFixed(6)}, ${lng.toFixed(6)}`,
    };

    return {
      address,
      coords: { lat, lng, accuracy: accuracy ?? null },
    };
  } catch (err) {
    console.error('[Location] Critical failure:', err);
    Alert.alert(
      'Location Error',
      'Could not detect your location. Please check GPS settings and try again.'
    );
    return null;
  }
}
