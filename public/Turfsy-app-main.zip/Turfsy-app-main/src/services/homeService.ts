import { apiClient } from '../api/apiClient';

export interface TurfCard {
  id: string;
  name: string;
  city: string;
  address: string;
  distanceKm: number | null;
  rating: number;
  reviewCount: number;
  sportsType: string;
  turfSize: string;
  status: string;
  openTime: string;
  closeTime: string;
  weekdayDayPrice: number;
  weekdayNightPrice: number;
  weekendDayPrice: number;
  weekendNightPrice: number;
  floodLights: boolean;
  parking: boolean;
  washroom: boolean;
  changingRoom: boolean;
  drinkingWater: boolean;
  seatingArea: boolean;
  cafeteria: boolean;
  images: string[];
  image?: string;
  entranceUrl?: string;
  groundDayUrl?: string;
  groundNightUrl?: string;
  description: string;
  rules?: string[];
  customerReviews?: {
    reviewerName: string;
    rating: number;
    comment: string;
  }[];
  owner: {
    name: string;
    contactNumber: string;
  };
  videoUrl?: string;
  createdAt: string;
}

export interface HomeSection {
  sectionType: string;
  title: string;
  subtitle?: string;
  turfs: TurfCard[];
}

export interface HomeResponse {
  success: boolean;
  userCity: string | null;
  sections: HomeSection[];
}


export const HomeService = {
  /**
   * Fetch main dashboard data.
   * Can optionally filter by location to get more accurate 'Nearby' sections.
   */
  getHomeData: async (params?: { 
    lat?: number; 
    lng?: number; 
    city?: string; 
    radiusKm?: number; 
    refresh?: boolean;
  }): Promise<HomeResponse> => {
    return apiClient.get('/api/v3/user-home', { params });
  },


  /**
   * Fetch specific home section
   */
  getSectionData: async (section: string): Promise<{ success: boolean; userCity: string | null; section: HomeSection }> => {
    return apiClient.get(`/api/v3/user-home/${section}`);
  }
};
