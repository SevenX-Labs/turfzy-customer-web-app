import { apiClient } from '../api/apiClient';

/**
 * USER SETTINGS SERVICE
 * 
 * Target Contract for /api/v3/user-settings/*
 */

export interface PaymentSettings {
  upiId: string | null;
  defaultPaymentMethod: 'UPI' | 'NET_BANKING' | 'CARD';
}

export interface UserPreferences {
  notificationsEnabled: boolean;
  preferredTime: 'MORNING' | 'AFTERNOON' | 'EVENING' | 'NIGHT';
  favoriteSport: 'FOOTBALL' | 'CRICKET' | 'TENNIS' | 'BASKETBALL';
  favoriteTurfIds: string[];
}

export interface NotificationSettings {
  bookingAlerts: boolean;
  offerAlerts: boolean;
  reminderAlerts: boolean;
}

export const UserSettingsService = {
  // Payment Settings
  getPaymentSettings: async (): Promise<{ success: boolean; data: PaymentSettings }> => {
    return apiClient.get('/api/v3/user-settings/payment');
  },

  updatePaymentSettings: async (dto: Partial<PaymentSettings>): Promise<{ success: boolean; data: PaymentSettings; message: string }> => {
    return apiClient.patch('/api/v3/user-settings/payment', dto);
  },

  // Security (Phone Change)
  requestPhoneChange: async (newPhone: string): Promise<{ success: boolean; data: { sessionToken: string }; message: string }> => {
    return apiClient.post('/api/v3/user-settings/change-phone', { newPhone });
  },

  verifyPhoneChange: async (data: { newPhone: string; otp: string; sessionToken: string }): Promise<{ success: boolean; data: { phone: string }; message: string }> => {
    return apiClient.post('/api/v3/user-settings/change-phone', data);
  },

  // Preferences
  getPreferences: async (): Promise<{ success: boolean; data: UserPreferences }> => {
    return apiClient.get('/api/v3/user-settings/preferences');
  },

  updatePreferences: async (dto: Partial<UserPreferences>): Promise<{ success: boolean; data: UserPreferences; message: string }> => {
    return apiClient.patch('/api/v3/user-settings/preferences', dto);
  },

  // Notification Settings
  getNotificationSettings: async (): Promise<{ success: boolean; data: NotificationSettings }> => {
    return apiClient.get('/api/v3/user-settings/notifications');
  },

  updateNotificationSettings: async (dto: Partial<NotificationSettings>): Promise<{ success: boolean; data: NotificationSettings; message: string }> => {
    return apiClient.patch('/api/v3/user-settings/notifications', dto);
  }
};
