import { apiClient } from '../api/apiClient';

/**
 * USER SERVICE
 * 
 * Handles all profile, location, and user-specific settings.
 * Maps directly to the /api/v3/user-profile NestJS endpoints.
 */

export interface CreateProfileDto {
  username: string;
  name: string;
  email: string;
  dob: string; // ISO string
  gender: 'MALE' | 'FEMALE' | 'OTHER' | 'PREFER_NOT_TO_SAY';
  preferredSport?: 'FOOTBALL' | 'CRICKET';
  currentLat?: number;
  currentLng?: number;
  // New unified address fields
  city?: string;
  state?: string;
  pincode?: string;
  expoPushToken?: string;
}

export interface UpdateHomeAddressDto {
  houseNumber?: string;
  societyName?: string;
  landmark?: string;
  roadName?: string;
  city?: string;
  state?: string;
  pincode?: string;
}

export interface UserProfile {
  id: string;
  authId: string;
  username: string;
  name: string;
  email: string;
  dob: string;
  gender: string;
  avatarUrl: string | null;
  preferredSport: string | null;
  // GPS-based location
  currentLat?: number | null;
  currentLng?: number | null;
  city?: string | null;
  state?: string | null;
  pincode?: string | null;
  // Manually entered home address (backend auto-joins into single string)
  address?: string | null;
  payment?: {
    upiId: string;
  } | null;
}

export interface ProfileResponse {
  success: boolean;
  message?: string;
  data: UserProfile;
}

export const UserService = {
  /**
   * Check if a username is available for registration
   * GET /api/v3/user-profile/check-availability
   */
  checkUsername: async (username: string): Promise<{ available: boolean; message: string }> => {
    return apiClient.get('/api/v3/user-profile/check-availability', { params: { username } });
  },

  /**
   * Create new profile (usually called after first-time OTP verification)
   */
  createProfile: async (dto: CreateProfileDto): Promise<ProfileResponse> => {
    return apiClient.post('/api/v3/user-profile', dto);
  },

  /**
   * Get current user's profile and payment details
   */
  getProfile: async (): Promise<ProfileResponse> => {
    return apiClient.get('/api/v3/user-profile');
  },

  /**
   * Update profile fields (name, email, city, etc.)
   */
  updateProfile: async (dto: Partial<CreateProfileDto>): Promise<ProfileResponse> => {
    return apiClient.patch('/api/v3/user-profile', dto);
  },

  /**
   * Add/Update home address details (house no, society, landmark, road).
   * Backend auto-joins them into a single `address` string.
   * PATCH /api/v3/user-profile/address
   */
  updateHomeAddress: async (dto: UpdateHomeAddressDto): Promise<any> => {
    return apiClient.patch('/api/v3/user-profile/address', dto);
  },

  /**
   * Update user GPS coordinates and city name
   */
  updateLocation: async (lat: number, lng: number, city?: string): Promise<any> => {
    return apiClient.post('/api/v3/user-profile/location', { lat, lng, city });
  },

  /**
   * Save UPI payment details
   */
  savePaymentDetails: async (upiId: string): Promise<any> => {
    return apiClient.post('/api/v3/user-profile/payment-details', { upiId });
  },

  /**
   * Upload profile picture
   */
  uploadAvatar: async (formData: FormData): Promise<any> => {
    return apiClient.post('/api/v3/user-profile/upload-avatar', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },

  /**
   * Delete profile picture
   */
  deleteAvatar: async (): Promise<any> => {
    return apiClient.delete('/api/v3/user-profile/upload-avatar');
  }
};
