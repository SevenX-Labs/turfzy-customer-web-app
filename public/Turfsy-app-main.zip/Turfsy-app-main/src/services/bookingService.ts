import { apiClient } from '../api/apiClient';
import { Booking, PaymentType } from '../types/booking.types';

export interface AvailabilityResponse {
  success: boolean;
  data: {
    openTime: string;
    closeTime: string;
    minBookableTime?: string;
    bookedSlots: { startTime: string; endTime: string; isExpired?: boolean }[];
    pricing: {
      dayPrice: number;
      nightPrice: number;
      nightStartsAt: string;
      isWeekend: boolean;
    };
  };
}

export const BookingService = {
  /**
   * 1. Get Turf Availability (Booked Slots)
   * GET /api/v3/booking/availability/:turfId?date=2026-04-05
   */
  getAvailability: async (turfId: string, date: string): Promise<AvailabilityResponse> => {
    return apiClient.get(`/api/v3/booking/availability/${turfId}`, { params: { date } });
  },

  /**
   * 2. Create Booking
   * POST /api/v3/booking
   */
  createBooking: async (data: {
    turfId: string;
    bookingDate: string;
    startTime: string;
    endTime: string;
    durationMins: number;
    paymentType: PaymentType;
    notes?: string;
    playersCount?: number;
  }): Promise<{ success: boolean; data: Booking; message: string }> => {
    return apiClient.post('/api/v3/booking', data);
  },

  /**
   * 3. Quick Pay-At-Turf Booking
   * POST /api/v3/booking/pay-at-turf
   */
  quickPayAtTurf: async (data: {
    turfId: string;
    bookingDate: string;
    startTime: string;
    endTime: string;
    durationMins: number;
    notes?: string;
    playersCount?: number;
  }): Promise<{ success: boolean; data: Booking; message: string }> => {
    return apiClient.post('/api/v3/booking/pay-at-turf', data);
  },

  /**
   * 4. Rebook Past Booking
   * POST /api/v3/booking/:bookingId/rebook
   */
  rebook: async (bookingId: string, data: {
    bookingDate?: string;
    startTime?: string;
    paymentType?: PaymentType;
  }): Promise<{ success: boolean; data: Booking; message: string }> => {
    return apiClient.post(`/api/v3/booking/${bookingId}/rebook`, data);
  },

  createRazorpayOrder: async (bookingId: string): Promise<{
    success: boolean;
    data: {
      orderId: string;
      amount: number;
      currency: string;
      keyId: string;
      bookingId: string;
      displayId: string;
    };
  }> => {
    return apiClient.post(`/api/v3/booking/${bookingId}/create-order`);
  },

  /**
   * 6. Mark Payment Failed
   * POST /api/v3/booking/:bookingId/payment-failed
   */
  failOnlinePayment: async (bookingId: string): Promise<{ success: boolean; data: Partial<Booking>; message: string }> => {
    return apiClient.post(`/api/v3/booking/${bookingId}/payment-failed`);
  },

  /**
   * 6. Confirm Online Payment
   * POST /api/v3/booking/:bookingId/confirm-payment
   */
  confirmPayment: async (bookingId: string, paymentData: {
    razorpayOrderId: string;
    razorpayPaymentId: string;
    razorpaySignature: string;
  }): Promise<{ success: boolean; data: Partial<Booking>; message: string }> => {
    return apiClient.post(`/api/v3/booking/${bookingId}/confirm-payment`, paymentData);
  },

  /**
   * 7. Cancel Booking
   * PATCH /api/v3/booking/:bookingId/cancel
   */
  cancelBooking: async (bookingId: string, reason: string): Promise<any> => {
    return apiClient.patch(`/api/v3/booking/${bookingId}/cancel`, { reason });
  },



  /**
   * 8. My Bookings
   * Supports base, active, and filtered bookings
   */
  getUserBookings: async (params?: { status?: string; filter?: string; date?: string }): Promise<Booking[]> => {
    let url = '/api/v3/booking/my-bookings';
    
    // Determine the correct endpoint based on provided params
    if (params?.status === 'active') {
      url = '/api/v3/booking/my-bookings/active';
    } else if (params) {
      url = '/api/v3/booking/my-bookings/bookings';
    }

    const response: any = await apiClient.get(url, { params: params?.status === 'active' ? {} : params });
    
    // Standard response flattening for arrays
    if (Array.isArray(response)) return response;
    if (response?.data && Array.isArray(response.data)) return response.data;
    if (response?.success && Array.isArray(response.data)) return response.data;
    
    // If it's a single object (like the new /active endpoint), wrap it in an array
    if (response?.data && typeof response.data === 'object' && !Array.isArray(response.data)) {
      return [response.data];
    }
    
    return [];
  },

  /**
   * Convenience method for Active Bookings (used in Dashboard)
   */
  getActiveBooking: async (): Promise<{ success: boolean; data: Booking[] }> => {
    const data = await BookingService.getUserBookings({ status: 'active' });
    return { success: true, data };
  },

  /**
   * 9. Transaction History
   * GET /api/v3/booking/transaction-history
   */
  getTransactionHistory: async (): Promise<{ success: boolean; count: number; data: any[] }> => {
    return apiClient.get('/api/v3/booking/transaction-history');
  },

  /**
   * 10. Rate Turf
   * POST /api/v3/booking/my-bookings/:bookingId/rateTurf
   */
  rateTurf: async (bookingId: string, data: { rating: number; review?: string }): Promise<any> => {
    return apiClient.post(`/api/v3/booking/my-bookings/${bookingId}/rateTurf`, data);
  },

  /**
   * 11. Get Single Booking Details
   * GET /api/v3/booking/my-bookings/:bookingId
   */
  getBookingDetails: async (bookingId: string): Promise<{ success: boolean; data: Booking }> => {
    return apiClient.get(`/api/v3/booking/my-bookings/${bookingId}`);
  },

  /**
   * 10. Invoice & Receipt
   * GET /api/v3/booking/my-bookings/:bookingId/invoice
   */
  getInvoiceJson: async (bookingId: string): Promise<{ success: boolean; data: any }> => {
    return apiClient.get(`/api/v3/booking/my-bookings/${bookingId}/invoice`);
  },

  /**
   * 10. Invoice & Receipt (PDF URL)
   * GET /api/v3/booking/my-bookings/:bookingId/invoice/pdf
   */
  getInvoicePdfUrl: (bookingId: string) => {
    const baseURL = apiClient.defaults.baseURL || '';
    return `${baseURL}/api/v3/booking/my-bookings/${bookingId}/invoice/pdf`;
  }
};
