import { apiClient } from '../api/apiClient';

export interface SplitPlayer {
  id: string;
  username: string;
  amount: number;
  status: 'PENDING' | 'PAID';
  isNotifiable: boolean;
}

export interface SplitDetails {
  id: string;
  bookingId: string;
  totalAmount: number;
  isSplitDone: boolean;
  leadUserId: string;
  players: SplitPlayer[];
}

export const SplitService = {
  /**
   * 1. Add Players to Split
   * POST /api/v3/booking/:bookingId/split/players
   */
  addPlayers: async (bookingId: string, usernames: string[]): Promise<{ success: boolean; message: string }> => {
    return apiClient.post(`/api/v3/booking/${bookingId}/split/players`, { usernames });
  },

  /**
   * 2. Remove Player from Split
   * DELETE /api/v3/booking/split/players/:playerId
   */
  removePlayer: async (playerId: string): Promise<{ success: boolean; message: string }> => {
    return apiClient.delete(`/api/v3/booking/split/players/${playerId}`);
  },

  /**
   * 3. Fetch Split Details
   * GET /api/v3/booking/:bookingId/split
   */
  getSplitDetails: async (bookingId: string): Promise<{ success: boolean; data: SplitDetails }> => {
    return apiClient.get(`/api/v3/booking/${bookingId}/split`);
  },

  /**
   * 4. Custom Split Amounts
   * PATCH /api/v3/booking/:bookingId/split/custom-amounts
   */
  setCustomAmounts: async (bookingId: string, amounts: { playerId: string; amount: number }[]): Promise<{ success: boolean; message: string }> => {
    return apiClient.patch(`/api/v3/booking/${bookingId}/split/custom-amounts`, { amounts });
  },

  /**
   * 5. Trigger/Confirm Split
   * POST /api/v3/booking/:bookingId/split/trigger
   */
  triggerSplit: async (bookingId: string): Promise<{ success: boolean; message: string }> => {
    return apiClient.post(`/api/v3/booking/${bookingId}/split/trigger`);
  },

  /**
   * 6. Mark as Paid (Settlement)
   * PATCH /api/v3/booking/split/players/:playerId/status
   */
  updatePlayerStatus: async (playerId: string, status: 'PAID' | 'PENDING'): Promise<{ success: boolean; message: string }> => {
    return apiClient.patch(`/api/v3/booking/split/players/${playerId}/status`, { status });
  },
};
