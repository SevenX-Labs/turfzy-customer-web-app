import { apiClient } from '../api/apiClient';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';

export interface InvoiceData {
  success: boolean;
  data: {
    invoiceId: string;
    bookingId: string;
    internalId: string;
    bookingDate: string;
    slot: string;
    duration: string;
    amount: number;
    depositAmount: number;
    paymentType: string;
    paymentStatus: string;
    bookingStatus: string;
    turf: {
      name: string;
      city: string;
      address: string;
      pincode: string;
      sportsType: string;
      owner?: {
        name: string;
        contactNumber: string;
        email?: string;
      };
    };
    customer: {
      name: string;
      email?: string;
      phone: string;
    };
    createdAt: string;
  };
}

export const InvoiceService = {
  /**
   * Fetches invoice details for a specific booking
   */
  getInvoiceDetails: async (bookingId: string): Promise<InvoiceData> => {
    return apiClient.get(`/api/v3/booking/my-bookings/${bookingId}/invoice`);
  },

  /**
   * Downloads the invoice PDF and allows sharing
   */
  downloadInvoicePdf: async (bookingId: string, authToken: string | null) => {
    const filename = `invoice-${bookingId}.pdf`;
    const fileUri = `${FileSystem.documentDirectory}${filename}`;
    const apiUrl = `${apiClient.defaults.baseURL}/api/v3/booking/my-bookings/${bookingId}/invoice/pdf`;

    try {
      const headers: Record<string, string> = {};
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }

      console.log('Downloading PDF from:', apiUrl);
      
      const downloadRes = await FileSystem.downloadAsync(apiUrl, fileUri, {
        headers,
      });

      if (downloadRes.status !== 200) {
        throw new Error(`Failed to download PDF: Status ${downloadRes.status}`);
      }

      console.log('Finished downloading to:', downloadRes.uri);

      // Share the file
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(downloadRes.uri, {
          mimeType: 'application/pdf',
          dialogTitle: 'Download Invoice',
          UTI: 'com.adobe.pdf',
        });
      } else {
        throw new Error('Sharing is not available on this device');
      }

      return downloadRes.uri;
    } catch (error) {
      console.error('Error downloading/sharing PDF:', error);
      throw error;
    }
  },
};
