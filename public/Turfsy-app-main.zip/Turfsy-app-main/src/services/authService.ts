import { apiClient } from '../api/apiClient';

/**
 * AUTH SERVICE
 * 
 * Provides a clean abstraction layer for all identity-related operations.
 * Maps directly to the /api/v3/auth NestJS endpoints.
 */

export interface LoginResponse {
  success: boolean;
  message: string;
  expiresIn: number;
}

export interface AuthData {
  id: string;
  phone: string;
  role: string;
}

export interface VerifyOtpResponse {
  success: boolean;
  message: string;
  accessToken: string;
  role: string;
  isNewUser: boolean;
  auth: AuthData;
}

export interface MeResponse {
  success: boolean;
  data: AuthData & {
    profile: any;
    payment: any;
  };
}

export const AuthService = {
  // USER ROLE FLOW
  login: async (phone: string): Promise<LoginResponse> => {
    return apiClient.post('/api/v3/auth/user/login', { phone });
  },

  verifyOtp: async (phone: string, otp: string): Promise<VerifyOtpResponse> => {
    return apiClient.post('/api/v3/auth/user/verify-otp', { phone, otp });
  },

  resendOtp: async (phone: string): Promise<LoginResponse> => {
    return apiClient.post('/api/v3/auth/user/resend-otp', { phone });
  },

  // SHARED ENDPOINTS (Authenticated)
  getMe: async (): Promise<MeResponse> => {
    return apiClient.get('/api/v3/auth/get-me');
  },

  logout: async (): Promise<{ success: boolean; message: string }> => {
    return apiClient.get('/api/v3/auth/logout');
  },

  deleteAccount: async (dto: { email?: string; reason?: string }): Promise<{ success: boolean; message: string }> => {
    return apiClient.delete('/api/v3/auth/delete-account', { data: dto });
  }
};
