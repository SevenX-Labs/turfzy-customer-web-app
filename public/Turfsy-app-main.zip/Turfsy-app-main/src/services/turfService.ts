import { apiClient } from '../api/apiClient';
import { TurfCard } from './homeService';

export interface SavedTurfResponse {
  success: boolean;
  message: string;
  data?: any;
}

export interface GetAllSavedTurfsResponse {
  success: boolean;
  count: number;
  data: {
    savedId: string;
    savedAt: string;
    notes?: string;
    turfDetails: TurfCard;
  }[];
}

export interface TurfSearchResponse {
  success: boolean;
  count: number;
  data: TurfCard[];
  meta?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

export interface FilterParams {
  city?: string;
  sportsType?: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy?: 'price_low' | 'price_high' | 'popular' | 'distance' | 'newest';
  userLat?: number;
  userLng?: number;
  page?: number;
  limit?: number;
}

export const TurfService = {
  /**
   * Get all active turfs catalog
   */
  getAllTurfs: async (page = 1, limit = 15): Promise<TurfSearchResponse> => {
    return apiClient.get('/api/v3/turfs', { params: { page, limit } });
  },

  /**
   * Get specific turf details
   */
  getTurfDetails: async (turfId: string): Promise<{ success: boolean; data: TurfCard; message?: string }> => {
    return apiClient.get(`/api/v3/turfs/${turfId}`);
  },

  /**
   * Search nearby turfs based on lat/lng
   */
  getNearbyTurfs: async (params: { lat: number; lng: number; radiusKm?: number; page?: number; limit?: number }): Promise<TurfSearchResponse & { radiusKm: number }> => {
    return apiClient.get('/api/v3/turfs/nearby', { params: { ...params, page: params.page || 1, limit: params.limit || 15 } });
  },

  /**
   * Basic text search for turfs
   */
  searchTurfs: async (query: string, page = 1, limit = 15): Promise<TurfSearchResponse> => {
    return apiClient.get('/api/v3/turfs/search', { params: { q: query, page, limit } });
  },

  /**
   * Advanced filtration and sorting
   */
  filterTurfs: async (params: FilterParams): Promise<TurfSearchResponse> => {
    return apiClient.get('/api/v3/turfs/filter', { params: { ...params, page: params.page || 1, limit: params.limit || 15 } });
  },

  /**
   * Save a turf to favorites
   */
  saveTurf: async (turfId: string, notes?: string): Promise<SavedTurfResponse> => {
    return apiClient.post(`/api/v3/saved-turfs/${turfId}`, { notes });
  },

  /**
   * Remove a turf from favorites
   */
  unsaveTurf: async (turfId: string): Promise<SavedTurfResponse> => {
    return apiClient.delete(`/api/v3/saved-turfs/${turfId}`);
  },

  /**
   * Get all saved turfs for the user
   */
  getSavedTurfs: async (): Promise<GetAllSavedTurfsResponse> => {
    return apiClient.get('/api/v3/saved-turfs');
  }
};
