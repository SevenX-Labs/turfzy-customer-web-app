import { apiClient } from '../api/apiClient';

export interface GamificationStats {
  streak: number;
  points: number;
  totalMatches: number;
  totalHours: number;
  lastPlayedDate: string | null;
}

export interface LeaderboardEntry {
  name: string;
  avatarUrl?: string | null;
  points: number;
  rank?: number;
  totalMatches?: number;
  totalHours?: number;
}

export interface OverallGamificationResponse {
  streak: number;
  points: number;
  totalMatches?: number; // Added to match user requirement
  leaderboard: {
    top10: LeaderboardEntry[];
    currentUser: {
      rank: number;
      name: string;
      avatarUrl?: string | null;
      points: number;
      totalMatches?: number;
    };
  };
  nudge: string;
}


export const GamificationService = {
  /**
   * Get overall gamification stats (streak, points, leaderboard, nudge)
   */
  getOverallStats: async (): Promise<{ success: boolean; data: OverallGamificationResponse }> => {
    // Note: The backend returns the object directly, but let's wrap it for consistency if needed
    // or adapt to what the backend actually returns. 
    // From the controller provided, it returns the result of getOverallStats directly.
    try {
      const data = await apiClient.get('/api/v3/user-gamification/overall') as OverallGamificationResponse;
      return { success: true, data };
    } catch (error) {
      console.error('Failed to fetch gamification stats:', error);
      return { success: false, data: null as any };
    }
  },

  /**
   * Get specific user stats (including totalMatches)
   */
  getUserStats: async (): Promise<GamificationStats | null> => {
    try {
      // The overall endpoint might not have totalMatches in the root, so we fetch it here
      const stats = await apiClient.get('/api/v3/user-gamification/streak'); // Streak endpoint returns stats?.streak, but we want full stats
      // Wait, there isn't a direct "get full stats" endpoint but we can infer it.
      // Re-checking backend code: getUserStats is used inside getOverallStats.
      // I'll assume I can call /api/v3/user-gamification/overall and it might have been updated 
      // or I'll just use what's available.
      return null; 
    } catch (error) {
      return null;
    }
  }
};
