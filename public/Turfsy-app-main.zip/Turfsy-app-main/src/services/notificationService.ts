import * as ExpoNotifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import { router } from 'expo-router';
import { apiClient } from '../api/apiClient';

const isExpoGo = Constants.appOwnership === 'expo';

/**
 * Configure how notifications are handled when the app is foregrounded
 */
try {
  ExpoNotifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
} catch (error) {
  console.warn('Failed to set notification handler:', error);
}

/**
 * Requests notification permissions and returns the Expo Push Token
 */
export async function registerForPushNotificationsAsync() {
  let token;

  if (isExpoGo) {
    console.log('Push notifications are not supported in Expo Go');
    return null;
  }

  if (Platform.OS === 'android') {
    await ExpoNotifications.setNotificationChannelAsync('default', {
      name: 'Default Notification Channel',
      importance: ExpoNotifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF231F7C',
    });
  }

  if (Device.isDevice) {
    const { status: existingStatus } = await ExpoNotifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await ExpoNotifications.requestPermissionsAsync();
      finalStatus = status;
    }
    
    if (finalStatus !== 'granted') {
      console.warn('Failed to get push token for push notification!');
      return null;
    }
    
    try {
      const projectId = 
        Constants?.expoConfig?.extra?.eas?.projectId ?? 
        Constants?.easConfig?.projectId;
        
      if (!projectId) {
        console.error('Project ID not found in expo config. Please check app.json.');
      }

      token = (await ExpoNotifications.getExpoPushTokenAsync({
        projectId: projectId,
      })).data;
      
      console.log('Generated Expo Push Token:', token);
    } catch (e) {
      console.error('Error getting Expo push token:', e);
    }
  } else {
    console.log('Physical device required for Push Notifications');
  }

  return token;
}

/**
 * Sends the generated token to the backend with retry logic
 */
export async function savePushTokenAtBackend(token: string, retries = 3) {
  if (!token) return;
  
  for (let i = 0; i < retries; i++) {
    try {
      // Updated to match latest backend endpoint: /api/v3/notifications/register
      const response = await apiClient.post('/api/v3/notifications/save-token', { 
        expoPushToken: token 
      });
      console.log('Successfully registered push token at backend');
      return response;
    } catch (error) {
      console.error(`Attempt ${i + 1} to register push token failed:`, error);
      if (i === retries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, 2000 * (i + 1)));
    }
  }
}

export interface NotificationInboxResponse {
  success: boolean;
  data: {
    id: string;
    title: string;
    body: string;
    type: string;
    isRead: boolean;
    createdAt: string;
  }[];
  meta: {
    total: number;
    page: number;
    limit: number;
    unreadCount: number;
  };
}

/**
 * Fetches the notification inbox for the user
 */
export async function getNotificationInbox(page = 1, limit = 20): Promise<NotificationInboxResponse> {
  return apiClient.get('/api/v3/notifications/inbox', { params: { page, limit } });
}

/**
 * Marks a specific notification as read
 */
export async function markNotificationAsRead(id: string) {
  return apiClient.patch(`/api/v3/notifications/${id}/read`);
}

/**
 * Marks all unread notifications as read
 */
export async function markAllNotificationsAsRead() {
  return apiClient.patch('/api/v3/notifications/read-all');
}

/**
 * Permanently deletes a specific notification
 */
export async function deleteNotification(id: string) {
  return apiClient.delete(`/api/v3/notifications/${id}`);
}

/**
 * Permanently clears all notifications for the user
 */
export async function clearAllNotifications() {
  return apiClient.delete('/api/v3/notifications/clear-all');
}

/**
 * Sends a test notification to the current user
 */
export async function sendTestNotification() {
  return apiClient.get('/api/v3/notifications/test');
}

/**
 * Handles navigation when a user clicks on a notification
 */
export function handleNotificationResponse(response: ExpoNotifications.NotificationResponse) {
  const data = response.notification.request.content.data;
  if (!data || !data.type) return;

  console.log('Handling notification click with data:', data);

  const bookingId = data.bookingId ? String(data.bookingId) : undefined;

  switch (data.type) {
    case "BOOKING_CONFIRMED":
    case "PAYMENT_PARTIAL":
    case "PAYMENT_FULL":
      if (bookingId) {
        router.push({ pathname: '/customer/booking/confirm', params: { id: bookingId } });
      }
      break;

    case "SPLIT_PAYMENT":
    case "SPLIT_PAID":
    case "SPLIT_ADDED":
      if (bookingId) {
        router.push({ pathname: '/customer/booking/split', params: { id: bookingId } });
      }
      break;

    case "GAME_COMPLETED":
    case "STREAK_UPDATE":
      router.push('/customer/(tabs)/home');
      break;

    case "NO_SHOW":
      router.push('/customer/(tabs)/bookings');
      break;

    default:
      router.push('/customer/(tabs)/home');
  }
}

/**
 * Combined utility to register token, setup listeners, and handle initial notification
 */
export async function setupPushNotifications() {
  // 1. Register Token
  const token = await registerForPushNotificationsAsync();
  if (token) {
    await savePushTokenAtBackend(token);
  }

  // 2. Handle initial notification if app was opened from killed state
  const lastResponse = await ExpoNotifications.getLastNotificationResponseAsync();
  if (lastResponse) {
    handleNotificationResponse(lastResponse);
  }

  // 3. Listen for response (clicks)
  const responseSubscription = ExpoNotifications.addNotificationResponseReceivedListener(
    (response: ExpoNotifications.NotificationResponse) => {
      handleNotificationResponse(response);
    }
  );

  // 4. Listen for incoming (foreground)
  const notificationSubscription = ExpoNotifications.addNotificationReceivedListener(
    (notification: ExpoNotifications.Notification) => {
      // Just log for now, don't interrupt user flow
      console.log('Notification received in foreground:', notification.request.content.title);
    }
  );

  // Return unsubscribe function
  return () => {
    responseSubscription.remove();
    notificationSubscription.remove();
  };
}
