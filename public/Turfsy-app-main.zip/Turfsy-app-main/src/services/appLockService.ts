import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import * as LocalAuthentication from 'expo-local-authentication';
import { apiClient } from '../api/apiClient';

export interface AppLockSettings {
  enabled: boolean;
  method: 'BIOMETRIC' | 'MPIN' | null;
  timeout: number; // 0 for immediately, or milliseconds
  lastActive: number;
}

export const AppLockService = {
  // Keychain / SecureStore
  async storeToken(token: string) {
    await SecureStore.setItemAsync('AUTH_TOKEN', token);
  },
  async getToken() {
    return await SecureStore.getItemAsync('AUTH_TOKEN');
  },
  async clearToken() {
    await SecureStore.deleteItemAsync('AUTH_TOKEN');
  },

  // AsyncStorage for Settings
  async getSettings(): Promise<AppLockSettings> {
    const settingsStr = await AsyncStorage.getItem('APP_LOCK_SETTINGS');
    if (settingsStr) {
      return JSON.parse(settingsStr);
    }
    return {
      enabled: false,
      method: null,
      timeout: 0,
      lastActive: Date.now(),
    };
  },
  async saveSettings(settings: AppLockSettings) {
    await AsyncStorage.setItem('APP_LOCK_SETTINGS', JSON.stringify(settings));
  },
  async updateLastActive() {
    const settings = await this.getSettings();
    await this.saveSettings({ ...settings, lastActive: Date.now() });
  },
  async isLockScreenRequired(): Promise<boolean> {
    const settings = await this.getSettings();
    if (!settings.enabled) return false;
    
    // Fallback: If timeout was saved as 0 from an older version, treat it as 5 minutes.
    const actualTimeout = settings.timeout === 0 ? 5 * 60 * 1000 : settings.timeout;
    
    const now = Date.now();
    if (now - settings.lastActive > actualTimeout) {
      return true;
    }
    return false;
  },

  // Biometrics
  async isBiometricSupported() {
    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    return hasHardware && isEnrolled;
  },
  async authenticateBiometric() {
    return await LocalAuthentication.authenticateAsync({
      promptMessage: 'Authenticate to open Turfzy',
      fallbackLabel: 'Use MPIN',
    });
  },

  // MPIN Backend APIs
  async checkMpinStatus(): Promise<boolean> {
    try {
      const response = await apiClient.get('/api/v3/auth/get-me');
      return response?.data?.isMpinSet === true;
    } catch {
      return false;
    }
  },
  async createMpin(mpin: string, confirmMpin: string) {
    return apiClient.post('/api/v3/auth/create-mpin', { mpin, confirmMpin });
  },
  async verifyMpin(mpin: string) {
    return apiClient.post('/api/v3/auth/verify-mpin', { mpin });
  },
  async changeMpin(currentMpin: string, newMpin: string, confirmMpin: string) {
    return apiClient.patch('/api/v3/auth/change-mpin', { currentMpin, newMpin, confirmMpin });
  }
};
