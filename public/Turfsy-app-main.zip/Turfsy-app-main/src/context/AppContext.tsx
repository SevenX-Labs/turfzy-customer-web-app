import { createContext, useContext, useState, ReactNode, useEffect, useMemo, useRef, useCallback } from 'react';
import { useColorScheme, Appearance } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { THEMES, ThemeType } from '../constants/theme';
import { getPreciseUserLocation, PreciseLocationResult } from '../utils/location';
import { Booking } from '../types/booking.types';
import { setAuthHeader } from '../api/apiClient';
import { CreateProfileDto, UserService } from '../services/userService';
import { AuthService } from '../services/authService';
import { TurfService } from '../services/turfService';
import * as Haptics from 'expo-haptics';
import StatusModal from '../components/StatusModal';
import { HomeService, HomeResponse } from '../services/homeService';
import * as SplashScreen from 'expo-splash-screen';

type AppContextType = {

  role: 'customer' | 'owner' | null;
  setRole: (r: 'customer' | 'owner' | null) => void;
  bookings: Booking[];
  addBooking: (b: Booking) => void;
  pendingBooking: Partial<Booking> | null;
  setPendingBooking: (b: Partial<Booking> | null) => void;
  favoriteTurfIds: string[];
  toggleFavoriteTurf: (turfId: string) => void;
  isFavoriteTurf: (turfId: string) => boolean;
  theme: ThemeType;
  setTheme: (theme: ThemeType) => void;
  COLORS: typeof THEMES.light & { isDark: boolean };
  userLocation: PreciseLocationResult | null;
  refreshLocation: () => Promise<void>;
  isTabBarHidden: boolean;
  setIsTabBarHidden: (hidden: boolean) => void;
  authToken: string | null;
  setAuthToken: (t: string | null) => void;
  userInfo: { id: string; phone: string; role: string; isNewUser?: boolean } | null;
  setUserInfo: (u: { id: string; phone: string; role: string; isNewUser?: boolean } | null) => void;
  userProfile: any | null;
  setUserProfile: (p: any | null) => void;
  setBookings: (b: Booking[]) => void;
  onboardingData: Partial<CreateProfileDto> & { avatarUri?: string };
  updateOnboardingData: (data: Partial<CreateProfileDto> & { avatarUri?: string }) => void;
  refreshFavorites: () => Promise<void>;
  isAuthLoaded: boolean;
  isInitialDataLoaded: boolean;
  isManualRefreshing: boolean;
  setIsManualRefreshing: (val: boolean) => void;
  homeData: HomeResponse | null;
  setHomeData: (data: HomeResponse | null) => void;
  unreadCount: number;
  setUnreadCount: (count: number | ((prev: number) => number)) => void;
  showStatusModal: (config: { type: 'success' | 'error' | 'warning'; title: string; message: string; actionText?: string; onAction?: () => void }) => void;
  refreshProfile: () => Promise<void>;
};


const AppContext = createContext<AppContextType>({
  role: null,
  setRole: () => {},
  bookings: [],
  addBooking: () => {},
  pendingBooking: null,
  setPendingBooking: () => {},
  favoriteTurfIds: [],
  toggleFavoriteTurf: () => {},
  isFavoriteTurf: () => false,
  theme: 'system',
  setTheme: () => {},
  COLORS: { ...THEMES.light, isDark: false },
  userLocation: null,
  refreshLocation: async () => {},
  isTabBarHidden: false,
  setIsTabBarHidden: () => {},
  authToken: null,
  setAuthToken: () => {},
  userInfo: null,
  setUserInfo: () => {},
  userProfile: null,
  setUserProfile: () => {},
  setBookings: () => {},
  onboardingData: {},
  updateOnboardingData: () => {},
  refreshFavorites: async () => {},
  isAuthLoaded: false,
  isInitialDataLoaded: false,
  isManualRefreshing: false,
  setIsManualRefreshing: () => {},
  homeData: null,
  setHomeData: () => {},
  unreadCount: 0,
  setUnreadCount: () => {},
  showStatusModal: () => {},
  refreshProfile: async () => {},
});




export function AppProvider({ children }: { children: ReactNode }) {
  const systemColorScheme = useColorScheme();
  const [role, setRole] = useState<'customer' | 'owner' | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [pendingBooking, setPendingBooking] = useState<Partial<Booking> | null>(null);
  const [favoriteTurfIds, setFavoriteTurfIds] = useState<string[]>([]);

  const [theme, setTheme] = useState<ThemeType>('system');
  const [userLocation, setUserLocation] = useState<PreciseLocationResult | null>(null);
  const [isTabBarHidden, setIsTabBarHidden] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [userInfo, setUserInfo] = useState<{ id: string; phone: string; role: string; isNewUser?: boolean } | null>(null);
  const [userProfile, setUserProfile] = useState<any | null>(null);
  const [onboardingData, setOnboardingData] = useState<Partial<CreateProfileDto> & { avatarUri?: string }>({});
  const [homeData, setHomeData] = useState<HomeResponse | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isInitialDataLoaded, setIsInitialDataLoaded] = useState(false);
  const [isManualRefreshing, setIsManualRefreshing] = useState(false);

  const [isStatusVisible, setIsStatusVisible] = useState(false);
  const [statusType, setStatusType] = useState<'success' | 'error' | 'warning'>('success');
  const [statusTitle, setStatusTitle] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [statusActionText, setStatusActionText] = useState<string | undefined>();
  const [statusOnAction, setStatusOnAction] = useState<(() => void) | undefined>();

  const showStatusModal = useCallback((config: { type: 'success' | 'error' | 'warning'; title: string; message: string; actionText?: string; onAction?: () => void }) => {
    setStatusType(config.type);
    setStatusTitle(config.title);
    setStatusMessage(config.message);
    setStatusActionText(config.actionText);
    setStatusOnAction(() => config.onAction); // Use functional update to store a function in state
    setIsStatusVisible(true);
  }, []);

  const updateOnboardingData = useCallback((data: Partial<CreateProfileDto> & { avatarUri?: string }) => {
    setOnboardingData(prev => ({ ...prev, ...data }));
  }, []);

  // Immediate detection to prevent "flash"
  const currentSystemTheme = useMemo(() => {
    return systemColorScheme || Appearance.getColorScheme() || 'light';
  }, [systemColorScheme]);

  const resolvedTheme: 'light' | 'dark' = useMemo(() => {
    return theme === 'system' ? (currentSystemTheme === 'dark' ? 'dark' : 'light') : theme;
  }, [theme, currentSystemTheme]);

  const COLORS = useMemo(() => ({
    ...THEMES[resolvedTheme],
    isDark: resolvedTheme === 'dark',
  }), [resolvedTheme]);

  const lastLocationFetch = useRef<number>(0);
  const skipNextProfileSync = useRef<boolean>(false);

  const refreshLocation = useCallback(async () => {
    const now = Date.now();
    // Cache location for 5 minutes (300000 ms) to save battery
    if (userLocation && (now - lastLocationFetch.current < 300000)) {
      return; 
    }
    const loc = await getPreciseUserLocation();
    if (loc) {
      setUserLocation(loc);
      lastLocationFetch.current = now;
    }
  }, [userLocation]);

  const refreshFavorites = useCallback(async () => {
    try {
      const response = await TurfService.getSavedTurfs();
      if (response.success) {
        const ids = response.data.map(item => item.turfDetails.id);
        setFavoriteTurfIds(ids);
      }
    } catch (error) {
      console.warn('Failed to refresh favorites:', error);
    }
  }, []);
  
  const refreshProfile = useCallback(async () => {
    try {
      const response = await UserService.getProfile();
      if (response.success) {
        setUserProfile(response.data);
        AsyncStorage.setItem('@user_profile', JSON.stringify(response.data));
      }
    } catch (error) {
      console.warn('Failed to refresh profile:', error);
    }
  }, []);


  useEffect(() => {
    refreshLocation();
  }, []);

  const [isAuthLoaded, setIsAuthLoaded] = useState(false);

  const deriveIsNewUserFromProfile = (profile: any) => {
    return profile == null;
  };

  // 1. Persistence Initialization: Load Auth from Disk
  useEffect(() => {
    const loadAuth = async () => {
      try {
        const [storedToken, storedUser, storedRole, storedProfile] = await Promise.all([
          AsyncStorage.getItem('@auth_token'),
          AsyncStorage.getItem('@user_info'),
          AsyncStorage.getItem('@user_role'),
          AsyncStorage.getItem('@user_profile'),
        ]);

        if (storedProfile) {
          try {
            setUserProfile(JSON.parse(storedProfile));
          } catch (e) {}
        }

        if (storedUser) {
          try {
            setUserInfo(JSON.parse(storedUser));
          } catch (e) {
            console.warn('Failed to parse stored user info:', e);
          }
        }
        if (storedRole) setRole(storedRole as any);

        if (storedToken) {
          setAuthHeader(storedToken);
          setAuthToken(storedToken);
          
          // Fetch latest user and profile data
          try {
            const meResponse = await AuthService.getMe();
            if (meResponse.success) {
              const isNewUser = deriveIsNewUserFromProfile(meResponse.data.profile);
              const info = {
                id: meResponse.data.id,
                phone: meResponse.data.phone,
                role: meResponse.data.role,
                isNewUser,
              };
              setUserInfo(info);
              const fullProfile = { ...meResponse.data.profile, payment: meResponse.data.payment };
              setUserProfile(fullProfile);
              skipNextProfileSync.current = true; // Skip redundant API call in the token effect
              setAuthToken(storedToken);
              
              // Update storage with fresh info
              AsyncStorage.multiSet([
                ['@user_info', JSON.stringify(info)],
                ['@user_profile', JSON.stringify(fullProfile)]
              ]);
            } else {
              // If success is false, only clear token if unauthorized
              if ((meResponse as any).statusCode === 401) {
                setAuthToken(null);
                setAuthHeader(null);
                AsyncStorage.removeItem('@auth_token');
              } else {
                setAuthToken(storedToken);
              }
            }
          } catch (apiErr: any) {
            console.warn('Authentication validation failed:', apiErr);
            // ONLY clear token on 401 Unauthorized to avoid logging out users on 429/500/network errors
            const isUnauthorized = apiErr?.status === 401 || apiErr?.response?.status === 401 || apiErr?.response?.data?.statusCode === 401;
            
            if (isUnauthorized) {
              setAuthToken(null);
              setAuthHeader(null);
              AsyncStorage.removeItem('@auth_token');
            } else {
              setAuthToken(storedToken);
            }
          }
          
          // Pre-fetch Home Data if authenticated
          if (storedToken) {
            try {
              const homeRes = await HomeService.getHomeData();
              if (homeRes.success) {
                setHomeData(homeRes);
              }
            } catch (homeErr) {
              console.warn('Initial home data fetch failed:', homeErr);
            }
          }
          
          // Favorites will be pulled automatically by the authToken effect
        }

      } catch (e) {
        console.error('Failed to load auth state', e);
      } finally {
        setIsAuthLoaded(true);
        setIsInitialDataLoaded(true);
      }
    };
    loadAuth();
  }, []);

  useEffect(() => {
    if (!isAuthLoaded) return; // Prevent clearing token during initialization

    if (authToken) {
      AsyncStorage.setItem('@auth_token', authToken);
      setAuthHeader(authToken);
      
      // Every time token changes, refresh user profile to keep state in sync
      const syncProfile = async () => {
        try {
          const meResponse = await AuthService.getMe();
          if (meResponse.success) {
            const isNewUser = deriveIsNewUserFromProfile(meResponse.data.profile);
            const freshInfo = {
              id: meResponse.data.id,
              phone: meResponse.data.phone,
              role: meResponse.data.role,
              isNewUser,
            };
            setUserInfo(freshInfo);
            const fullProfile = { ...meResponse.data.profile, payment: meResponse.data.payment };
            setUserProfile(fullProfile);
            
            AsyncStorage.multiSet([
              ['@user_info', JSON.stringify(freshInfo)],
              ['@user_profile', JSON.stringify(fullProfile)]
            ]);
          }
        } catch (e) {
          console.warn('Profile sync failed:', e);
        }
      };

      // Only sync profile if we didn't just fetch it during loadAuth
      if (skipNextProfileSync.current) {
        skipNextProfileSync.current = false;
      } else {
        syncProfile();
      }
      
      refreshFavorites();
    } else {
      AsyncStorage.removeItem('@auth_token');
      setAuthHeader(null);
    }
  }, [authToken, isAuthLoaded]);

  useEffect(() => {
    if (!isAuthLoaded) return;

    const backupUserInfo = async () => {
      try {
        const stored = await AsyncStorage.getItem('@user_info');
        if (userInfo) {
          const stringified = JSON.stringify(userInfo);
          if (stored !== stringified) {
            await AsyncStorage.setItem('@user_info', stringified);
          }
        } else if (stored) {
          await AsyncStorage.removeItem('@user_info');
        }
      } catch (e) {
        console.warn('Failed memory cache validation:', e);
      }
    };
    backupUserInfo();
  }, [userInfo, isAuthLoaded]);

  useEffect(() => {
    if (!isAuthLoaded) return;

    if (role) {
      AsyncStorage.setItem('@user_role', role);
    } else {
      AsyncStorage.removeItem('@user_role');
    }
  }, [role, isAuthLoaded]);

  const addBooking = useCallback((b: Booking) => {
    setBookings((prev) => [b, ...prev]);
  }, []);

  const toggleFavoriteTurf = useCallback(async (turfId: string) => {
    const isFav = favoriteTurfIds.includes(turfId);
    
    // Optimistic UI
    setFavoriteTurfIds((prev) =>
      isFav ? prev.filter((id) => id !== turfId) : [...prev, turfId]
    );

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      if (isFav) {
        await TurfService.unsaveTurf(turfId);
      } else {
        await TurfService.saveTurf(turfId);
      }
    } catch (error) {
      console.error('Failed to toggle favorite:', error);
      // Revert on error
      setFavoriteTurfIds((prev) =>
        !isFav ? prev.filter((id) => id !== turfId) : [...prev, turfId]
      );
    }
  }, [favoriteTurfIds]);


  const isFavoriteTurf = useCallback((turfId: string) => favoriteTurfIds.includes(turfId), [favoriteTurfIds]);

  const contextValue = useMemo(() => ({
    role,
    setRole,
    bookings,
    addBooking,
    pendingBooking,
    setPendingBooking,
    favoriteTurfIds,
    toggleFavoriteTurf,
    isFavoriteTurf,
    theme,
    setTheme,
    COLORS,
    userLocation,
    refreshLocation,
    isTabBarHidden,
    setIsTabBarHidden,
    authToken,
    setAuthToken,
    userInfo,
    setUserInfo,
    userProfile,
    setUserProfile,
    setBookings,
    onboardingData,
    updateOnboardingData,
    refreshFavorites,
    isAuthLoaded,
    isInitialDataLoaded,
    isManualRefreshing,
    setIsManualRefreshing,
    homeData,
    setHomeData,
    unreadCount,
    setUnreadCount,
    showStatusModal,
    refreshProfile,
  }), [
    role, bookings, pendingBooking, favoriteTurfIds, theme, COLORS,
    userLocation, isTabBarHidden, authToken, userInfo, userProfile,
    onboardingData, isAuthLoaded, isInitialDataLoaded, homeData,
    isManualRefreshing, unreadCount, refreshProfile
  ]);

  return (
    <AppContext.Provider
      value={contextValue}
    >
      {children}
      <StatusModal
        visible={isStatusVisible}
        type={statusType}
        title={statusTitle}
        message={statusMessage}
        actionText={statusActionText}
        onAction={statusOnAction}
        onClose={() => setIsStatusVisible(false)}
      />
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
