/**
 * Below are the colors that are used in the app. The colors are defined in the light and dark mode.
 * There are many other ways to style your app. For example, [Nativewind](https://www.nativewind.dev/), [Tamagui](https://tamagui.dev/), [unistyles](https://reactnativeunistyles.vercel.app), etc.
 */

import { Platform } from 'react-native';

const tintColorLight = '#0a7ea4';
const tintColorDark = '#fff';

export type ThemeType = 'light' | 'dark' | 'system';

export const LIGHT_THEME = {
  kiwi: '#89E900',
  night: '#FFFFFF',
  surface: '#FFFFFF',
  textMain: '#000000',
  textMuted: '#8E8E93',
  border: 'rgba(0, 0, 0, 0.08)',
  error: '#FF453A',
  background: '#F8F9FA', // Off-white background
  primary: '#89E900',
  card: '#FFFFFF',
  textSecondary: '#8E8E93',
  textBase: '#000000',
  skeletonBase: '#E0E0E0',
  skeletonHighlight: '#F5F5F5',
  accentGreen: '#89E900',
  primaryDark: '#6FC000',
  gold: '#F6C453',
  silver: '#C7CDD6',
  bronze: '#C98752',
  surfaceSoft: 'rgba(0, 0, 0, 0.03)',
  placeholder: '#A1A1A1',
  btnDarkText: '#000000',
  closeIcon: '#000000',
  chevron: '#8E8E93',
  cardBg: '#FFFFFF',
  iconBoxBorder: 'rgba(0, 0, 0, 0.08)',
  iconBoxBg: '#F5F5F7',
  textSub: '#8E8E93',
  borderDark: 'rgba(0, 0, 0, 0.15)',
  surfaceLight: 'rgba(0, 0, 0, 0.05)',
};

export const DARK_THEME = {
  kiwi: '#89E900',
  night: '#08090A',
  surface: '#151718',
  textMain: '#FFFFFF',
  textMuted: '#888E96',
  border: 'rgba(255, 255, 255, 0.08)',
  error: '#FF453A',
  background: '#08090A',
  primary: '#89E900',
  card: '#151718',
  textSecondary: '#888E96',
  textBase: '#FFFFFF',
  skeletonBase: '#151718',
  skeletonHighlight: '#2A2C2E',
  accentGreen: '#89E900',
  primaryDark: '#6FC000',
  gold: '#F6C453',
  silver: '#C7CDD6',
  bronze: '#C98752',
  surfaceSoft: 'rgba(255, 255, 255, 0.03)',
  placeholder: '#444444',
  btnDarkText: '#000000',
  closeIcon: '#FFFFFF',
  chevron: '#888E96',
  cardBg: '#151718',
  iconBoxBorder: 'rgba(255, 255, 255, 0.08)',
  iconBoxBg: '#08090A',
  textSub: '#888E96',
  borderDark: 'rgba(255, 255, 255, 0.15)',
  surfaceLight: 'rgba(255, 255, 255, 0.05)',
};

export const THEMES = {
  light: LIGHT_THEME,
  dark: DARK_THEME,
};

export const Colors = {
  light: {
    text: '#11181C',
    background: '#fff',
    tint: tintColorLight,
    icon: '#687076',
    tabIconDefault: '#687076',
    tabIconSelected: tintColorLight,
  },
  dark: {
    text: '#ECEDEE',
    background: '#151718',
    tint: tintColorDark,
    icon: '#9BA1A6',
    tabIconDefault: '#9BA1A6',
    tabIconSelected: tintColorDark,
  },
};

export const Fonts = Platform.select({
  ios: {
    /** iOS `UIFontDescriptorSystemDesignDefault` */
    sans: 'system-ui',
    /** iOS `UIFontDescriptorSystemDesignSerif` */
    serif: 'ui-serif',
    /** iOS `UIFontDescriptorSystemDesignRounded` */
    rounded: 'ui-rounded',
    /** iOS `UIFontDescriptorSystemDesignMonospaced` */
    mono: 'ui-monospace',
  },
  default: {
    sans: 'normal',
    serif: 'serif',
    rounded: 'normal',
    mono: 'monospace',
  },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded: "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});
