import { useEffect, useRef } from 'react';
import { StyleSheet, View, Animated, Image, Dimensions } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import * as SplashScreen from 'expo-splash-screen';
import { useApp } from '@/src/context/AppContext';

type OpeningSplashProps = {
  onFinish: () => void;
  isReady?: boolean;
};

const LOGO_LOCAL = require('@/assets/images/logo.png');

export default function OpeningSplash({ onFinish, isReady = true }: OpeningSplashProps) {
  const logoFade = useRef(new Animated.Value(1)).current;
  const uiFade = useRef(new Animated.Value(1)).current;
  const isFinishedSequence = useRef(false);
  const isReadyRef = useRef(isReady);
  const hasFinished = useRef(false);
  const { COLORS } = useApp();
  const isDark = COLORS.isDark;

  // Keep the ref in sync with the prop so the setTimeout callback always sees current value
  isReadyRef.current = isReady;

  const triggerFadeOut = () => {
    if (hasFinished.current) return;
    hasFinished.current = true;

    Animated.parallel([
      Animated.timing(logoFade, { toValue: 0, duration: 400, useNativeDriver: true }),
      Animated.timing(uiFade, { toValue: 0, duration: 400, useNativeDriver: true }),
    ]).start(() => {
      onFinish();
    });
  };

  useEffect(() => {
    // Immediately hide the native OS splash so only our JS splash shows — fixes double logo
    SplashScreen.hideAsync().catch(() => {});

    // If already ready, start fade out immediately to respect user's request for fast start
    if (isReadyRef.current) {
      triggerFadeOut();
      return;
    }

    // Wait for the minimum branding duration only if not ready
    const timer = setTimeout(() => {
      isFinishedSequence.current = true;
      // If auth is already resolved by the time the timer fires, leave immediately
      if (isReadyRef.current) {
        triggerFadeOut();
      }
    }, 1200);

    return () => clearTimeout(timer);
  }, []);

  // When isReady becomes true AFTER the timer has already started
  useEffect(() => {
    if (isReady) {
      // If we haven't finished the sequence but the user is ready, 
      // we can still trigger fade out if we want it to be super fast
      triggerFadeOut();
    }
  }, [isReady]);

  // Dynamic Styles for Atmosphere
  const blobTopColor = isDark ? '#1A2E05' : '#C5FF00';
  const blobBottomColor = isDark ? '#0D1A02' : '#89E900';
  const blobOpacityTop = isDark ? 0.6 : 0.3;
  const blobOpacityBottom = isDark ? 0.5 : 0.25;

  return (
    <View style={[styles.container, { backgroundColor: isDark ? '#000000' : '#FFFFFF' }]}>
      {/* Atmosphere */}
      <Animated.View style={[StyleSheet.absoluteFill, { opacity: uiFade }]}>
        <View style={[styles.blobTop, { backgroundColor: blobTopColor, opacity: blobOpacityTop }]} />
        <View style={[styles.blobBottom, { backgroundColor: blobBottomColor, opacity: blobOpacityBottom }]} />
      </Animated.View>

      <View style={styles.content}>
        <Animated.View style={[styles.logoContainer, { opacity: logoFade }]}>
          <Image
            source={LOGO_LOCAL}
            style={styles.logo}
            resizeMode="contain"
          />
        </Animated.View>

        <Animated.View style={[styles.quoteWrap, { opacity: uiFade }]}>
          <Text style={[styles.quoteText, { color: COLORS.textMain }]}>BOOK. PLAY. REPEAT.</Text>
          <View style={[styles.quoteLine, { backgroundColor: isDark ? '#89E900' : COLORS.textMain }]} />
        </Animated.View>
      </View>
    </View>
  );
}

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  blobTop: {
    position: 'absolute',
    top: -width * 0.1,
    right: -width * 0.2,
    width: width * 0.8,
    height: width * 0.8,
    borderRadius: (width * 0.8) / 2,
  },
  blobBottom: {
    position: 'absolute',
    bottom: -width * 0.15,
    left: -width * 0.2,
    width: width * 0.9,
    height: width * 0.9,
    borderRadius: (width * 0.9) / 2,
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: '100%',
  },
  logoContainer: {
    width: width * 0.55,
    height: width * 0.55,
    marginBottom: 40,
    backgroundColor: 'transparent',
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  quoteWrap: {
    position: 'absolute',
    bottom: 60,
    alignItems: 'center',
  },
  quoteText: {
    fontSize: 13,
    fontWeight: '900',
    letterSpacing: 5,
    textTransform: 'uppercase',
  },
  quoteLine: {
    width: 40,
    height: 3,
    marginTop: 10,
    borderRadius: 2,
  },
});
