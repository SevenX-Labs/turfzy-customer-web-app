import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Dimensions, ActivityIndicator, Animated } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../context/AppContext';

const { width } = Dimensions.get('window');

export default function LoadingOverlay({ message = "Finalizing your profile..." }: { message?: string }) {
  const { COLORS } = useApp();
  const opacity = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(0.85)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, tension: 80, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);

  return (
    <Animated.View style={[styles.container, { opacity }]}>
      <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} />
      <Animated.View style={[styles.card, { backgroundColor: COLORS.surface, transform: [{ scale }] }]}>
        <View style={[styles.iconBox, { backgroundColor: COLORS.kiwi + '20' }]}>
          <Ionicons name="sparkles" size={32} color={COLORS.kiwi} />
        </View>
        <Text style={[styles.title, { color: COLORS.textMain }]}>{message}</Text>
        <Text style={[styles.subtitle, { color: COLORS.textMuted }]}>
          Setting up your professional dashboard
        </Text>
        <View style={styles.loaderWrapper}>
          <ActivityIndicator size="small" color={COLORS.kiwi} />
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { backgroundColor: COLORS.kiwi }]} />
          </View>
        </View>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: width * 0.85,
    padding: 32,
    borderRadius: 32,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.4,
    shadowRadius: 30,
    elevation: 20,
  },
  iconBox: {
    width: 64,
    height: 64,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 24,
    opacity: 0.8,
  },
  loaderWrapper: {
    width: '100%',
    alignItems: 'center',
  },
  progressBar: {
    width: '60%',
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    marginTop: 16,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    width: '100%',
  },
});
