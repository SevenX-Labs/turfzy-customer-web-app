import { TextInput } from 'react-native';

type Props = {
  placeholder?: string;
  value?: string;
  onChangeText?: (text: string) => void;
};

export default function InputField({ placeholder, value, onChangeText }: Props) {
  return (
    <TextInput
      placeholder={placeholder}
      value={value}
      onChangeText={onChangeText}
      placeholderTextColor="#AAAAAA"
      style={{
        backgroundColor: '#FFFFFF',
        height: 52,
        borderRadius: 25,
        paddingHorizontal: 16,
        fontSize: 15,
        borderWidth: 1,
        borderColor: '#E8E3D9',
      }}
    />
  );
}