import React from 'react';
import { View, TouchableOpacity } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { Image } from 'expo-image';

type Props = {
  horizontal?: boolean;
  onPress?: () => void;
};

const TurfCard = React.memo(({ horizontal, onPress }: Props) => {
  if (horizontal) {
    return (
      <TouchableOpacity
        onPress={onPress}
        style={{
          width: 260,
          backgroundColor: '#fff',
          borderRadius: 20,
          marginRight: 15,
          marginTop: 15,
          overflow: 'hidden',
          elevation: 4,
        }}
      >
        <Image
          source={{
            uri: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2',
          }}
          style={{ width: '100%', height: 150 }}
        />

        <View style={{ padding: 14 }}>
          <Text style={{ fontWeight: '600' }}>
            Midtown Goal Park
          </Text>

          <Text style={{ fontSize: 12, color: '#888' }}>
            📍 4.5 km away
          </Text>

          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: '#5C7A2E', fontWeight: '700' }}>
              ₹800/hr
            </Text>

            <Text>⭐ 4.8</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={onPress}
      style={{
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderRadius: 20,
        padding: 12,
        marginTop: 15,
        elevation: 3,
      }}
    >
      <Image
        source={{
          uri: 'https://images.unsplash.com/photo-1521412644187-c49fa049e84d',
         }}
        style={{ width: 90, height: 90, borderRadius: 14 }}
      />

      <View style={{ marginLeft: 12 }}>
        <Text style={{ fontWeight: '600' }}>
          Elite Sports Arena
        </Text>

        <Text style={{ fontSize: 12, color: '#888' }}>
          📍 2.3 km away
        </Text>

        <Text>⭐ 4.7</Text>

        <Text style={{ color: '#5C7A2E', fontWeight: '700' }}>
          ₹900/hr
        </Text>
      </View>
    </TouchableOpacity>
  );
});

export default TurfCard;