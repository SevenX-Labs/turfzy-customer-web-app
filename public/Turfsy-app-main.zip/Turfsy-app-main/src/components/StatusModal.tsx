import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Modal, TouchableOpacity, Dimensions, Platform, Animated } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../context/AppContext';

const { width } = Dimensions.get('window');

type StatusModalProps = {
  visible: boolean;
  type: 'success' | 'error' | 'warning';
  title: string;
  message: string;
  onClose: () => void;
  actionText?: string;
  onAction?: () => void;
};

export default function StatusModal({
  visible,
  type,
  title,
  message,
  onClose,
  actionText,
  onAction,
}: StatusModalProps) {
  const { COLORS } = useApp();
  const scale = useRef(new Animated.Value(0.8)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(scale, {
          toValue: 1,
          useNativeDriver: true,
          tension: 80,
          friction: 8,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(scale, {
          toValue: 0.8,
          duration: 150,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0,
          duration: 150,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible]);

  const getIcon = () => {
    switch (type) {
      case 'success':
        return { name: 'checkmark-done', color: COLORS.kiwi };
      case 'error':
        return { name: 'alert-circle', color: '#FF3B30' };
      case 'warning':
        return { name: 'warning', color: '#FF9500' };
      default:
        return { name: 'information-circle', color: COLORS.kiwi };
    }
  };

  const icon = getIcon();

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <BlurView intensity={Platform.OS === 'ios' ? 20 : 100} tint="dark" style={StyleSheet.absoluteFill} />
        <Animated.View
          style={[
            styles.card,
            { backgroundColor: COLORS.surface, borderColor: COLORS.border },
            { opacity, transform: [{ scale }] },
          ]}
        >
          <View style={[styles.iconBox, { backgroundColor: icon.color + '20' }]}>
            <Ionicons name={icon.name as any} size={48} color={icon.color} />
          </View>

          <Text style={[styles.title, { color: COLORS.textMain }]}>{title}</Text>
          <Text style={[styles.message, { color: COLORS.textMuted }]}>{message}</Text>

          <View style={styles.actionRow}>
            <TouchableOpacity
              style={[styles.btn, { backgroundColor: COLORS.background, borderColor: COLORS.border, borderWidth: 1 }]}
              onPress={onClose}
              activeOpacity={0.7}
            >
              <Text style={[styles.btnText, { color: COLORS.textMain }]}>
                {onAction ? 'Cancel' : 'Dismiss'}
              </Text>
            </TouchableOpacity>

            {onAction && actionText && (
              <TouchableOpacity
                style={[styles.btnMain, { backgroundColor: icon.color }]}
                onPress={onAction}
                activeOpacity={0.8}
              >
                <Text style={styles.btnTextMain}>{actionText}</Text>
              </TouchableOpacity>
            )}
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  card: {
    width: '100%',
    maxWidth: 340,
    borderRadius: 32,
    borderWidth: 1,
    padding: 32,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.4,
    shadowRadius: 30,
    elevation: 20,
  },
  iconBox: {
    width: 88,
    height: 88,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 22,
    fontWeight: '900',
    textAlign: 'center',
    marginBottom: 10,
  },
  message: {
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 32,
    opacity: 0.8,
  },
  actionRow: {
    width: '100%',
    flexDirection: 'row',
    gap: 12,
  },
  btn: {
    flex: 1,
    height: 56,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnMain: {
    flex: 1.5,
    height: 56,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  btnText: {
    fontSize: 15,
    fontWeight: '700',
  },
  btnTextMain: {
    fontSize: 15,
    fontWeight: '800',
    color: '#FFF',
  },
});
