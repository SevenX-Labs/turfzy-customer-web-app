import React from 'react';
import { Text as RNText, TextProps as RNTextProps, StyleSheet } from 'react-native';

export type AppTextProps = RNTextProps;

export const AppText: React.FC<AppTextProps> = (props) => {
  const { style, ...rest } = props;
  const flattenedStyle = StyleSheet.flatten(style) || {};
  
  let fontWeight = '400';
  if (flattenedStyle.fontWeight) {
    fontWeight = flattenedStyle.fontWeight.toString();
  }

  let fontFamily = 'Inter';
  if (fontWeight === 'bold' || fontWeight === '700') fontFamily = 'Inter-Bold';
  else if (fontWeight === '100') fontFamily = 'Inter-Thin';
  else if (fontWeight === '200') fontFamily = 'Inter-ExtraLight';
  else if (fontWeight === '300') fontFamily = 'Inter-Light';
  else if (fontWeight === '500') fontFamily = 'Inter-Medium';
  else if (fontWeight === '600') fontFamily = 'Inter-SemiBold';
  else if (fontWeight === '800') fontFamily = 'Inter-ExtraBold';
  else if (fontWeight === '900') fontFamily = 'Inter-Black';

  // Remove fontWeight and fontStyle to prevent Android from falling back to system fonts
  const { fontWeight: _fw, fontStyle: _fs, ...restStyle } = flattenedStyle as any;

  return (
    <RNText style={[{ fontFamily }, restStyle]} {...rest} />
  );
};
