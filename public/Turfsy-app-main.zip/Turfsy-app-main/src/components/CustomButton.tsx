import React from 'react';
import { TouchableOpacity, ActivityIndicator, StyleSheet, Platform } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;

type Props = {
  title: string;
  onPress?: () => void;
  loading?: boolean;
  disabled?: boolean;
};

export default function CustomButton({ title, onPress, loading, disabled }: Props) {
  const isInteractionDisabled = loading || disabled;

  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.8}
      disabled={isInteractionDisabled}
      style={[
        styles.button,
        isInteractionDisabled && styles.disabledButton
      ]}
    >
      {loading ? (
        <ActivityIndicator color="#FFFFFF" />
      ) : (
        <Text style={styles.text}>
          {title}
        </Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#16a34a', // Turfsy Primary Green
    height: 60,
    borderRadius: 18, // Matches your TurfCard and InputField radius
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    flexDirection: 'row',
    
    // Premium Shadow Logic
    ...Platform.select({
      ios: {
        shadowColor: '#16a34a',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.2,
        shadowRadius: 10,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  disabledButton: {
    backgroundColor: '#A7F3D0', // Lighter green to show it's inactive
    elevation: 0,
    shadowOpacity: 0,
  },
  text: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
});