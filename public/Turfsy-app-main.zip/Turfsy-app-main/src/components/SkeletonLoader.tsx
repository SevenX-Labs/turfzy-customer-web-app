import React, { useEffect } from 'react';
import { View, StyleSheet, Animated, DimensionValue, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../context/AppContext';

interface SkeletonLoaderProps {
  width: DimensionValue;
  height: DimensionValue;
  borderRadius?: number;
  style?: any;
}

const SkeletonLoader: React.FC<SkeletonLoaderProps> = ({ width, height, borderRadius = 8, style }) => {
  const animatedValue = new Animated.Value(0);
  const { COLORS } = useApp();

  useEffect(() => {
    Animated.loop(
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 1500,
        useNativeDriver: true,
      })
    ).start();
  }, []);

  const screenWidth = Dimensions.get('window').width;

  const translateX = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [-screenWidth, screenWidth],
  });

  const baseBgColor = COLORS?.skeletonBase || 'rgba(255,255,255,0.05)';
  const highlightColor = COLORS?.skeletonHighlight || 'rgba(255,255,255,0.1)';

  return (
    <View style={[styles.container, { width, height, borderRadius, backgroundColor: baseBgColor }, style]}>
      <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ translateX }] }]}>
        <LinearGradient
          colors={['transparent', highlightColor, 'transparent']}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={StyleSheet.absoluteFill}
        />
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
  },
});

export default SkeletonLoader;
