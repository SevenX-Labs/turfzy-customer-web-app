declare module 'react-native-razorpay' {
  interface Prefill {
    email?: string;
    contact?: string;
    name?: string;
  }

  interface Theme {
    color?: string;
  }

  interface CheckoutOptions {
    description?: string;
    image?: string;
    currency: string;
    key: string;
    amount: number;
    name: string;
    order_id: string;
    prefill?: Prefill;
    theme?: Theme;
    [key: string]: any;
  }

  interface PaymentResult {
    razorpay_payment_id: string;
    razorpay_order_id: string;
    razorpay_signature: string;
  }

  export default class RazorpayCheckout {
    static open(options: CheckoutOptions): Promise<PaymentResult>;
  }
}
