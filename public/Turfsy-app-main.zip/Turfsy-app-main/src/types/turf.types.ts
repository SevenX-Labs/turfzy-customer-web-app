export type TurfAvailability = 'Available' | 'Busy' | 'Full';

export type Turf = {
  id: string;
  name: string;
  image: string;
  images: string[];
  location: string;
  distance: string;
  rating: number;
  reviews: number;
  pricePerHour: number;
  sports: string[];
  amenities: string[];
  description: string;
  openTime: string;
  closeTime: string;
  size: string;
  availability: TurfAvailability;
  lat?: number;
  lng?: number;
};
