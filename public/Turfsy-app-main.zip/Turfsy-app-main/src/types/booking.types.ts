export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';
export type PaymentStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED';
export type PaymentType = 'FULL_ONLINE' | 'HALF_ONLINE_HALF_CASH' | 'FULL_CASH';

export interface Booking {
  id: string;
  displayId: string;
  turfId: string;
  bookingDate: string;
  startTime: string;
  endTime: string;
  durationMins: number;
  bookingStatus: BookingStatus;
  paymentStatus: PaymentStatus;
  paymentType: PaymentType;
  amount: number;
  depositAmount: number;
  platformFee?: number;
  amountToPay: number;
  remainingAmount: number;
  checkInPin: string | null;
  pinExpiresAt?: string;
  qrStatus?: 'UPCOMING' | 'ACTIVE' | 'COMPLETED' | 'NO_SHOW' | 'EXPIRED';
  qrMessage?: string;
  qrCode?: string | null;
  createdAt: string;
  
  // Nested turf info for display in lists
  turf?: {
    id: string;
    name: string;
    city: string;
    address: string;
    sportsType: string;
    entranceUrl?: string;
    groundDayUrl?: string;
    images?: string[];
  };

  // Legacy fields for backward compatibility during migration
  // (UI components might still use these)
  status?: 'upcoming' | 'completed' | 'cancelled' | 'pending';
  date?: string;
  timeSlot?: string;
  hours?: number;
  turfName?: string;
  turfImage?: string; 
  location?: string;
  sport?: string;
  totalAmount?: number;
  bookingCode?: string;
  pricePerHour?: number;
}
