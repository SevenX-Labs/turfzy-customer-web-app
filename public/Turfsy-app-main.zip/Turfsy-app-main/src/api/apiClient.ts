import axios from 'axios';

// The centralized source of truth for API configuration
const BASE_URL = 'https://turfsy.onrender.com';

const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

/**
 * Configure global interceptors for a professional request flow
 */

// 0. Request Interceptor: Log outgoing requests for debugging
apiClient.interceptors.request.use((config) => {
  if (__DEV__) {
    console.log('[API REQUEST]', {
      method: config.method?.toUpperCase(),
      url: config.url,
      params: config.params,
      data: config.data
    });
  }
  return config;
});

// 1. Request Interceptor: Inject JWT Token automatically
export const setAuthHeader = (token: string | null) => {
  if (token) {
    apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete apiClient.defaults.headers.common['Authorization'];
  }
};

// 2. Response Interceptor: Flatten data & Global error handling
apiClient.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const errorData = error.response?.data;
    const message = errorData?.message || 'A network error occurred';
    const status = error.response?.status;
    const method = error.config?.method?.toUpperCase();
    const path = error.config?.url;
    const headers = error.response?.headers || {};
    const requestId =
      headers['rndr-id'] ||
      headers['x-request-id'] ||
      headers['cf-ray'] ||
      headers['x-correlation-id'];
    
    // Log errors in dev for easier debugging
    if (__DEV__) {
      console.warn('[API ERROR]', {
        status,
        message,
        path,
        method,
        requestId,
        data: errorData,
      });
    }

    return Promise.reject({
      success: false,
      message,
      status,
      statusCode: errorData?.statusCode ?? status,
      path,
      method,
      requestId,
      data: errorData,
      ...errorData,
    });
  }
);

export { apiClient };
