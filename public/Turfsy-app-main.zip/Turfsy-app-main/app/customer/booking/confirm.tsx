import React, { useRef, useEffect, useState } from 'react';
import { View, TouchableOpacity, StyleSheet, Dimensions, StatusBar, Platform, Animated, Share, Image, ScrollView, ActivityIndicator, Alert, BackHandler, Modal, TextInput, KeyboardAvoidingView } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons, MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import { useApp } from '@/src/context/AppContext';
import { BookingService } from '@/src/services/bookingService';
import { Booking } from '@/src/types/booking.types';
import { LinearGradient } from 'expo-linear-gradient';
import { SplitService, SplitDetails } from '@/src/services/splitService';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';

const { width, height } = Dimensions.get('window');

function formatDateSafe(value: any) {
  const d = new Date(value);
  return Number.isFinite(d.getTime()) ? d.toDateString() : '—';
}

export default function ConfirmScreen() {
  const { COLORS } = useApp();
  const insets = useSafeAreaInsets();
  const isDark = COLORS.isDark;
  const styles = getStyles(COLORS, insets);

  const { code, id } = useLocalSearchParams<{ code: string; id: string }>();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [split, setSplit] = useState<SplitDetails | null>(null);
  const [loading, setLoading] = useState(true);

  const scaleAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const ticketAnim = useRef(new Animated.Value(50)).current;

  // Cancellation Flow States
  const [cancelModalVisible, setCancelModalVisible] = useState(false);
  const [selectedReason, setSelectedReason] = useState('Change of plans');
  const [customReason, setCustomReason] = useState('');
  const [submittingCancellation, setSubmittingCancellation] = useState(false);

  // Race Condition Warning Modal States
  const [raceConditionModalVisible, setRaceConditionModalVisible] = useState(false);
  const [raceConditionTitle, setRaceConditionTitle] = useState('');
  const [raceConditionMessage, setRaceConditionMessage] = useState('');

  // Dynamic Refund Calculation
  const getRefundDetails = () => {
    if (!booking) {
      return { hoursUntilSlot: 0, platformFee: 0, turfPortion: 0, refundPercentage: 0, estimatedRefund: 0 };
    }

    // 1. Calculate time remaining until the slot start
    const now = new Date();
    const slotStartTime = new Date(booking.bookingDate + 'T' + booking.startTime);
    const hoursUntilSlot = (slotStartTime.getTime() - now.getTime()) / (1000 * 60 * 60);

    // 2. Identify Turf Portion (base deposit amount minus platform fee)
    const platformFee = booking.platformFee || 0;
    const turfPortion = Math.max(0, booking.depositAmount - platformFee);

    let refundPercentage = 0;
    let estimatedRefund = 0;

    if ((booking.bookingStatus as any) === 'PENDING_APPROVAL' || booking.bookingStatus === 'PENDING') {
      // Never confirmed yet, eligible for 100% refund of turf portion
      refundPercentage = 100;
      estimatedRefund = turfPortion;
    } else {
      // Confirmed booking time-based matrix
      if (hoursUntilSlot > 72) {
        refundPercentage = 100;
        estimatedRefund = turfPortion;
      } else if (hoursUntilSlot >= 24) {
        refundPercentage = 50;
        estimatedRefund = turfPortion * 0.5;
      } else {
        refundPercentage = 0;
        estimatedRefund = 0;
      }
    }

    estimatedRefund = Math.floor(estimatedRefund);

    return {
      hoursUntilSlot,
      platformFee,
      turfPortion,
      refundPercentage,
      estimatedRefund,
    };
  };

  const handleCancelBooking = async () => {
    if (!booking) return;

    const finalReason = selectedReason === 'Other' ? customReason : selectedReason;
    if (!finalReason.trim()) {
      Alert.alert('Reason Required', 'Please enter a cancellation reason.');
      return;
    }

    const now = new Date();
    const slotStartTime = new Date(booking.bookingDate + 'T' + booking.startTime);
    const hoursUntilSlot = (slotStartTime.getTime() - now.getTime()) / (1000 * 60 * 60);

    const performCancellation = async () => {
      setSubmittingCancellation(true);
      try {
        const res = await BookingService.cancelBooking(booking.id, finalReason);
        
        if (res.success) {
          setCancelModalVisible(false);
          
          // First update the local booking status
          setBooking(prev => prev ? {
            ...prev,
            bookingStatus: 'CANCELLED' as any,
            paymentStatus: (res.data?.paymentStatus || prev.paymentStatus) as any
          } : null);

          // Handle specific backend restriction/late cancellation responses
          if (res.fullCashDisabled) {
            const formattedDate = res.disabledUntil
              ? new Date(res.disabledUntil).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })
              : '';
            Alert.alert(
              'Full Cash Disabled',
              `Your Full Cash payment option has been temporarily disabled until ${formattedDate} due to repeated late cancellations.\n\nYou can continue booking using Online Payment.`
            );
          } else if (res.lateCancellation) {
            Alert.alert(
              'Booking Cancelled',
              `Booking cancelled successfully.\n\nThis was recorded as a Late Cancellation.\n\n${res.remainingBeforeRestriction} late cancellations remaining before Full Cash is temporarily disabled.`
            );
          } else if (res.resolvedBy === 'OWNER' || res.bookingStatus === 'REJECTED' || res.data?.bookingStatus === 'REJECTED') {
            const msg = res.message || 'This booking was already rejected by the venue before your cancellation was processed. Your refund has been initiated.';
            setRaceConditionTitle('Booking Already Rejected');
            setRaceConditionMessage(msg);
            setRaceConditionModalVisible(true);
            
            setBooking(prev => prev ? {
              ...prev,
              bookingStatus: 'REJECTED' as any,
              paymentStatus: (res.data?.paymentStatus || prev.paymentStatus) as any
            } : null);
          } else {
            // Scenario A: Standard / Duplicate Cancellation
            const msg = res.message || 'Booking cancelled successfully.';
            Alert.alert('Success', msg);
          }
        } else {
          Alert.alert('Error', res.message || 'Failed to cancel booking.');
        }
      } catch (err: any) {
        console.error('Cancellation request failed:', err);
        Alert.alert('Error', err.message || 'Failed to process booking cancellation.');
      } finally {
        setSubmittingCancellation(false);
      }
    };

    if (booking.paymentType === 'FULL_CASH' && hoursUntilSlot < 24) {
      Alert.alert(
        'Late Cancellation Warning',
        'This booking is within 24 hours of the scheduled time.\n\nThis cancellation will be recorded as a Late Cancellation.\n\nAfter 3 late cancellations within 90 days, your Full Cash payment option will be disabled for 30 days.\n\nDo you want to continue?',
        [
          { text: 'Go Back', style: 'cancel' },
          { 
            text: 'Cancel Booking', 
            style: 'destructive',
            onPress: performCancellation 
          }
        ]
      );
    } else {
      await performCancellation();
    }
  };

  useEffect(() => {
    const fetchDetails = async () => {
      try {
        const fetchId = id || code;
        if (!fetchId) return;

        const res = await BookingService.getBookingDetails(fetchId);
        if (res.success) {
          setBooking(res.data);
          
          // Fetch split details if booking exists
          const splitRes = await SplitService.getSplitDetails(res.data.id);
          if (splitRes.success) {
            setSplit(splitRes.data);
          }

          startAnims();
          if (Platform.OS !== 'web') {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          }
        }
      } catch (err: any) {
        console.error('Failed to fetch booking details:', err);
        const status = err?.response?.status || err?.status;
        if (status === 429) {
          Alert.alert('Too Many Requests', 'Please wait a moment before refreshing your booking details.');
        } else {
          Alert.alert('Error', 'Unable to load booking details correctly.');
        }
      } finally {
        setLoading(false);
      }
    };

    const startAnims = () => {
      Animated.parallel([
        Animated.spring(scaleAnim, { toValue: 1, tension: 50, friction: 7, useNativeDriver: true, delay: 100 }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true, delay: 200 }),
        Animated.spring(ticketAnim, { toValue: 0, tension: 40, friction: 8, useNativeDriver: true, delay: 150 })
      ]).start();
    };

    fetchDetails();

    // Prevent going back to payment/booking screen on hardware back press
    const backAction = () => {
      router.dismissAll();
      router.replace('/customer/(tabs)/home');
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      backAction
    );

    return () => backHandler.remove();
  }, [code, id]);

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  if (!booking) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 40 }]}>
        <Feather name="alert-circle" size={48} color={COLORS.textMuted} style={{ marginBottom: 16 }} />
        <Text style={{ color: COLORS.textMain, fontSize: 18, textAlign: 'center', fontWeight: '800' }}>
          Unable to load booking
        </Text>
        <Text style={{ color: COLORS.textMuted, fontSize: 14, textAlign: 'center', marginTop: 8 }}>
          The server might be busy or you've checked too many bookings recently. Please wait a moment and try again.
        </Text>
        <TouchableOpacity 
          style={{ marginTop: 24, backgroundColor: COLORS.primary, paddingHorizontal: 20, paddingVertical: 10, borderRadius: 12 }} 
          onPress={() => router.back()}
        >
          <Text style={{ color: '#000', fontWeight: 'bold' }}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const onShare = async () => {
    try {
      await Share.share({
        message: `I just booked ${booking.turf?.name} on Turfsy! My booking code is ${booking.displayId}.`,
      });
    } catch (error: any) {
      console.log(error.message);
    }
  };

        const status = (booking.bookingStatus || booking.status || '').toUpperCase();
        const isNoShow = status === 'NO_SHOW';
        const isCancelled = status === 'CANCELLED';
        const isRejected = status === 'REJECTED';
        const isPending = status === 'PENDING_APPROVAL' || status === 'PENDING';
        const isFailed = status === 'PAYMENT_FAILED' || status === 'FAILED';
        const isConfirmed = status === 'CONFIRMED' || status === 'UPCOMING';

        return (
          <View style={styles.container}>
            <StatusBar barStyle="light-content" />
            
            {/* Background Glows */}
            <View style={[styles.glow, { top: -100, right: -50, backgroundColor: COLORS.primary }]} />
            <View style={[styles.glow, { bottom: -100, left: -50, backgroundColor: COLORS.accentGreen }]} />

            <ScrollView 
              contentContainerStyle={styles.scrollContent}
              showsVerticalScrollIndicator={false}
            >
              <View style={{ width: '100%', flexDirection: 'row', justifyContent: 'flex-end', zIndex: 10 }}>
                <TouchableOpacity 
                  style={styles.closeBtn} 
                  onPress={() => {
                    router.dismissAll();
                    router.replace('/customer/(tabs)/home');
                  }}
                >
                  <Ionicons name="close" size={24} color={COLORS.textMain} />
                </TouchableOpacity>
              </View>

              <View style={styles.headerSection}>
                <Animated.View style={[styles.checkCircle, { 
                  transform: [{ scale: scaleAnim }], 
                  backgroundColor: isNoShow || isCancelled || isFailed || isRejected ? '#FF453A' : isPending ? '#FF9800' : COLORS.primary 
                }]}>
                  <Ionicons 
                    name={isNoShow ? 'close' : (isCancelled || isFailed || isRejected) ? 'alert' : isPending ? 'time' : 'checkmark'} 
                    size={48} 
                    color="#000" 
                  />
                </Animated.View>
                <Text style={styles.headerTitle}>
                  {isNoShow ? 'Booking Missed' : 
                   isCancelled ? 'Booking Cancelled' : 
                   isRejected ? 'Booking Rejected' :
                   isFailed ? 'Payment Failed' :
                   isPending ? 'Booking Pending' : 'Booking Confirmed!'}
                </Text>
                <Text style={styles.headerSubtitle}>
                  {isNoShow ? 'You did not check-in for this slot.' : 
                   isCancelled ? 'This booking has been cancelled.' : 
                   isRejected ? 'This booking was rejected by the venue.' :
                   isFailed ? 'The payment for this booking failed.' :
                   isPending ? 'Waiting for confirmation or payment completion.' : 
                   "You're all set to play."}
                </Text>
              </View>

              {/* QR Code Check-in Display */}
              {isConfirmed && booking.qrStatus && (
                <Animated.View style={[styles.qrCard, { opacity: fadeAnim }]}>
                  {booking.qrStatus === 'UPCOMING' && (
                    <View style={styles.qrContent}>
                      <Ionicons name="time-outline" size={64} color={COLORS.primary} />
                      <Text style={styles.qrMessage}>{booking.qrMessage}</Text>
                    </View>
                  )}
                  {booking.qrStatus === 'ACTIVE' && booking.qrCode && (
                    <View style={styles.qrContent}>
                      <Image source={{ uri: booking.qrCode }} style={{ width: 250, height: 250, borderRadius: 16 }} />
                      <Text style={styles.qrMessage}>{booking.qrMessage}</Text>
                    </View>
                  )}
                  {booking.qrStatus === 'COMPLETED' && (
                    <View style={styles.qrContent}>
                      <Ionicons name="checkmark-circle" size={64} color={COLORS.primary} />
                      <Text style={styles.qrMessage}>{booking.qrMessage}</Text>
                    </View>
                  )}
                  {booking.qrStatus === 'NO_SHOW' && (
                    <View style={styles.qrContent}>
                      <Ionicons name="warning" size={64} color="#FF9800" />
                      <Text style={styles.qrMessage}>{booking.qrMessage}</Text>
                    </View>
                  )}
                  {booking.qrStatus === 'EXPIRED' && (
                    <View style={styles.qrContent}>
                      <Ionicons name="close-circle" size={64} color="#FF453A" />
                      <Text style={styles.qrMessage}>{booking.qrMessage}</Text>
                    </View>
                  )}
                </Animated.View>
              )}

        {/* Ticket Component */}
        <Animated.View style={[
          styles.ticketContainer, 
          { 
            opacity: fadeAnim,
            transform: [{ translateY: ticketAnim }] 
          }
        ]}>
          <View style={styles.notchesRowTop}>
            <View style={styles.notchLeft} />
            <View style={styles.notchRight} />
          </View>

          <View style={styles.ticketContent}>
            <View style={styles.ticketTopRow}>
              <View>
                <Text style={styles.codeLabel}>BOOKING ID</Text>
                <Text style={styles.codeText}>#{booking.displayId}</Text>
              </View>
              {booking.turf?.images?.[0] ? (
                <Image source={{ uri: booking.turf.images[0] }} style={styles.turfImage} />
              ) : (
                <View style={styles.turfImagePlaceholder}>
                  <MaterialCommunityIcons name="soccer" size={32} color={COLORS.primary} />
                </View>
              )}
            </View>

            <View style={styles.divider} />

            <View style={styles.detailsSection}>
              <Text style={styles.turfNameText}>{booking.turf?.name}</Text>
              
              <View style={[styles.detailItem, { marginTop: 12 }]}>
                <View style={styles.iconCircle}>
                  <Ionicons name="calendar-outline" size={16} color={COLORS.primary} />
                </View>
                <View>
                  <Text style={styles.detailLabel}>DATE</Text>
                  <Text style={styles.detailVal}>{formatDateSafe(booking.bookingDate)}</Text>
                </View>
              </View>

              <View style={styles.detailItem}>
                <View style={styles.iconCircle}>
                  <Ionicons name="time-outline" size={16} color={COLORS.primary} />
                </View>
                <View>
                  <Text style={styles.detailLabel}>TIME SLOT</Text>
                  <Text style={styles.detailVal}>{booking.startTime} - {booking.endTime}</Text>
                </View>
              </View>

              <View style={styles.detailItem}>
                <View style={styles.iconCircle}>
                  <Ionicons name="location-outline" size={16} color={COLORS.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.detailLabel}>LOCATION</Text>
                  <Text style={styles.detailVal} numberOfLines={1}>{booking.turf?.address}</Text>
                </View>
              </View>
            </View>

            <View style={styles.priceRow}>
              <View>
                <View style={[styles.paidBadge, (isFailed || isCancelled || isRejected) && { backgroundColor: 'rgba(255, 69, 58, 0.2)' }]}>
                  <Ionicons name={isFailed || isCancelled || isRejected ? "close-circle" : "checkmark-circle"} size={14} color={isFailed || isCancelled || isRejected ? "#FF453A" : "#000"} />
                  <Text style={[styles.paidText, (isFailed || isCancelled || isRejected) && { color: "#FF453A" }]}>
                    {isFailed ? 'PAYMENT FAILED' : isCancelled ? 'CANCELLED' : isRejected ? 'REJECTED' : isPending ? (booking.paymentType === 'FULL_CASH' ? 'PAY AT TURF' : 'PAYMENT PENDING') : booking.paymentType === 'FULL_ONLINE' ? 'PAID ONLINE' : booking.paymentType === 'FULL_CASH' ? 'PAY AT TURF' : `DEPOSIT PAID (₹${booking.depositAmount})`}
                  </Text>
                </View>
                <Text style={styles.priceText}>₹{booking.amount}</Text>
                {booking.paymentType !== 'FULL_ONLINE' && typeof booking.remainingAmount === 'number' && (
                  <Text style={styles.remainingText}>Pay at venue: ₹{booking.remainingAmount}</Text>
                )}
              </View>
              <TouchableOpacity style={styles.btnShareInTicket} onPress={onShare}>
                <Ionicons name="share-social-outline" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.notchesRowBottom}>
            <View style={styles.notchLeft} />
            <View style={styles.notchRight} />
          </View>
        </Animated.View>

        {/* TEAM SPLIT FEATURE PLATE */}
        {booking?.id && (isConfirmed || status === 'COMPLETED') && (
          <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
            <LinearGradient
              colors={isDark ? ['#1A1C1E', '#0F1112'] : ['#F8FAF0', '#FFFFFF']}
              style={[styles.premiumSplitCard, { borderColor: split?.isSplitDone ? COLORS.primary : COLORS.border }]}
            >
              <View style={styles.premiumSplitHeader}>
                <View style={[styles.splitIconCircle, { backgroundColor: COLORS.primary + '15' }]}>
                  <MaterialCommunityIcons name="piggy-bank-outline" size={20} color={COLORS.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.premiumSplitTitle, { color: COLORS.textMain }]} numberOfLines={1}>
                    {split ? 'Team Settlement' : 'Split with Team'}
                  </Text>
                  <Text style={[styles.premiumSplitSub, { color: COLORS.textMuted }]} numberOfLines={2}>
                    {split 
                      ? `${split.players.length} players • ₹${split.totalAmount}`
                      : 'Distribute costs among teammates'
                    }
                  </Text>
                </View>
                {split?.isSplitDone && (
                  <Ionicons name="checkmark-done-circle" size={20} color={COLORS.primary} />
                )}
              </View>

              {split && (
                <View style={styles.progressContainer}>
                  <View style={styles.progressLabelRow}>
                    <Text style={[styles.progressLabel, { color: COLORS.textMuted }]}>
                      {split.players.filter(p => p.status === 'PAID').length} settled
                    </Text>
                    <Text style={[styles.progressPct, { color: COLORS.primary }]}>
                      {Math.round((split.players.filter(p => p.status === 'PAID').length / split.players.length) * 100)}%
                    </Text>
                  </View>
                  <View style={[styles.progressBarTrack, { backgroundColor: isDark ? '#333' : '#eee' }]}>
                    <View 
                      style={[
                        styles.progressBarFill, 
                        { 
                          width: `${(split.players.filter(p => p.status === 'PAID').length / split.players.length) * 100}%`,
                          backgroundColor: COLORS.primary 
                        }
                      ]} 
                    />
                  </View>
                </View>
              )}

              <TouchableOpacity 
                style={[styles.premiumSplitBtn, { backgroundColor: COLORS.primary }]}
                activeOpacity={0.8}
                onPress={() => router.push({ pathname: '/customer/booking/split', params: { id: booking.id } })}
              >
                <MaterialCommunityIcons name="bank-transfer" size={18} color="#000" />
                <Text style={styles.premiumSplitBtnText}>
                  {split ? 'Manage Team Split' : 'Start Team Split'}
                </Text>
              </TouchableOpacity>
            </LinearGradient>
          </Animated.View>
        )}

        {(isConfirmed || isPending || status === 'COMPLETED' || isNoShow || isCancelled || isRejected) && (
          <Animated.View style={[styles.footer, { opacity: fadeAnim }]}>
            <View style={{ gap: 12 }}>
              
              {(status === 'COMPLETED' || isNoShow || isCancelled || isRejected) && (
                <TouchableOpacity 
                  style={[styles.btnSecondary, { borderColor: COLORS.primary, borderWidth: 1.5, backgroundColor: COLORS.primary }]}
                  onPress={() => router.push({ 
                    pathname: '/customer/booking/book', 
                    params: { 
                      id: booking.turfId, 
                      rebookId: booking.id,
                      startTime: booking.startTime,
                      endTime: booking.endTime
                    } 
                  })}
                >
                  <Feather name="refresh-cw" size={20} color="#000" style={{ marginRight: 8 }} />
                  <Text style={[styles.btnSecondaryText, { color: '#000', fontWeight: '900' }]}>BOOK AGAIN</Text>
                </TouchableOpacity>
              )}

              <View style={{ flexDirection: 'row', gap: 12 }}>
                {(isConfirmed || status === 'COMPLETED') && (
                  <TouchableOpacity 
                    style={[styles.btnSecondary, { flex: 1, borderColor: COLORS.primary, borderWidth: 1.5 }]}
                    onPress={() => router.push({ pathname: '/customer/booking/split', params: { id: booking.id } })}
                  >
                    <MaterialCommunityIcons name="bank-transfer" size={18} color={COLORS.primary} style={{ marginRight: 6 }} />
                    <Text style={[styles.btnSecondaryText, { color: COLORS.primary, fontWeight: '800', fontSize: 13 }]}>SPLIT</Text>
                  </TouchableOpacity>
                )}
                
                <TouchableOpacity 
                  style={[styles.btnSecondary, { flex: 1 }]}
                  onPress={() => router.push({ pathname: '/customer/booking/invoice', params: { bookingId: booking.id } })}
                >
                  <Feather name="file-text" size={16} color={COLORS.textMain} style={{ marginRight: 6 }} />
                  <Text style={[styles.btnSecondaryText, { fontSize: 13 }]}>INVOICE</Text>
                </TouchableOpacity>
              </View>

              {(isConfirmed || isPending) && (
                <TouchableOpacity 
                  style={styles.btnCancel}
                  onPress={() => setCancelModalVisible(true)}
                  activeOpacity={0.8}
                >
                  <Ionicons name="close-circle-outline" size={20} color="#FF453A" style={{ marginRight: 8 }} />
                  <Text style={styles.btnCancelText}>Cancel Booking</Text>
                </TouchableOpacity>
              )}
            </View>
          </Animated.View>
        )}
      </ScrollView>

      {/* Cancellation Modal */}
      <Modal
        visible={cancelModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setCancelModalVisible(false)}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.modalOverlay}
        >
          <View style={styles.modalContent}>
            {/* Header */}
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Cancel Booking</Text>
              <TouchableOpacity onPress={() => setCancelModalVisible(false)} style={styles.modalCloseBtn}>
                <Ionicons name="close" size={24} color={COLORS.textMain} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.modalScrollContent}>
              {booking.paymentType === 'FULL_CASH' ? (
                <View style={styles.policyCard}>
                  <Text style={styles.policyTitle}>Cancellation Policy</Text>
                  <Text style={styles.policyBullet}>• Cancellations made within 24 hours of the slot start are recorded as Late Cancellations.</Text>
                  <Text style={styles.policyBullet}>• 3 late cancellations within 90 days will disable your Full Cash payment option for 30 days.</Text>
                </View>
              ) : (
                <>
                  {/* Section A: Policy Rules Breakdown */}
                  <View style={styles.policyCard}>
                    <Text style={styles.policyTitle}>Cancellation Policy</Text>
                    <Text style={styles.policyBullet}>• Pending Approval: 100% Refund (Excluding Platform Fee)</Text>
                    <Text style={styles.policyBullet}>• More than 72 hours before slot: 100% Refund (Excluding Platform Fee)</Text>
                    <Text style={styles.policyBullet}>• Between 24 to 72 hours before slot: 50% Refund (Excluding Platform Fee)</Text>
                    <Text style={styles.policyBullet}>• Less than 24 hours before slot: No Refund (0%)</Text>
                    <Text style={styles.policyBullet}>• Platform Fee is non-refundable in all scenarios.</Text>
                  </View>

                  {/* Section B: Dynamic Refund Estimate Card */}
                  {(() => {
                    const { hoursUntilSlot, platformFee, turfPortion, refundPercentage, estimatedRefund } = getRefundDetails();
                    const isZero = estimatedRefund <= 0;
                    const isPendingApproval = (booking.bookingStatus as any) === 'PENDING_APPROVAL' || booking.bookingStatus === 'PENDING';
                    
                    let policyApplyText = '0% Refund (Less than 24 hours remaining)';
                    if (isPendingApproval) {
                      policyApplyText = '100% Refund (Pending Approval)';
                    } else if (hoursUntilSlot > 72) {
                      policyApplyText = '100% Refund (>72 hours remaining)';
                    } else if (hoursUntilSlot >= 24) {
                      policyApplyText = '50% Refund (24–72 hours remaining)';
                    }

                    return (
                      <View style={styles.refundEstimateCard}>
                        <Text style={styles.refundEstimateTitle}>Refund Summary</Text>
                        <View style={styles.refundEstimateDivider} />
                        
                        <View style={styles.refundEstimateRow}>
                          <Text style={styles.refundEstimateLabel}>Amount Paid:</Text>
                          <Text style={styles.refundEstimateValue}>₹{(booking.depositAmount || 0).toFixed(2)}</Text>
                        </View>
                        
                        <View style={styles.refundEstimateRow}>
                          <Text style={styles.refundEstimateLabel}>Platform Fee (Non-Ref):</Text>
                          <Text style={styles.refundEstimateValue}>-₹{platformFee.toFixed(2)}</Text>
                        </View>
                        
                        <View style={styles.refundEstimateRow}>
                          <Text style={styles.refundEstimateLabel}>Turf Portion:</Text>
                          <Text style={styles.refundEstimateValue}>₹{turfPortion.toFixed(2)}</Text>
                        </View>
                        
                        <View style={styles.refundEstimateDivider} />
                        
                        <View style={styles.refundEstimateRow}>
                          <Text style={styles.refundEstimateLabelBold}>Policy Apply:</Text>
                          <Text style={styles.refundEstimateValueBold}>{policyApplyText}</Text>
                        </View>
                        
                        <View style={styles.refundEstimateRow}>
                          <Text style={styles.refundEstimateLabelBold}>Estimated Refund:</Text>
                          <Text style={[styles.refundEstimateValueHighlight, isZero && { color: '#FF9500' }]}>
                            ₹{estimatedRefund.toFixed(2)}
                          </Text>
                        </View>
                        
                        {isZero && (
                          <View style={styles.refundWarningBox}>
                            <Ionicons name="warning" size={16} color="#FF9500" style={{ marginRight: 6 }} />
                            <Text style={styles.refundWarningText}>
                              You are cancelling less than 24 hours before the slot. No refund is applicable.
                            </Text>
                          </View>
                        )}
                      </View>
                    );
                  })()}
                </>
              )}

              {/* Cancellation Reason Dropdown/Selection */}
              <View style={styles.reasonSection}>
                <Text style={styles.reasonLabel}>Select Cancellation Reason</Text>
                <View style={styles.reasonPillsContainer}>
                  {['Change of plans', 'Weather conditions', 'Booked wrong slot', 'Personal emergency', 'Other'].map((reasonOption) => {
                    const isSelected = selectedReason === reasonOption;
                    return (
                      <TouchableOpacity
                        key={reasonOption}
                        onPress={() => setSelectedReason(reasonOption)}
                        style={[styles.reasonPill, isSelected && styles.reasonPillActive]}
                      >
                        <Text style={[styles.reasonPillText, isSelected && styles.reasonPillTextActive]}>
                          {reasonOption}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>

                {selectedReason === 'Other' && (
                  <TextInput
                    style={styles.reasonTextInput}
                    placeholder="Type your cancellation reason here..."
                    placeholderTextColor={COLORS.textMuted}
                    multiline
                    value={customReason}
                    onChangeText={setCustomReason}
                    maxLength={200}
                  />
                )}
              </View>
            </ScrollView>

            {/* Confirm / Cancel Buttons */}
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalConfirmBtn, submittingCancellation && { opacity: 0.7 }]}
                onPress={handleCancelBooking}
                disabled={submittingCancellation}
              >
                {submittingCancellation ? (
                  <ActivityIndicator color="#000" size="small" />
                ) : (
                  <Text style={styles.modalConfirmBtnText} numberOfLines={1} adjustsFontSizeToFit>Confirm Cancellation</Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.modalCancelBtn}
                onPress={() => setCancelModalVisible(false)}
                disabled={submittingCancellation}
              >
                <Text style={styles.modalCancelBtnText} numberOfLines={1} adjustsFontSizeToFit>Go Back</Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Race Condition Warning Modal */}
      <Modal
        visible={raceConditionModalVisible}
        animationType="fade"
        transparent={true}
        onRequestClose={() => setRaceConditionModalVisible(false)}
      >
        <View style={styles.raceOverlay}>
          <View style={styles.raceContent}>
            <View style={styles.raceIconCircle}>
              <Ionicons name="warning-outline" size={48} color="#FF9500" />
            </View>
            <Text style={styles.raceTitle}>{raceConditionTitle}</Text>
            <Text style={styles.raceBody}>{raceConditionMessage}</Text>
            <TouchableOpacity
              style={styles.raceOkBtn}
              onPress={() => setRaceConditionModalVisible(false)}
            >
              <Text style={styles.raceOkBtnText}>Understood</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const getStyles = (COLORS: any, insets: any) => {
  const isDark = COLORS.isDark;
  const ticketFill = isDark ? '#1a2a0a' : '#7ED321';
  const notchBg = isDark ? '#0d0d0d' : '#ffffff';
  
  return StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 40,
    alignItems: 'center',
  },
  glow: {
    position: 'absolute',
    width: 300,
    height: 300,
    borderRadius: 150,
    opacity: 0.1,
  },
  closeBtn: {
    alignSelf: 'flex-end',
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  headerSection: {
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 20,
  },
  checkCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  headerTitle: {
    color: COLORS.textMain,
    fontSize: 28,
    fontWeight: '900',
    textAlign: 'center',
  },
  headerSubtitle: {
    color: COLORS.textMuted,
    fontSize: 16,
    marginTop: 8,
    textAlign: 'center',
  },
  qrCard: {
    width: '100%',
    backgroundColor: COLORS.surface,
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: COLORS.primary,
    marginTop: 10,
    marginBottom: 10,
  },
  qrContent: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  qrMessage: {
    color: COLORS.textMuted,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginTop: 8,
  },
  ticketContainer: {
    width: '100%',
    backgroundColor: ticketFill,
    borderRadius: 20,
    overflow: 'visible', // Critical for notches
    marginVertical: 20,
    borderWidth: isDark ? 1.5 : 0,
    borderColor: isDark ? '#7ED321' : 'transparent',
    // Shadow
    ...Platform.select({
      ios: {
        shadowColor: '#7ED321',
        shadowOffset: { width: 0, height: isDark ? 4 : 8 },
        shadowOpacity: isDark ? 0.15 : 0.25,
        shadowRadius: isDark ? 24 : 32,
      },
      android: {
        elevation: 12,
      },
    }),
  },
  ticketContent: {
    padding: 24,
  },
  ticketTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  codeLabel: {
    color: isDark ? '#7ED321' : '#1a4a00',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
    marginBottom: 4,
  },
  codeText: {
    color: isDark ? '#fff' : '#0d0d0d',
    fontSize: 26,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  turfImage: {
    width: 72,
    height: 72,
    borderRadius: 22,
  },
  turfImagePlaceholder: {
    width: 72,
    height: 72,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.05)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  divider: {
    height: 0,
    borderWidth: 0.75,
    borderColor: isDark ? 'rgba(174,234,0,0.25)' : 'rgba(0,0,0,0.18)',
    borderStyle: 'dashed',
    marginHorizontal: -24,
    marginBottom: 24,
    marginTop: 4,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailsSection: {
    gap: 16,
  },
  turfNameText: {
    fontSize: 24,
    fontWeight: '900',
    color: isDark ? '#fff' : '#0d0d0d',
    marginBottom: 4,
    letterSpacing: -0.5,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: isDark ? 'rgba(126, 211, 33, 0.1)' : 'rgba(0,0,0,0.05)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailLabel: {
    color: isDark ? '#7ED321' : '#1a4a00',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.5,
    marginBottom: 4,
  },
  detailVal: {
    color: isDark ? '#fff' : '#0d0d0d',
    fontSize: 16,
    fontWeight: '700',
  },
  priceRow: {
    marginTop: 32,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 24,
    borderTopWidth: 1.5,
    borderTopColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)',
  },
  priceText: {
    color: isDark ? '#fff' : '#0d0d0d',
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -1,
  },
  remainingText: {
    marginTop: 6,
    color: isDark ? 'rgba(255,255,255,0.78)' : 'rgba(0,0,0,0.55)',
    fontSize: 13,
    fontWeight: '800',
  },
  paidBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: isDark ? 'rgba(126, 211, 33, 0.2)' : 'rgba(0,0,0,0.08)',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 10,
    marginBottom: 8,
    alignSelf: 'flex-start',
  },
  paidText: {
    color: isDark ? '#7ED321' : '#0d0d0d',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  btnShareInTicket: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.1)',
  },
  notchesRowTop: {
    position: 'absolute',
    top: 136, // Manually adjusted for confirm screen content
    left: -12,
    right: -12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    zIndex: 10,
  },
  notchesRowBottom: {
    display: 'none',
  },
  notchLeft: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: notchBg,
  },
  notchRight: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: notchBg,
  },
  footer: {
    width: '100%',
    paddingHorizontal: 24,
    paddingTop: 12,
  },
  section: {
    width: '100%',
    paddingHorizontal: 24,
    marginTop: 10,
  },
  premiumSplitCard: {
    borderRadius: 24,
    borderWidth: 1.5,
    padding: 16,
    marginTop: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 3,
  },
  premiumSplitHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  splitIconCircle: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  premiumSplitTitle: {
    fontSize: 16,
    fontWeight: '900',
    marginBottom: 0,
    letterSpacing: -0.2,
  },
  premiumSplitSub: {
    fontSize: 11,
    fontWeight: '500',
    lineHeight: 14,
  },
  doneBadge: {
    width: 16,
    height: 16,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressContainer: {
    marginBottom: 16,
  },
  progressLabelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  progressLabel: {
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  progressPct: {
    fontSize: 11,
    fontWeight: '900',
  },
  progressBarTrack: {
    height: 4,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 2,
  },
  premiumSplitBtn: {
    height: 44,
    borderRadius: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 16,
  },
  premiumSplitBtnText: {
    color: '#000',
    fontSize: 13,
    fontWeight: '900',
    flex: 1,
    textAlign: 'center',
  },
  btnPrimary: {
    width: '100%',
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  btnPrimaryText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  btnSecondary: {
    height: 56,
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  btnSecondaryText: {
    color: COLORS.textMain,
    fontSize: 15,
    fontWeight: '700',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: Dimensions.get('window').height * 0.85,
    paddingBottom: Math.max(24, insets.bottom),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  modalTitle: {
    color: COLORS.textMain,
    fontSize: 20,
    fontWeight: '900',
  },
  modalCloseBtn: {
    padding: 4,
  },
  modalScrollContent: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 24,
  },
  policyCard: {
    backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.03)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 20,
  },
  policyTitle: {
    color: COLORS.textMain,
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 10,
  },
  policyBullet: {
    color: COLORS.textMuted,
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 6,
  },
  refundEstimateCard: {
    backgroundColor: isDark ? '#1a2a0a' : 'rgba(126,211,33,0.06)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    borderColor: isDark ? COLORS.primary : 'rgba(126,211,33,0.2)',
    marginBottom: 20,
  },
  refundEstimateTitle: {
    color: COLORS.textMain,
    fontSize: 15,
    fontWeight: '800',
  },
  refundEstimateDivider: {
    height: 1,
    backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)',
    marginVertical: 12,
  },
  refundEstimateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  refundEstimateLabel: {
    color: COLORS.textMuted,
    fontSize: 13,
    fontWeight: '500',
  },
  refundEstimateValue: {
    color: COLORS.textMain,
    fontSize: 13,
    fontWeight: '700',
  },
  refundEstimateLabelBold: {
    color: COLORS.textMain,
    fontSize: 14,
    fontWeight: '800',
  },
  refundEstimateValueBold: {
    color: COLORS.textMain,
    fontSize: 13,
    fontWeight: '700',
  },
  refundEstimateValueHighlight: {
    color: COLORS.primary,
    fontSize: 18,
    fontWeight: '900',
  },
  refundWarningBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 149, 0, 0.1)',
    borderRadius: 10,
    padding: 10,
    marginTop: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 149, 0, 0.2)',
  },
  refundWarningText: {
    flex: 1,
    color: '#FF9500',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
  },
  reasonSection: {
    marginBottom: 12,
  },
  reasonLabel: {
    color: COLORS.textMain,
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 12,
  },
  reasonPillsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  reasonPill: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  reasonPillActive: {
    borderColor: COLORS.primary,
    backgroundColor: isDark ? 'rgba(137,233,0,0.1)' : 'rgba(137,233,0,0.05)',
  },
  reasonPillText: {
    color: COLORS.textMuted,
    fontSize: 12,
    fontWeight: '700',
  },
  reasonPillTextActive: {
    color: COLORS.primary,
  },
  reasonTextInput: {
    backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    padding: 12,
    color: COLORS.textMain,
    minHeight: 80,
    textAlignVertical: 'top',
    fontSize: 13,
  },
  modalActions: {
    gap: 12,
    paddingHorizontal: 24,
    marginTop: 16,
    marginBottom: 8,
  },
  modalCancelBtn: {
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  modalCancelBtnText: {
    color: COLORS.textMain,
    fontSize: 14,
    fontWeight: '800',
    textAlign: 'center',
  },
  modalConfirmBtn: {
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
  },
  modalConfirmBtnText: {
    color: '#000',
    fontSize: 14,
    fontWeight: '900',
    textAlign: 'center',
  },
  btnCancel: {
    height: 56,
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 69, 58, 0.1)',
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255, 69, 58, 0.3)',
  },
  btnCancelText: {
    color: '#FF453A',
    fontSize: 15,
    fontWeight: '800',
  },
  raceOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  raceContent: {
    backgroundColor: COLORS.surface,
    borderRadius: 24,
    padding: 24,
    width: '100%',
    maxWidth: 340,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: COLORS.border,
  },
  raceIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 149, 0, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  raceTitle: {
    color: COLORS.textMain,
    fontSize: 20,
    fontWeight: '900',
    textAlign: 'center',
    marginBottom: 12,
  },
  raceBody: {
    color: COLORS.textMuted,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  raceOkBtn: {
    width: '100%',
    height: 50,
    borderRadius: 25,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  raceOkBtnText: {
    color: '#000',
    fontSize: 14,
    fontWeight: '900',
  },
});
}
