import { AppText as Text } from '@/src/components/AppText';
import { useApp } from '@/src/context/AppContext';
import { BookingService } from '@/src/services/bookingService';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Modal, Platform, ScrollView, StatusBar, StyleSheet, TouchableOpacity, View } from 'react-native';
import RazorpayCheckout from 'react-native-razorpay';
;

import { apiClient } from '@/src/api/apiClient';
import { PaymentType } from '@/src/types/booking.types';

export interface PlatformFeeSlab {
  id: string;
  minAmount: number;
  maxAmount: number;
  platformFee: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

const PAYMENT_METHODS: { id: PaymentType; label: string; sub: string; icon: any }[] = [
  { id: 'FULL_ONLINE', label: 'Full Online Payment', sub: 'Pay 100% now. Faster check-in.', icon: 'card-outline' },
  { id: 'HALF_ONLINE_HALF_CASH', label: '30% Advance & 70% Cash', sub: 'Pay 30% advance + fees now.', icon: 'cash-outline' },
  { id: 'FULL_CASH', label: 'Pay at Turf', sub: 'Pay 100% at the turf.', icon: 'wallet-outline' },
];

const calculatePlatformFee = (amount: number, slabs: PlatformFeeSlab[]) => {
  if (!slabs || slabs.length === 0) return 0; // Safe fallback

  for (const slab of slabs) {
    if (amount >= slab.minAmount && amount <= slab.maxAmount) {
      return slab.platformFee;
    }
  }

  // Fallback if no matching slab is found
  return slabs[slabs.length - 1].platformFee;
};

export default function PaymentScreen() {
  const { COLORS, pendingBooking, setPendingBooking, userProfile, userInfo } = useApp();
  const styles = getStyles(COLORS);
  const { paymentPreferences, bookingApprovalType } = useLocalSearchParams();

  const isManualApproval = bookingApprovalType === 'MANUAL';
  
  const availablePreferences = paymentPreferences 
    ? JSON.parse(paymentPreferences as string) 
    : ['FULL_ONLINE', 'ADVANCE_PAYMENT', 'FULL_CASH'];

  // Default to Pay-at-turf since online payments are not fully integrated on-device yet.
  const [selectedMethod, setSelectedMethod] = useState<PaymentType>(
    availablePreferences.includes('FULL_CASH') 
      ? 'FULL_CASH' 
      : (availablePreferences.includes('ADVANCE_PAYMENT') ? 'HALF_ONLINE_HALF_CASH' : 'FULL_ONLINE')
  );
  const [processing, setProcessing] = useState(false);
  const [feeSlabs, setFeeSlabs] = useState<PlatformFeeSlab[]>([]);

  // Full Cash Restriction State (driven entirely by backend)
  const [fullCashEnabled, setFullCashEnabled] = useState(true);
  const [fullCashDisabledUntil, setFullCashDisabledUntil] = useState<string | null>(null);
  const [fullCashDisabledReason, setFullCashDisabledReason] = useState<string | null>(null);
  const [fullCashRestrictionModal, setFullCashRestrictionModal] = useState(false);

  useEffect(() => {
    const fetchSlabs = async () => {
      try {
        const response: any = await apiClient.get('/api/v3/platform-fee-slab/active');
        const data = response?.data || response;
        if (Array.isArray(data)) {
          setFeeSlabs(data);
        }
      } catch (error) {
        console.error('[PaymentScreen] Failed to fetch platform fee slabs:', error);
      }
    };

    const fetchFullCashStatus = async () => {
      try {
        const response: any = await apiClient.get('/api/v3/booking/customer/full-cash-status');
        const data = response?.data || response;
        if (data && typeof data.fullCashEnabled === 'boolean') {
          setFullCashEnabled(data.fullCashEnabled);
          setFullCashDisabledUntil(data.disabledUntil || null);
          setFullCashDisabledReason(data.reason || null);

          // If FULL_CASH is currently selected but now disabled, auto-fallback
          if (!data.fullCashEnabled && selectedMethod === 'FULL_CASH') {
            setSelectedMethod(
              availablePreferences.includes('ADVANCE_PAYMENT') ? 'HALF_ONLINE_HALF_CASH' : 'FULL_ONLINE'
            );
          }
        }
      } catch (error) {
        console.error('[PaymentScreen] Failed to fetch full cash status:', error);
      }
    };

    fetchSlabs();
    fetchFullCashStatus();
  }, []);

  const b = pendingBooking;
  if (!b) return null;

  const groundCharge = b.totalAmount ?? 0;
  const platformFee = calculatePlatformFee(groundCharge, feeSlabs);
  const gstAmount = 0;

  const calculateBookingAmounts = (paymentType: PaymentType) => {
    const totalAmount = groundCharge + platformFee;
    const depositPercentage = 0.3; // Fixed 30% advance deposit rate

    let onlinePayable = 0;
    let remainingAtTurf = 0;
    let groundAdvance = 0;

    if (paymentType === 'FULL_ONLINE') {
      onlinePayable = totalAmount;
      remainingAtTurf = 0;
    } else if (paymentType === 'HALF_ONLINE_HALF_CASH') {
      // 30% advance calculated only on the Turf Price (groundCharge)
      groundAdvance = Math.round(groundCharge * depositPercentage);
      // Online Payable (Deposit) = Ground Advance + platformFee
      onlinePayable = groundAdvance + platformFee;
      // Remaining Cash at Turf = Turf Price - Ground Advance
      remainingAtTurf = groundCharge - groundAdvance;
    } else if (paymentType === 'FULL_CASH') {
      onlinePayable = 0;
      remainingAtTurf = totalAmount;
    }

    return {
      groundCharge,
      platformFee,
      totalAmount,
      onlinePayable,      // Amount to pay via Razorpay online
      remainingAtTurf,    // Amount to pay in cash at the turf
      groundAdvance,
    };
  };

  const { totalAmount, onlinePayable, remainingAtTurf, groundAdvance } = calculateBookingAmounts(selectedMethod);

  const getMethodSubtext = (methodId: PaymentType) => {
    const { onlinePayable: online, remainingAtTurf: turfVal, totalAmount: total } = calculateBookingAmounts(methodId);
    if (methodId === 'FULL_ONLINE') {
      return `Pay ₹${total} now. Faster check-in.`;
    } else if (methodId === 'HALF_ONLINE_HALF_CASH') {
      return `Pay ₹${online} now + ₹${turfVal} at turf.`;
    } else {
      return `Pay ₹${total} at the turf.`;
    }
  };

  const handleBookNow = async () => {
    setProcessing(true);
    try {
      // Ensure required fields exist (prevents sending malformed payloads)
      const turfId = typeof b.turfId === 'string' ? b.turfId : null;
      const bookingDate = typeof b.bookingDate === 'string' ? b.bookingDate : null;
      const startTime = typeof b.startTime === 'string' ? b.startTime : null;
      const endTime = typeof b.endTime === 'string' ? b.endTime : null;
      const durationMins = typeof b.durationMins === 'number' ? b.durationMins : null;
      if (!turfId || !bookingDate || !startTime || !endTime || !durationMins) {
        throw new Error('Missing booking details. Please go back and select your slot again.');
      }

      if (__DEV__) {
        console.log('[BOOKING] createBooking payload', {
          turfId,
          bookingDate,
          startTime,
          endTime,
          durationMins,
          paymentType: selectedMethod,
        });
      }

      // 1. Create Booking in Backend
      const res = await BookingService.createBooking({
        // Keep payload aligned with the working Postman request
        turfId,
        bookingDate,
        startTime,
        endTime,
        durationMins,
        paymentType: selectedMethod,
      });

      if (!res.success) {
        throw new Error(res.message || 'Failed to create booking');
      }

      const bookingData = res.data;

      // 2. Handle Payment Flow
      if (selectedMethod !== 'FULL_CASH' && bookingData.amountToPay > 0) {
        if (__DEV__) {
          console.log('[BOOKING] Created booking for online payment', {
            id: bookingData.id,
            paymentType: selectedMethod,
            amountToPay: bookingData.amountToPay,
          });
        }
        // Initialize Razorpay Order
        const orderRes = await BookingService.createRazorpayOrder(bookingData.id);
        
        if (!orderRes.success) {
          throw new Error('Could not initialize payment order');
        }

        const { orderId, amount, currency, keyId } = orderRes.data;

        if (Platform.OS === 'web') {
          // Fallback simulation for Web environment testing
          if (__DEV__) {
            console.log(`[RAZORPAY WEB SIMULATION] Initializing order ${orderId} for ₹${amount / 100}`);
          }
          const simulatedPaymentId = 'pay_' + Math.random().toString(36).substring(7);
          const simulatedSignature = 'sig_' + Math.random().toString(36).substring(7);

          const confirmRes = await BookingService.confirmPayment(bookingData.id, {
            razorpayOrderId: orderId,
            razorpayPaymentId: simulatedPaymentId,
            razorpaySignature: simulatedSignature,
          });

          if (confirmRes.success) {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            setPendingBooking(null);
            router.replace({ 
              pathname: '/customer/booking/confirm', 
              params: { code: bookingData.displayId, id: bookingData.id } 
            });
          } else {
            throw new Error((confirmRes as any)?.message || 'Payment confirmation failed');
          }
        } else {
          // Native Razorpay Checkout flow
          const isNativeRazorpayAvailable = RazorpayCheckout && typeof RazorpayCheckout.open === 'function';

          if (!isNativeRazorpayAvailable && __DEV__) {
            Alert.alert(
              'Razorpay Simulator (Expo Go Bypass)',
              'You are running in a environment without native Razorpay modules (like Expo Go). Would you like to simulate a successful payment?',
              [
                {
                  text: 'Simulate Failure',
                  style: 'cancel',
                  onPress: async () => {
                    try {
                      await BookingService.failOnlinePayment(bookingData.id);
                      await BookingService.cancelBooking(bookingData.id, 'Payment cancelled or failed by user.');
                    } catch (e) {
                      console.error('Failed to cancel booking after payment failure', e);
                    }
                    Alert.alert('Payment Failed', 'Simulated payment failure.');
                    setProcessing(false);
                  }
                },
                {
                  text: 'Simulate Success',
                  onPress: async () => {
                    try {
                      const simulatedPaymentId = 'pay_' + Math.random().toString(36).substring(7);
                      const simulatedSignature = 'sig_' + Math.random().toString(36).substring(7);
                      const confirmRes = await BookingService.confirmPayment(bookingData.id, {
                        razorpayOrderId: orderId,
                        razorpayPaymentId: simulatedPaymentId,
                        razorpaySignature: simulatedSignature,
                      });
                      if (confirmRes.success) {
                        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                        setPendingBooking(null);
                        router.replace({ 
                          pathname: '/customer/booking/confirm', 
                          params: { code: bookingData.displayId, id: bookingData.id } 
                        });
                      } else {
                        Alert.alert('Error', (confirmRes as any)?.message || 'Payment confirmation failed');
                      }
                    } catch (err: any) {
                      Alert.alert('Error', err.message || 'Payment confirmation failed');
                    } finally {
                      setProcessing(false);
                    }
                  }
                }
              ]
            );
            return;
          }

          const options = {
            description: 'Booking payment for Turf',
            image: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=200&auto=format&fit=crop',
            currency: currency || 'INR',
            key: keyId,
            amount: amount,
            name: 'Turfsy',
            order_id: orderId,
            prefill: {
              email: userProfile?.email || '',
              contact: userProfile?.phone || userInfo?.phone || '',
              name: userProfile?.name || ''
            },
            theme: {
              color: COLORS.primary || '#89E900'
            },
            method: {
              upi: true,
              card: false,
              netbanking: false,
              wallet: false,
              emi: false,
              paylater: false,
            },
            config: {
              display: {
                blocks: {
                  upi: {
                    name: 'Pay via UPI',
                    instruments: [
                      {
                        method: 'upi'
                      }
                    ]
                  }
                },
                sequence: ['block.upi'],
                preferences: {
                  show_default_blocks: false
                }
              }
            }
          };

          try {
            const paymentResult = await RazorpayCheckout.open(options);
            
            if (__DEV__) {
              console.log('[RAZORPAY] Native payment success:', paymentResult);
            }

            // Confirm payment on server
            const confirmRes = await BookingService.confirmPayment(bookingData.id, {
              razorpayOrderId: paymentResult.razorpay_order_id,
              razorpayPaymentId: paymentResult.razorpay_payment_id,
              razorpaySignature: paymentResult.razorpay_signature,
            });

            if (confirmRes.success) {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              setPendingBooking(null);
              router.replace({ 
                pathname: '/customer/booking/confirm', 
                params: { code: bookingData.displayId, id: bookingData.id } 
              });
            } else {
              throw new Error((confirmRes as any)?.message || 'Payment confirmation failed');
            }
          } catch (error) {
            if (__DEV__) {
              console.error('[RAZORPAY] Payment cancelled or failed', error);
            }
            // Mark payment failed on backend and cancel the booking so it doesn't stay pending
            try {
              await BookingService.failOnlinePayment(bookingData.id);
              await BookingService.cancelBooking(bookingData.id, 'Payment cancelled or failed by user.');
            } catch (e) {
              console.error('Failed to cancel booking after payment failure', e);
            }
            throw new Error('Payment cancelled or failed. Please try again.');
          }
        }
      } else {
        // For FULL_CASH or bookings with 0 to pay now, it confirmed immediately
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setPendingBooking(null);
        router.replace({ 
          pathname: '/customer/booking/confirm', 
          params: { code: bookingData.displayId, id: bookingData.id } 
        });
      }
    } catch (error: any) {
      console.error('[Booking Flow Error]', error);
      if (error?.statusCode === 401 || error?.status === 401) {
        Alert.alert('Session Expired', 'Please log in again and retry.');
        return;
      }

      if (error?.statusCode === 403 || error?.status === 403) {
        Alert.alert(
          'Payment Option Disabled',
          'Full Cash is temporarily disabled. Please choose an online payment method.',
          [{ text: 'OK', onPress: () => router.back() }]
        );
        return;
      }

      const msg = typeof error?.message === 'string'
        ? error.message
        : 'Something went wrong while processing your booking.';

      const debugHint =
        __DEV__ && (error?.requestId || error?.path)
          ? `\n\nDebug: ${String(error?.method || 'REQUEST')} ${String(error?.path || '')} (${String(error?.statusCode || error?.status || '')})${error?.requestId ? `\nrequestId: ${String(error.requestId)}` : ''}`
          : '';

      Alert.alert('Booking Restricted', `${msg}`, [
        { text: 'OK', onPress: () => router.back() }
      ]);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={22} color={COLORS.textMain} />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerSub}>CHECKOUT</Text>
          <Text style={styles.headerTitle}>Confirmation</Text>
        </View>
        <View style={{ width: 44 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>

        {/* Turf Info Card */}
        <View style={styles.turfSummary}>
          <Text style={styles.turfName}>{b.turfName}</Text>
          <Text style={styles.turfLoc} numberOfLines={1}>{b.location}</Text>
          <View style={styles.divider} />
          <View style={styles.slotDetails}>
            <View style={styles.slotItem}>
              <Ionicons name="calendar-outline" size={14} color={COLORS.primary} />
              <Text style={styles.slotText}>{b.bookingDate}</Text>
            </View>
            <View style={styles.slotItem}>
              <Ionicons name="time-outline" size={14} color={COLORS.primary} />
              <Text style={styles.slotText}>{b.startTime} - {b.endTime}</Text>
            </View>
          </View>
        </View>



        {/* Payment Methods */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>PAYMENT METHOD</Text>
          
          {availablePreferences.includes('FULL_ONLINE') && (() => {
            const m = PAYMENT_METHODS.find(m => m.id === 'FULL_ONLINE')!;
            const isActive = selectedMethod === m.id;
            return (
              <TouchableOpacity
                key={m.id}
                onPress={() => setSelectedMethod(m.id)}
                style={[styles.methodCard, isActive && styles.methodCardActive]}
                activeOpacity={0.8}
              >
                <View style={[styles.methodIcon, isActive && { backgroundColor: COLORS.primary }]}>
                  <Ionicons name={m.icon} size={22} color={isActive ? '#000' : COLORS.textMuted} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.methodLabel, isActive && { color: COLORS.textMain }]}>{m.label}</Text>
                  <Text style={styles.methodSub}>{getMethodSubtext(m.id)}</Text>
                </View>
                <View style={[styles.radio, isActive && { borderColor: COLORS.primary }]}>
                  {isActive && <View style={styles.radioIn} />}
                </View>
              </TouchableOpacity>
            );
          })()}

          {availablePreferences.includes('ADVANCE_PAYMENT') && (() => {
            const m = PAYMENT_METHODS.find(m => m.id === 'HALF_ONLINE_HALF_CASH')!;
            const isActive = selectedMethod === m.id;
            return (
              <TouchableOpacity
                key={m.id}
                onPress={() => setSelectedMethod(m.id)}
                style={[styles.methodCard, isActive && styles.methodCardActive]}
                activeOpacity={0.8}
              >
                <View style={[styles.methodIcon, isActive && { backgroundColor: COLORS.primary }]}>
                  <Ionicons name={m.icon} size={22} color={isActive ? '#000' : COLORS.textMuted} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.methodLabel, isActive && { color: COLORS.textMain }]}>{m.label}</Text>
                  <Text style={styles.methodSub}>{getMethodSubtext(m.id)}</Text>
                </View>
                <View style={[styles.radio, isActive && { borderColor: COLORS.primary }]}>
                  {isActive && <View style={styles.radioIn} />}
                </View>
              </TouchableOpacity>
            );
          })()}

          {availablePreferences.includes('FULL_CASH') && (() => {
            const m = PAYMENT_METHODS.find(m => m.id === 'FULL_CASH')!;
            const isActive = selectedMethod === m.id;
            const isRestricted = !fullCashEnabled;

            const formattedDisabledDate = fullCashDisabledUntil
              ? new Date(fullCashDisabledUntil).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })
              : null;

            return (
              <>
                <TouchableOpacity
                  key={m.id}
                  onPress={() => {
                    if (isRestricted) {
                      setFullCashRestrictionModal(true);
                      return;
                    }
                    setSelectedMethod(m.id);
                  }}
                  style={[
                    styles.methodCard,
                    isActive && !isRestricted && styles.methodCardActive,
                    isRestricted && { opacity: 0.5, borderColor: 'rgba(255,69,58,0.3)' },
                  ]}
                  activeOpacity={0.8}
                >
                  <View style={[styles.methodIcon, isActive && !isRestricted && { backgroundColor: COLORS.primary }]}>
                    {isRestricted ? (
                      <Ionicons name="lock-closed" size={22} color="#FF453A" />
                    ) : (
                      <Ionicons name={m.icon} size={22} color={isActive ? '#000' : COLORS.textMuted} />
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Text style={[styles.methodLabel, isActive && !isRestricted && { color: COLORS.textMain }]}>{m.label}</Text>
                      {isRestricted && (
                        <View style={{ backgroundColor: 'rgba(255,69,58,0.15)', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 }}>
                          <Text style={{ color: '#FF453A', fontSize: 9, fontWeight: '800' }}>RESTRICTED</Text>
                        </View>
                      )}
                    </View>
                    <Text style={styles.methodSub}>
                      {isRestricted ? 'Temporarily unavailable' : getMethodSubtext(m.id)}
                    </Text>
                  </View>
                  <View style={[styles.radio, isActive && !isRestricted && { borderColor: COLORS.primary }, isRestricted && { borderColor: 'rgba(255,69,58,0.3)' }]}>
                    {isActive && !isRestricted && <View style={styles.radioIn} />}
                    {isRestricted && <Ionicons name="lock-closed" size={10} color="#FF453A" />}
                  </View>
                </TouchableOpacity>

                {isRestricted && (
                  <View style={styles.cashRestrictionBanner}>
                    <Ionicons name="warning" size={16} color="#FF9500" />
                    <Text style={styles.cashRestrictionText}>
                      Full Cash is temporarily unavailable.
                      {fullCashDisabledReason ? ` ${fullCashDisabledReason}` : ''}
                      {formattedDisabledDate ? ` Disabled until ${formattedDisabledDate}.` : ''}
                      {' '}Please choose an online payment method.
                    </Text>
                  </View>
                )}
              </>
            );
          })()}
        </View>

        {/* Bill Details */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>BILL DETAILS</Text>
          <View style={styles.billCard}>
            
            {/* Ground Charges */}
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Ground Charges ({(b.durationMins || 60) / 60}h)</Text>
              <Text style={styles.billValue}>₹{groundCharge}</Text>
            </View>

            {/* Platform Fee */}
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Booking & Platform Fee</Text>
              <Text style={styles.billValue}>₹{platformFee}</Text>
            </View>

            {/* GST */}
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Taxes & GST (0%)</Text>
              <Text style={styles.billValue}>₹{gstAmount}</Text>
            </View>

            <View style={styles.divider} />

            {/* Grand Total */}
            <View style={styles.billRow}>
              <Text style={styles.grandTotalLabel}>Total Booking Price</Text>
              <Text style={styles.grandTotalValue}>₹{totalAmount}</Text>
            </View>

            <View style={styles.divider} />

            {/* Payment Split Info */}
            <View style={styles.splitRow}>
              <Text style={styles.splitLabel}>
                {selectedMethod === 'HALF_ONLINE_HALF_CASH' 
                  ? 'Pay Online Now (Deposit)' 
                  : selectedMethod === 'FULL_ONLINE' 
                  ? 'Pay Online Now (100%)' 
                  : 'Pay Online Now (Full Cash)'}
              </Text>
              <Text style={[styles.splitValue, selectedMethod !== 'FULL_CASH' && { color: COLORS.primary }]}>
                {selectedMethod === 'FULL_CASH' ? '₹0' : `₹${onlinePayable}`}
              </Text>
            </View>
            <View style={styles.splitRow}>
              <Text style={styles.splitLabel}>
                {selectedMethod === 'HALF_ONLINE_HALF_CASH' 
                  ? 'Pay at Turf (Cash/UPI)' 
                  : 'Pay at Venue'}
              </Text>
              <Text style={styles.splitValue}>₹{remainingAtTurf}</Text>
            </View>

            {/* Dynamic Info Box */}
            <View style={styles.infoBox}>
              <Ionicons name="information-circle" size={16} color={COLORS.primary} />
              <Text style={styles.infoText}>
                {selectedMethod === 'FULL_ONLINE' 
                  ? `You are paying the full amount of ₹${totalAmount} now. Nothing to pay at the venue.`
                  : selectedMethod === 'HALF_ONLINE_HALF_CASH'
                  ? `You will pay ₹${onlinePayable} now, and the remaining ₹${remainingAtTurf} directly at the turf.`
                  : `You will pay the full amount of ₹${totalAmount} directly at the turf. You do not need to pay anything online now.`
                }
              </Text>
            </View>
          </View>
        </View>

        {isManualApproval && (
          <View style={styles.manualApprovalBanner}>
            <Ionicons name="time-outline" size={20} color="#FF9800" />
            <Text style={styles.manualApprovalText}>
              This turf requires manual approval. Your booking slot will be held, but not confirmed until the owner accepts it.
              {selectedMethod !== 'FULL_CASH' && " (If rejected, your payment will be fully refunded within 3-5 days)."}
            </Text>
          </View>
        )}

        <View style={{ height: 140 }} />
      </ScrollView>

      {/* Pay Button */}
      <View style={styles.bottomBar}>
        <View style={{ flex: 1, marginRight: 8 }}>
          <Text style={styles.toPayLabel}>TO PAY NOW</Text>
          <Text style={styles.toPayAmt}>₹{onlinePayable}</Text>
          {selectedMethod === 'FULL_CASH' && (
            <Text style={{ color: COLORS.textMuted, fontSize: 10, fontWeight: '700', marginTop: 2 }}>
              Pay nothing online now
            </Text>
          )}
        </View>
        <TouchableOpacity
          style={[styles.payBtn, processing && { opacity: 0.7 }]}
          onPress={handleBookNow}
          disabled={processing}
          activeOpacity={0.9}
        >
          <LinearGradient colors={[COLORS.primary, '#6FC000']} style={styles.payGradient}>
            {processing ? (
              <ActivityIndicator color="#000" size="small" />
            ) : (
              <>
                <Text style={styles.payText} numberOfLines={1} adjustsFontSizeToFit>CONFIRM</Text>
                <Ionicons name="chevron-forward" size={18} color="#000" />
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Full Cash Restriction Info Modal */}
      <Modal
        visible={fullCashRestrictionModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setFullCashRestrictionModal(false)}
      >
        <View style={styles.restrictionModalOverlay}>
          <View style={styles.restrictionModalContent}>
            <View style={styles.restrictionIconCircle}>
              <Ionicons name="lock-closed" size={40} color="#FF453A" />
            </View>
            <Text style={styles.restrictionTitle}>Full Cash Disabled</Text>
            <Text style={styles.restrictionBody}>
              {fullCashDisabledReason || "Due to repeated late cancellations, your Full Cash payment option has been temporarily disabled."}
              {fullCashDisabledUntil ? `\n\nThis restriction remains active until ${new Date(fullCashDisabledUntil).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}.` : ''}
            </Text>
            <TouchableOpacity
              style={styles.restrictionOkBtn}
              onPress={() => setFullCashRestrictionModal(false)}
            >
              <Text style={styles.restrictionOkBtnText}>Understood</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 60 : 44, paddingBottom: 16,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  backBtn: { width: 44, height: 44, borderRadius: 14, backgroundColor: COLORS.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  headerSub: { color: COLORS.primary, fontSize: 10, fontWeight: '900', letterSpacing: 2 },
  headerTitle: { color: COLORS.textMain, fontSize: 18, fontWeight: '800' },
  scrollContent: { paddingBottom: 20 },

  turfSummary: { margin: 20, padding: 20, backgroundColor: COLORS.surface, borderRadius: 24, borderWidth: 1, borderColor: COLORS.border },
  turfName: { color: COLORS.textMain, fontSize: 20, fontWeight: '800', marginBottom: 4 },
  turfLoc: { color: COLORS.textMuted, fontSize: 13, marginBottom: 16 },
  divider: { height: 1, backgroundColor: COLORS.border, marginVertical: 12 },
  slotDetails: { flexDirection: 'row', gap: 20 },
  slotItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  slotText: { color: COLORS.textMain, fontSize: 13, fontWeight: '600' },
  
  nudgeCard: {
    margin: 20,
    marginTop: 0,
    padding: 16,
    backgroundColor: COLORS.surface,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: COLORS.kiwi,
    flexDirection: 'row',
    gap: 16,
    alignItems: 'center',
  },
  nudgeIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(137,233,0,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  nudgeTitle: { color: COLORS.textMain, fontSize: 16, fontWeight: '800' },
  nudgeText: { color: COLORS.textMuted, fontSize: 13, marginTop: 4, lineHeight: 18, opacity: 0.9 },
  nudgeBtnRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 },
  nudgeBtn: { color: COLORS.kiwi, fontSize: 14, fontWeight: '800' },

  section: { paddingHorizontal: 20, marginTop: 20 },
  sectionLabel: { color: COLORS.textMuted, fontSize: 10, fontWeight: '900', letterSpacing: 2, marginBottom: 12 },

  methodCard: { 
    flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.surface, 
    borderRadius: 20, padding: 16, marginBottom: 12, borderWidth: 1.5, borderColor: COLORS.border, gap: 14 
  },
  methodCardActive: { borderColor: COLORS.primary, backgroundColor: 'rgba(137,233,0,0.02)' },
  methodIcon: { width: 46, height: 46, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.05)', justifyContent: 'center', alignItems: 'center' },
  methodLabel: { color: COLORS.textMuted, fontSize: 15, fontWeight: '700' },
  methodSub: { color: COLORS.textMuted, fontSize: 12, marginTop: 2 },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: COLORS.textMuted, justifyContent: 'center', alignItems: 'center' },
  radioIn: { width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.primary },

  billCard: { backgroundColor: COLORS.surface, borderRadius: 24, padding: 20, borderWidth: 1, borderColor: COLORS.border },
  billRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  billLabel: { color: COLORS.textMuted, fontSize: 13, fontWeight: '500' },
  billValue: { color: COLORS.textMain, fontSize: 13, fontWeight: '700' },
  grandTotalLabel: { color: COLORS.textMain, fontSize: 16, fontWeight: '800' },
  grandTotalValue: { color: COLORS.primary, fontSize: 20, fontWeight: '900' },
  splitRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  splitLabel: { flex: 1, color: COLORS.textMuted, fontSize: 13, fontWeight: '600', marginRight: 8 },
  splitValue: { color: COLORS.textMain, fontSize: 14, fontWeight: '800' },
  infoBox: { flexDirection: 'row', gap: 8, marginTop: 16, backgroundColor: 'rgba(137,233,0,0.08)', padding: 14, borderRadius: 16 },
  infoText: { flex: 1, color: COLORS.textMuted, fontSize: 12, lineHeight: 18, fontWeight: '500' },
  
  manualApprovalBanner: {
    marginHorizontal: 20, marginTop: 20, padding: 14,
    backgroundColor: 'rgba(255, 152, 0, 0.1)', borderRadius: 16,
    borderWidth: 1.5, borderColor: 'rgba(255, 152, 0, 0.4)',
    flexDirection: 'row', gap: 10, alignItems: 'center'
  },
  manualApprovalText: {
    flex: 1, color: '#FF9800', fontSize: 12, lineHeight: 18, fontWeight: '600'
  },

  cashRestrictionBanner: {
    marginTop: -4, marginBottom: 12, marginHorizontal: 4, padding: 12,
    backgroundColor: 'rgba(255, 149, 0, 0.08)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(255, 149, 0, 0.2)',
    flexDirection: 'row', gap: 8, alignItems: 'flex-start'
  },
  cashRestrictionText: {
    flex: 1, color: '#FF9500', fontSize: 11, lineHeight: 16, fontWeight: '600'
  },

  restrictionModalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center', alignItems: 'center', padding: 24,
  },
  restrictionModalContent: {
    backgroundColor: COLORS.surface, borderRadius: 24, padding: 24,
    width: '100%', maxWidth: 340, alignItems: 'center',
    borderWidth: 1.5, borderColor: COLORS.border,
  },
  restrictionIconCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(255, 69, 58, 0.1)',
    justifyContent: 'center', alignItems: 'center', marginBottom: 20,
  },
  restrictionTitle: {
    color: COLORS.textMain, fontSize: 20, fontWeight: '900',
    textAlign: 'center', marginBottom: 12,
  },
  restrictionBody: {
    color: COLORS.textMuted, fontSize: 14, textAlign: 'center',
    lineHeight: 20, marginBottom: 24,
  },
  restrictionOkBtn: {
    width: '100%', height: 50, borderRadius: 25,
    backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center',
  },
  restrictionOkBtnText: {
    color: '#000', fontSize: 14, fontWeight: '900',
  },

  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: COLORS.background, paddingHorizontal: 20,
    paddingTop: 16, paddingBottom: Platform.OS === 'ios' ? 40 : 24,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderTopWidth: 1.2, borderTopColor: COLORS.border,
  },
  toPayLabel: { color: COLORS.textMuted, fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  toPayAmt: { color: COLORS.textMain, fontSize: 26, fontWeight: '900' },
  payBtn: { flex: 1, borderRadius: 20, overflow: 'hidden', marginLeft: 12 },
  payGradient: { height: 60, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingHorizontal: 12 },
  payText: { color: '#000', fontWeight: '900', fontSize: 15 },
});
