import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Dimensions, Platform, StatusBar, ActivityIndicator, Alert } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/src/context/AppContext';
import { BookingService, AvailabilityResponse } from '@/src/services/bookingService';
import { TurfService } from '@/src/services/turfService';
import DateTimePicker from '@react-native-community/datetimepicker';

const { width } = Dimensions.get('window');

const MINUTES_IN_DAY = 24 * 60;
const MIN_BOOKING_MINS = 30;
const ADVANCE_CUTOFF_MINS = 30; // Must book at least 30 min before start time

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SLOT STATUS ENUM
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
type SlotStatus = 'AVAILABLE' | 'BOOKED' | 'UNAVAILABLE' | 'LOCKED';

type OperatingWindow =
  | { mode: '24H'; openMins: number; closeMins: number; stepMins: number }
  | { mode: 'NORMAL'; openMins: number; closeMins: number; stepMins: number }
  | { mode: 'OVERNIGHT'; openMins: number; closeMins: number; stepMins: number };

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// TIME UTILITIES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function parseTimeToMinutes(t: string): number | null {
  const [hhRaw, mmRaw] = (t || '').split(':');
  const hh = Number(hhRaw);
  const mm = Number(mmRaw);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return hh * 60 + mm;
}

function minutesToTime(m: number): string {
  const normalized = ((m % MINUTES_IN_DAY) + MINUTES_IN_DAY) % MINUTES_IN_DAY;
  const hh = Math.floor(normalized / 60);
  const mm = normalized % 60;
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

function getSlotStepMins(openTime: string, closeTime: string, minSlotDurationMins?: number): number {
  if (minSlotDurationMins) return minSlotDurationMins;
  const openMinPart = openTime?.split(':')[1] ?? '00';
  const closeMinPart = closeTime?.split(':')[1] ?? '00';
  return openMinPart === '00' && closeMinPart === '00' ? 60 : 30;
}

function buildOperatingWindow(openTime: string, closeTime: string, minSlotDurationMins?: number): OperatingWindow | null {
  const openMins = parseTimeToMinutes(openTime);
  const closeMins = parseTimeToMinutes(closeTime);
  if (openMins == null || closeMins == null) return null;
  const stepMins = getSlotStepMins(openTime, closeTime, minSlotDurationMins);
  if (openMins === closeMins) return { mode: '24H', openMins, closeMins, stepMins };
  if (openMins < closeMins) return { mode: 'NORMAL', openMins, closeMins, stepMins };
  return { mode: 'OVERNIGHT', openMins, closeMins, stepMins };
}

function generateTimeSlots(openTime: string, closeTime: string, minSlotDurationMins?: number): string[] {
  const window = buildOperatingWindow(openTime, closeTime, minSlotDurationMins);
  if (!window) return [];
  const step = Math.max(15, window.stepMins);
  const slots: string[] = [];
  const pushRange = (start: number, endExclusive: number) => {
    for (let t = start; t < endExclusive; t += step) {
      slots.push(minutesToTime(t));
    }
  };
  if (window.mode === '24H') { pushRange(0, MINUTES_IN_DAY); return slots; }
  if (window.mode === 'NORMAL') { pushRange(window.openMins, window.closeMins); return slots; }
  // OVERNIGHT: open -> midnight, then midnight -> close
  pushRange(window.openMins, MINUTES_IN_DAY);
  pushRange(0, window.closeMins);
  return slots;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STEP 1: CONVERT SLOT TO DateTime
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
/**
 * Converts a slot time string to a full DateTime object.
 * For OVERNIGHT windows:
 *   - Slots >= openTime → same calendar day as bookingDay
 *   - Slots < openTime (e.g. 00:00-04:59 for a turf opening at 06:00) → next calendar day
 */
function slotToDateTime(bookingDay: Date, slotTime: string, opWindow: OperatingWindow | null): Date | null {
  const mins = parseTimeToMinutes(slotTime);
  if (mins == null) return null;

  const dt = new Date(bookingDay.getFullYear(), bookingDay.getMonth(), bookingDay.getDate());

  // For overnight windows, times before the opening time belong to the next calendar day
  if (opWindow?.mode === 'OVERNIGHT' && mins < opWindow.openMins) {
    dt.setDate(dt.getDate() + 1);
  }

  dt.setHours(Math.floor(mins / 60), mins % 60, 0, 0);
  return dt;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STEP 2 + 3 + 4: COMPUTE SLOT STATUS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
interface BookedSlot {
  startTime: string;
  endTime: string;
  isExpired?: boolean;
}

interface SlotInfo {
  time: string;
  status: SlotStatus;
  bookedRange?: { startTime: string; endTime: string }; // Only set when status === BOOKED
}

function computeSlotStatuses(args: {
  slots: string[];
  bookingDay: Date;
  opWindow: OperatingWindow | null;
  bookedSlots: BookedSlot[];
  isToday: boolean;
  now: Date;
}): SlotInfo[] {
  const { slots, bookingDay, opWindow, bookedSlots, isToday, now } = args;
  const stepMins = opWindow?.stepMins || 60;
  const cutoffTime = new Date(now.getTime() + ADVANCE_CUTOFF_MINS * 60 * 1000);

  // Pre-convert all booked ranges to DateTime pairs (skip synthetic expired ones)
  const realBookings = bookedSlots
    .filter(b => !b.isExpired)
    .map(b => ({
      raw: b,
      start: slotToDateTime(bookingDay, b.startTime, opWindow),
      end: slotToDateTime(bookingDay, b.endTime, opWindow),
    }))
    .filter(b => b.start != null && b.end != null) as {
      raw: BookedSlot;
      start: Date;
      end: Date;
    }[];

  return slots.map(slot => {
    const slotDt = slotToDateTime(bookingDay, slot, opWindow);
    if (!slotDt) return { time: slot, status: 'AVAILABLE' as SlotStatus };

    const slotEndDt = new Date(slotDt.getTime() + stepMins * 60 * 1000);

    // ── STEP 3: Check BOOKED first (highest priority) ──
    for (const booking of realBookings) {
      // Overlap check: slotStart < bookingEnd AND slotEnd > bookingStart
      if (slotDt.getTime() < booking.end.getTime() && slotEndDt.getTime() > booking.start.getTime()) {
        return {
          time: slot,
          status: 'BOOKED' as SlotStatus,
          bookedRange: { startTime: booking.raw.startTime, endTime: booking.raw.endTime },
        };
      }
    }

    // ── STEP 2: Check UNAVAILABLE / LOCKED (only for today) ──
    if (isToday) {
      // If slot is already past → UNAVAILABLE
      if (slotDt.getTime() <= now.getTime()) {
        return { time: slot, status: 'UNAVAILABLE' as SlotStatus };
      }
      // If slot is within 30-min cutoff → LOCKED
      if (slotDt.getTime() <= cutoffTime.getTime()) {
        return { time: slot, status: 'LOCKED' as SlotStatus };
      }
    }

    // ── STEP 4: Otherwise AVAILABLE ──
    return { time: slot, status: 'AVAILABLE' as SlotStatus };
  });
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// DURATION + OVERLAP HELPERS (for End Time selection)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function toOperatingMinutes(time: string, window: OperatingWindow | null): number | null {
  const mins = parseTimeToMinutes(time);
  if (mins == null) return null;
  if (!window) return mins;
  if (window.mode === '24H') return mins;
  if (window.mode === 'NORMAL') {
    if (mins < window.openMins || mins > window.closeMins) return null;
    return mins;
  }
  // OVERNIGHT
  if (mins >= window.openMins) return mins;
  if (mins <= window.closeMins) return mins + MINUTES_IN_DAY;
  return null;
}

function computeDurationMins(startTime: string, endTime: string, window: OperatingWindow | null): number | null {
  const startLin = toOperatingMinutes(startTime, window);
  let endLin = toOperatingMinutes(endTime, window);
  if (startLin == null || endLin == null) return null;
  if (endLin < startLin) endLin += MINUTES_IN_DAY;
  const duration = endLin - startLin;
  if (duration <= 0) return null;
  return duration;
}

function maxOpenMinutesFromStart(startTime: string, window: OperatingWindow | null): number | null {
  if (!window) return null;
  const startMins = parseTimeToMinutes(startTime);
  if (startMins == null) return null;
  if (window.mode === '24H') return MINUTES_IN_DAY;
  if (window.mode === 'NORMAL') {
    if (startMins < window.openMins || startMins >= window.closeMins) return 0;
    return window.closeMins - startMins;
  }
  // OVERNIGHT
  const inA = startMins >= window.openMins;
  const inB = startMins < window.closeMins;
  if (!inA && !inB) return 0;
  if (inB) return window.closeMins - startMins;
  return (MINUTES_IN_DAY - startMins) + window.closeMins;
}

function hasBookingOverlap(args: {
  window: OperatingWindow | null;
  startTime: string;
  endTime: string;
  bookedSlots: BookedSlot[];
}): boolean {
  const startLin = toOperatingMinutes(args.startTime, args.window);
  let endLin = toOperatingMinutes(args.endTime, args.window);
  if (startLin == null || endLin == null) return false;
  if (endLin < startLin) endLin += MINUTES_IN_DAY;
  for (const s of args.bookedSlots) {
    if (s.isExpired) continue; // Skip synthetic expired slots
    const bStart = toOperatingMinutes(s.startTime, args.window);
    let bEnd = toOperatingMinutes(s.endTime, args.window);
    if (bStart == null || bEnd == null) continue;
    if (bEnd < bStart) bEnd += MINUTES_IN_DAY;
    if (Math.max(startLin, bStart) < Math.min(endLin, bEnd)) return true;
  }
  return false;
}

function addMinutesToTime(time: string, addMins: number): string | null {
  const startMins = parseTimeToMinutes(time);
  if (startMins == null) return null;
  return minutesToTime(startMins + addMins);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CALENDAR + FORMAT HELPERS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function getCalendarDays(): { day: string; date: Date; label: string; fullDate: string; month: string }[] {
  const days = [];
  const now = new Date();
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  // Support 90 days advance booking (0 to 90 days = 91 total days)
  for (let i = 0; i <= 90; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() + i);
    days.push({
      day: weekDays[d.getDay()],
      date: d,
      label: d.getDate().toString(),
      month: monthNames[d.getMonth()],
      fullDate: formatDate(d),
    });
  }
  return days;
}

function formatDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MAIN COMPONENT
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export default function BookScreen() {
  const { COLORS, userProfile, showStatusModal } = useApp();
  const styles = getStyles(COLORS);

  const { id, rebookId, startTime: preStart, endTime: preEnd } = useLocalSearchParams<{ 
    id: string; 
    rebookId?: string; 
    startTime?: string; 
    endTime?: string;
  }>();
  const [turf, setTurf] = useState<any>(null);
  const { setPendingBooking } = useApp();

  const days = useMemo(() => getCalendarDays(), []);
  const [selectedDay, setSelectedDay] = useState(0);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [startTime, setStartTime] = useState<string | null>(preStart || null);
  const [endTime, setEndTime] = useState<string | null>(preEnd || null);
  const [sport, setSport] = useState<string>('');
  const [showEarlierSlots, setShowEarlierSlots] = useState(false);

  const [availability, setAvailability] = useState<AvailabilityResponse['data'] | null>(null);
  const [loading, setLoading] = useState(true);
  const [isQuickBooking, setIsQuickBooking] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);

  // Live clock: updates every 30 seconds so time-based status is always fresh
  const [nowTick, setNowTick] = useState(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setNowTick(new Date()), 30_000);
    return () => clearInterval(timer);
  }, []);

  const operatingWindow = useMemo(() => {
    if (!availability) return null;
    return buildOperatingWindow(availability.openTime, availability.closeTime, turf?.minSlotDurationMins);
  }, [availability?.openTime, availability?.closeTime, turf?.minSlotDurationMins]);

  const fetchAvailability = useCallback(async () => {
    try {
      const date = formatDate(days[selectedDay].date);
      const availRes = await BookingService.getAvailability(id!, date);
      if (availRes.success) {
        setAvailability(availRes.data);
      }
    } catch (err) {
      console.error('Fetch Availability Error:', err);
    }
  }, [id, selectedDay, days]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        if (!turf) {
          const res: any = await TurfService.getTurfDetails(id!);
          if (res && (res.success || res.id)) {
            const turfData = res.success ? res.data : res;
            setTurf(turfData);
            setSport(turfData.sportsType);
          }
        }
        await fetchAvailability();
      } catch (err: any) {
        console.error('Fetch Error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id, selectedDay]);

  // ── Generate raw time slot strings ──
  const timeSlots = useMemo(() => {
    if (!availability) return [];
    return generateTimeSlots(availability.openTime, availability.closeTime, turf?.minSlotDurationMins);
  }, [availability, turf?.minSlotDurationMins]);

  // ── CORE: Compute status for every slot using DateTime comparison ──
  const slotStatuses = useMemo(() => {
    if (!availability || timeSlots.length === 0) return [];
    return computeSlotStatuses({
      slots: timeSlots,
      bookingDay: days[selectedDay].date,
      opWindow: operatingWindow,
      bookedSlots: availability.bookedSlots || [],
      isToday: selectedDay === 0,
      now: nowTick,
    });
  }, [availability, timeSlots, operatingWindow, selectedDay, nowTick, days]);

  const availableSlotsCount = useMemo(() => {
    return slotStatuses.filter(s => s.status === 'AVAILABLE').length;
  }, [slotStatuses]);

  const bookedSlotsCount = useMemo(() => {
    return slotStatuses.filter(s => s.status === 'BOOKED').length;
  }, [slotStatuses]);

  // ── Auto-clear stale startTime if it becomes unavailable ──
  useEffect(() => {
    if (!startTime || slotStatuses.length === 0) return;
    const info = slotStatuses.find(s => s.time === startTime);
    if (info && info.status !== 'AVAILABLE') {
      setStartTime(null);
      setEndTime(null);
    }
  }, [slotStatuses]);

  const getPriceForSlot = (slot: string) => {
    if (!availability || !availability.pricing) return turf?.weekdayDayPrice || 1200;
    const hour = parseInt(slot.split(':')[0]);
    const nightStart = parseInt(availability.pricing.nightStartsAt.split(':')[0]);
    return hour >= nightStart ? availability.pricing.nightPrice : availability.pricing.dayPrice;
  };

  const durationMins = useMemo(() => {
    if (!startTime || !endTime) return null;
    return computeDurationMins(startTime, endTime, operatingWindow);
  }, [startTime, endTime, operatingWindow]);

  const isNextDay = useMemo(() => {
    if (!startTime || !endTime) return false;
    const s = parseTimeToMinutes(startTime);
    const e = parseTimeToMinutes(endTime);
    if (s == null || e == null) return false;
    return e < s;
  }, [startTime, endTime]);

  const selectionError = useMemo(() => {
    if (selectedDay > 90) return 'Cannot book slots beyond the 90-day window.';
    if (!availability) return null;
    if (!operatingWindow) return 'Operating hours unavailable.';
    if (!startTime || !endTime) return null;
    if (startTime === endTime) return 'Start and end time cannot be the same.';
    const duration = computeDurationMins(startTime, endTime, operatingWindow);
    if (duration == null) return 'Invalid time selection.';
    if (duration < MIN_BOOKING_MINS) return `Minimum booking is ${MIN_BOOKING_MINS} mins.`;
    const maxMins = maxOpenMinutesFromStart(startTime, operatingWindow);
    if (maxMins == null || maxMins <= 0) return 'Selected start time is outside operating hours.';
    if (duration > maxMins) return 'Selected duration goes beyond closing time.';
    const overlaps = hasBookingOverlap({
      window: operatingWindow,
      startTime,
      endTime,
      bookedSlots: availability.bookedSlots || [],
    });
    if (overlaps) return 'Selected slot overlaps with an existing booking.';
    return null;
  }, [availability, operatingWindow, startTime, endTime, selectedDay]);

  const total = useMemo(() => {
    if (!availability) return turf?.weekdayDayPrice || 0;
    if (!startTime || !endTime || !durationMins || selectionError) return 0;
    const step = operatingWindow?.stepMins === 60 ? 60 : 30;
    const chunks = Math.ceil(durationMins / step);
    let sum = 0;
    for (let i = 0; i < chunks; i++) {
      const t = addMinutesToTime(startTime, i * step) || startTime;
      const pricePerHour = getPriceForSlot(t);
      sum += pricePerHour * (step / 60);
    }
    return Math.round(sum);
  }, [availability, turf, startTime, endTime, durationMins, selectionError, operatingWindow]);

  // ── Loading / Error guards ──
  if (!turf && loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }
  if (!turf && !loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 40 }]}>
        <Ionicons name="alert-circle-outline" size={48} color={COLORS.textMuted} />
        <Text style={{ color: COLORS.textMain, marginTop: 12, textAlign: 'center' }}>Turf details not found.</Text>
        <TouchableOpacity style={{ marginTop: 20 }} onPress={() => router.back()}>
          <Text style={{ color: COLORS.primary }}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const canContinue = startTime !== null && endTime !== null && !loading && !selectionError;

  const handleContinue = () => {
    if (!startTime || !endTime || !availability) return;
    if (selectionError) { Alert.alert('Error', selectionError); return; }

    const duration = durationMins;
    if (!duration) return;
    if (rebookId) {
      // For rebooking, we can directly call rebook API if they choose a standard flow
      // or we can just proceed to payment. Usually rebook follows a specific path.
      // Based on instructions, we'll implement the rebook call.
      handleQuickBook(); // Rebook often implies direct confirmation for the same slots
      return;
    }
    
    setIsNavigating(true);
    setPendingBooking({
      turfId: id,
      turfName: turf.name,
      turfImage: turf.entranceUrl || turf.groundDayUrl || (turf.images && turf.images[0]),
      location: turf.address || turf.city,
      bookingDate: formatDate(days[selectedDay].date),
      startTime,
      endTime,
      durationMins: duration,
      totalAmount: total,
    });
    router.push({ 
      pathname: '/customer/booking/payment',
      params: { 
        paymentPreferences: JSON.stringify(turf?.paymentPreferences || []),
        bookingApprovalType: turf?.bookingApprovalType || 'INSTANT'
      }
    });
    setTimeout(() => setIsNavigating(false), 1000);
  };

  const handleQuickBook = async () => {
    if (!startTime || !endTime || !availability) return;
    if (selectionError) { Alert.alert('Selection Error', selectionError); return; }



    setIsQuickBooking(true);
    try {
      const duration = durationMins;
      if (!duration) throw new Error('Could not compute duration.');
      
      let res;
      if (rebookId) {
        res = await BookingService.rebook(rebookId, {
          bookingDate: formatDate(days[selectedDay].date),
          startTime: startTime!,
          paymentType: 'FULL_CASH'
        });
      } else {
        res = await BookingService.quickPayAtTurf({
          turfId: id!,
          bookingDate: formatDate(days[selectedDay].date),
          startTime,
          endTime,
          durationMins: duration,
        });
      }
      
      if (res.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace({
          pathname: '/customer/booking/confirm',
          params: { code: res.data.displayId, id: res.data.id }
        });
      } else {
        throw res;
      }
    } catch (err: any) {
      console.error('[Quick Book Error]', err);
      const msg = err?.message || 'Quick book failed';
      Alert.alert('Booking Restricted', msg, [
        { text: 'OK', onPress: () => { fetchAvailability(); } }
      ]);
    } finally {
      setIsQuickBooking(false);
    }
  };

  const handleDatePicked = (event: any, selectedDate?: Date) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (event.type === 'set' || event.type === 'dismissed') {
      setShowDatePicker(false);
    }
    if (selectedDate) {
      const targetStr = formatDate(selectedDate);
      const foundIndex = days.findIndex(d => d.fullDate === targetStr);
      if (foundIndex !== -1) {
        setSelectedDay(foundIndex);
        setStartTime(null);
        setEndTime(null);
        setShowEarlierSlots(false);
      } else {
        Alert.alert('Invalid Date', 'Selected date is outside the allowed booking window.');
      }
    }
  };

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // RENDER
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backBtn}
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            router.back();
          }}
        >
          <Ionicons name="arrow-back" size={22} color={COLORS.textMain} />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerSub}>{rebookId ? 'REBOOKING' : 'BOOKING'}</Text>
          <Text style={styles.headerTitle}>{turf.name}</Text>
        </View>
        <View style={{ width: 44 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>

        {/* Date Picker */}
        <View style={styles.section}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <Text style={[styles.sectionLabel, { marginBottom: 0 }]}>SELECT DATE</Text>
            <TouchableOpacity onPress={() => setShowDatePicker(true)} style={{ padding: 4 }}>
              <Ionicons name="calendar" size={20} color={COLORS.primary} />
            </TouchableOpacity>
          </View>
          
          {showDatePicker && (
            <DateTimePicker
              value={days[selectedDay]?.date || new Date()}
              mode="date"
              display="default"
              minimumDate={days[0]?.date}
              maximumDate={days[days.length - 1]?.date}
              onChange={handleDatePicked}
            />
          )}

          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.dateScrollContent}>
            {days.map((d, i) => {
              const isSelected = selectedDay === i;
              const isToday = i === 0;
              return (
                <TouchableOpacity
                  key={i}
                  onPress={() => {
                    setSelectedDay(i);
                    setStartTime(null);
                    setEndTime(null);
                    setShowEarlierSlots(false);
                  }}
                  style={[styles.dayCard, isSelected && styles.dayCardActive]}
                >
                  <Text style={[styles.dayName, isSelected && styles.dayNameActive]}>
                    {isToday ? 'Today' : d.day}
                  </Text>
                  <View style={[styles.dayNumContainer, isSelected && styles.dayNumContainerActive]}>
                    <Text style={[styles.dayNum, isSelected && styles.dayNumActive]}>{d.label}</Text>
                  </View>
                  <Text style={[styles.dayMonth, isSelected && styles.dayMonthActive]}>
                    {d.month}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* ━━━━ TIME SLOTS ━━━━ */}
        <View style={styles.section}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <Text style={[styles.sectionLabel, { marginBottom: 0 }]}>SELECT TIME</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              {operatingWindow?.mode === '24H' && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>Open 24/7</Text>
                </View>
              )}
              {operatingWindow?.mode === 'OVERNIGHT' && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>Overnight</Text>
                </View>
              )}
              {loading && <ActivityIndicator size="small" color={COLORS.primary} />}
            </View>
          </View>

          {/* ── START TIME ── */}
          <Text style={styles.subLabel}>START TIME</Text>

          {availableSlotsCount === 0 && !loading ? (
            <View style={styles.noSlotsCard}>
              <View style={styles.noSlotsIconContainer}>
                <Ionicons name="alert-circle-outline" size={24} color="#ff6b6b" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.noSlotsTitle}>
                  {selectedDay === 0
                    ? bookedSlotsCount > 0
                      ? 'Fully Booked Today'
                      : 'Closed Today / Operating Hours Ended'
                    : bookedSlotsCount > 0
                    ? 'Fully Booked'
                    : 'Closed / No Slots Available'}
                </Text>
                <Text style={styles.noSlotsMessage}>
                  {selectedDay === 0
                    ? bookedSlotsCount > 0
                      ? 'All slots for today have been fully booked. Please select a different date from the calendar above!'
                      : "Today's operating hours have ended or the turf is closed. Please select a different date from the calendar above!"
                    : bookedSlotsCount > 0
                    ? 'All slots for this date have been booked. Please choose another date.'
                    : 'The turf is closed or has no operating hours on this date. Please select another date.'}
                </Text>
              </View>
            </View>
          ) : (
            <>
              {selectedDay === 0 && !showEarlierSlots && (
                <TouchableOpacity 
                  style={styles.showEarlierBtn} 
                  onPress={() => setShowEarlierSlots(true)}
                >
                  <Ionicons name="time-outline" size={12} color={COLORS.primary} />
                  <Text style={styles.showEarlierText}>Show earlier unavailable slots</Text>
                </TouchableOpacity>
              )}

              <View style={styles.slotsGrid}>
                {slotStatuses.map(info => {
                  const { time: slot, status, bookedRange } = info;
                  const isSelected = startTime === slot;
                  const isDisabled = status !== 'AVAILABLE';

                  // Hide past slots on today if not toggled
                  if (selectedDay === 0 && !showEarlierSlots && (status === 'UNAVAILABLE' || status === 'LOCKED')) {
                    return null;
                  }

                  return (
                    <TouchableOpacity
                      key={`start-${slot}`}
                      disabled={isDisabled || loading}
                      activeOpacity={isDisabled ? 1 : 0.7}
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                        setStartTime(slot);
                        setEndTime(null);
                      }}
                      style={[
                        styles.slotBtn,
                        isSelected && styles.slotBtnActive,
                        status === 'BOOKED' && !isSelected && styles.slotBtnBooked,
                        (status === 'UNAVAILABLE' || status === 'LOCKED') && !isSelected && styles.slotBtnUnavailable,
                      ]}
                    >
                      <Text style={[
                        styles.slotText,
                        isSelected && styles.slotTextActive,
                        status === 'BOOKED' && !isSelected && styles.slotTextBooked,
                        (status === 'UNAVAILABLE' || status === 'LOCKED') && !isSelected && styles.slotTextUnavailable,
                      ]}>
                        {status === 'BOOKED' && bookedRange
                          ? `${bookedRange.startTime} - ${bookedRange.endTime}`
                          : slot}
                      </Text>

                      {/* Status label */}
                      {status === 'BOOKED' && (
                        <View style={styles.statusRow}>
                          <Ionicons name="close-circle" size={12} color="#ff6b6b" />
                          <Text style={styles.statusLabelBooked}>Booked</Text>
                        </View>
                      )}
                      {status === 'UNAVAILABLE' && (
                        <View style={styles.statusRow}>
                          <Ionicons name="time-outline" size={11} color={COLORS.textMuted} />
                          <Text style={styles.statusLabelMuted}>Unavailable</Text>
                        </View>
                      )}
                      {status === 'LOCKED' && (
                        <View style={styles.statusRow}>
                          <Ionicons name="lock-closed-outline" size={11} color={COLORS.textMuted} />
                          <Text style={styles.statusLabelMuted}>Closed</Text>
                        </View>
                      )}
                    </TouchableOpacity>
                  );
                })}
              </View>
            </>
          )}

          {/* ── END TIME ── */}
          {availableSlotsCount > 0 && (
            <>
              <Text style={[styles.subLabel, { marginTop: 18 }]}>END TIME</Text>
              {!startTime && (
                <Text style={styles.helperText}>Select a start time to unlock end times.</Text>
              )}
              <View style={styles.slotsGrid}>
                {startTime && [...timeSlots]
                  .sort((a, b) => {
                    const durA = computeDurationMins(startTime, a, operatingWindow) || 0;
                    const durB = computeDurationMins(startTime, b, operatingWindow) || 0;
                    return durA - durB;
                  })
                  .map(slot => {

                  const durationCandidate = computeDurationMins(startTime, slot, operatingWindow);
                  // Only show times strictly after the selected start time
                  if (durationCandidate == null || durationCandidate <= 0) return null;

                  const isSelected = endTime === slot;
                  const tooShort = durationCandidate < MIN_BOOKING_MINS;
                  const maxMins = maxOpenMinutesFromStart(startTime, operatingWindow);
                  const beyondClose = maxMins != null && durationCandidate > maxMins;
                  const overlaps = availability
                    ? hasBookingOverlap({
                        window: operatingWindow,
                        startTime,
                        endTime: slot,
                        bookedSlots: availability.bookedSlots || [],
                      })
                    : false;

                  const isSlotNextDay = (parseTimeToMinutes(slot) || 0) < (parseTimeToMinutes(startTime) || 0);

                  const isBooked = availability?.bookedSlots?.some(s => {
                    if (s.isExpired) return false;
                    const bStart = toOperatingMinutes(s.startTime, operatingWindow);
                    let bEnd = toOperatingMinutes(s.endTime, operatingWindow);
                    if (bStart == null || bEnd == null) return false;
                    if (bEnd < bStart) bEnd += MINUTES_IN_DAY;
                    const tLin = toOperatingMinutes(slot, operatingWindow);
                    return tLin && tLin > bStart && tLin <= bEnd;
                  });

                  const isUnreachable = overlaps && !isBooked;
                  const disabled = loading || tooShort || beyondClose || overlaps;

                  return (
                    <TouchableOpacity
                      key={`end-${slot}`}
                      disabled={disabled}
                      activeOpacity={disabled ? 1 : 0.7}
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                        setEndTime(slot);
                      }}
                      style={[
                        styles.slotBtn,
                        isSelected && styles.slotBtnActive,
                        (overlaps && isBooked) && !isSelected && styles.slotBtnBooked,
                        (isUnreachable || beyondClose || tooShort) && !isSelected && styles.slotBtnUnavailable,
                      ]}
                    >
                      <Text style={[
                        styles.slotText,
                        isSelected && styles.slotTextActive,
                        (overlaps && isBooked) && !isSelected && styles.slotTextBooked,
                        (isUnreachable || beyondClose || tooShort) && !isSelected && styles.slotTextUnavailable,
                      ]}>
                        {slot}
                      </Text>
                      {isSlotNextDay && <Text style={[styles.nextDayLabel, isSelected && { color: '#000' }]}>Next Day</Text>}
                      {tooShort && <Text style={styles.invalidLabel}>Min {MIN_BOOKING_MINS}m</Text>}
                      {beyondClose && <Text style={styles.invalidLabel}>Close</Text>}
                      {overlaps && isBooked && !beyondClose && (
                        <View style={styles.statusRow}>
                          <Ionicons name="close-circle" size={12} color="#ff6b6b" />
                          <Text style={styles.statusLabelBooked}>Booked</Text>
                        </View>
                      )}
                      {isUnreachable && !beyondClose && (
                        <View style={styles.statusRow}>
                          <Ionicons name="time-outline" size={11} color={COLORS.textMuted} />
                          <Text style={styles.statusLabelMuted}>Unavailable</Text>
                        </View>
                      )}
                    </TouchableOpacity>
                  );
                })}
              </View>
            </>
          )}

          {!!durationMins && !selectionError && (
            <View style={styles.durationRow}>
              <Text style={styles.durationText}>
                Duration: {Math.floor(durationMins / 60)}h {durationMins % 60}m
              </Text>
              {isNextDay && (
                <View style={styles.nextDayBadge}>
                  <Text style={styles.nextDayText}>Next day booking</Text>
                </View>
              )}
            </View>
          )}

          {!!selectionError && <Text style={styles.selectionError}>{selectionError}</Text>}
        </View>

        {/* Sport Select */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>SELECT SPORT</Text>
          <View style={styles.sportRow}>
            {(turf.sports || [turf.sportsType]).map((s: string) => (
              <TouchableOpacity
                key={s}
                onPress={() => setSport(s)}
                style={[styles.sportChip, sport === s && styles.sportChipActive]}
              >
                <Text style={[styles.sportChipText, sport === s && styles.sportChipTextActive]}>{s}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Summary */}
        <View style={[styles.section, styles.summaryCard]}>
          <Text style={styles.sectionLabel}>BOOKING SUMMARY</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryKey}>Turf</Text>
            <Text style={styles.summaryVal}>{turf.name}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryKey}>Sport</Text>
            <Text style={styles.summaryVal}>{sport}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryKey}>Date</Text>
            <Text style={styles.summaryVal}>
              {days[selectedDay].day}, {days[selectedDay].label} {days[selectedDay].date.toLocaleString('default', { month: 'short' })}
            </Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryKey}>Time</Text>
            <Text style={styles.summaryVal}>
              {startTime && endTime ? `${startTime} - ${endTime}${isNextDay ? ' (Next day)' : ''}` : 'Not selected'}
            </Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryKey}>Duration</Text>
            <Text style={styles.summaryVal}>
              {durationMins ? `${Math.floor(durationMins / 60)}h ${durationMins % 60}m` : 'Not selected'}
            </Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.summaryRow}>
            <Text style={styles.totalKey}>Total</Text>
            <Text style={styles.totalVal}>₹{total.toLocaleString()}</Text>
          </View>
        </View>

        <View style={{ height: 120 }} />
      </ScrollView>

      {/* CTA */}
      <View style={styles.bottomBar}>
        <View style={styles.bottomBarContent}>
          <View>
            <Text style={styles.totalBarLabel}>Total Amount</Text>
            <Text style={styles.totalBarAmt}>₹{total.toLocaleString()}</Text>
          </View>
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={[styles.continueBtn, (!canContinue || isQuickBooking || isNavigating) && { opacity: 0.4 }]}
              onPress={handleContinue}
              disabled={!canContinue || isQuickBooking || isNavigating}
              activeOpacity={0.9}
            >
              <LinearGradient colors={[COLORS.primary, '#6FC000']} style={styles.continueGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                {isNavigating ? (
                  <ActivityIndicator size="small" color="#000" />
                ) : (
                  <>
                    <Text style={styles.continueText}>PROCEED</Text>
                    <Ionicons name="arrow-forward" size={18} color="#000" />
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STYLES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 44 : 32, paddingBottom: 16,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  backBtn: { width: 44, height: 44, borderRadius: 14, backgroundColor: COLORS.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  headerSub: { color: COLORS.primary, fontSize: 10, fontWeight: '900', letterSpacing: 2 },
  headerTitle: { color: COLORS.textMain, fontSize: 18, fontWeight: '800' },
  scrollContent: { paddingBottom: 20 },

  section: { paddingHorizontal: 20, marginTop: 24 },
  sectionLabel: { color: COLORS.textMuted, fontSize: 10, fontWeight: '900', letterSpacing: 2, marginBottom: 16 },

  sportRow: { flexDirection: 'row', gap: 10 },
  sportChip: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 12, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  sportChipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  sportChipText: { color: COLORS.textMuted, fontWeight: '700', fontSize: 13 },
  sportChipTextActive: { color: '#000' },

  dateScrollContent: { paddingRight: 20, gap: 10 },
  dayCard: {
    width: 64, height: 115, borderRadius: 32,
    backgroundColor: COLORS.surface, alignItems: 'center',
    borderWidth: 1, borderColor: COLORS.border, paddingVertical: 12,
    justifyContent: 'space-between',
  },
  dayCardActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  dayName: { color: COLORS.textMuted, fontSize: 13, fontWeight: '700' },
  dayNameActive: { color: '#000' },
  dayNumContainer: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.05)', justifyContent: 'center', alignItems: 'center' },
  dayNumContainerActive: { backgroundColor: '#fff' },
  dayNum: { color: COLORS.textMain, fontSize: 18, fontWeight: '800' },
  dayNumActive: { color: '#000' },
  dayMonth: { color: COLORS.textMuted, fontSize: 11, fontWeight: '800' },
  dayMonthActive: { color: 'rgba(0,0,0,0.6)' },

  slotsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 12 },
  slotBtn: {
    width: (width - 40 - 24) / 3,
    paddingVertical: 14, borderRadius: 16,
    backgroundColor: COLORS.surface, borderWidth: 1.2, borderColor: COLORS.border,
    alignItems: 'center',
  },
  slotBtnActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  // Real booked slot: red tint border, faded
  slotBtnBooked: {
    opacity: 0.55,
    backgroundColor: 'rgba(255,107,107,0.04)',
    borderColor: 'rgba(255,107,107,0.3)',
  },
  // Unavailable / Locked slot: greyed out fully
  slotBtnUnavailable: {
    opacity: 0.35,
    backgroundColor: 'transparent',
    borderColor: COLORS.border,
  },
  slotBtnDisabled: { opacity: 0.35 },
  slotText: { color: COLORS.textMain, fontWeight: '700', fontSize: 13 },
  slotTextActive: { color: '#000' },
  slotTextBooked: { color: '#ff6b6b', textDecorationLine: 'line-through', fontSize: 11 },
  slotTextUnavailable: { color: COLORS.textMuted },
  slotTextDisabled: { color: COLORS.textMuted },

  // Status label rows
  statusRow: { marginTop: 4, flexDirection: 'row', alignItems: 'center', gap: 3 },
  statusLabelBooked: { color: '#ff6b6b', fontSize: 9, fontWeight: '900', textTransform: 'uppercase' },
  statusLabelMuted: { color: COLORS.textMuted, fontSize: 9, fontWeight: '900', textTransform: 'uppercase' },

  bookedRow: { marginTop: 4, flexDirection: 'row', alignItems: 'center', gap: 4 },
  bookedLabel: { color: COLORS.textMuted, fontSize: 9, fontWeight: '900', textTransform: 'uppercase', marginTop: 4 },
  invalidLabel: { color: COLORS.textMuted, fontSize: 9, fontWeight: '900', textTransform: 'uppercase', marginTop: 4 },

  badge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface },
  badgeText: { color: COLORS.textMuted, fontSize: 10, fontWeight: '900', letterSpacing: 0.5 },
  selectionError: { marginTop: 10, color: '#ff6b6b', fontSize: 12, fontWeight: '700' },

  subLabel: { color: COLORS.textMuted, fontSize: 10, fontWeight: '900', letterSpacing: 2, marginBottom: 10 },
  showEarlierBtn: { 
    flexDirection: 'row', alignItems: 'center', gap: 6, 
    marginBottom: 12, backgroundColor: 'rgba(137,233,0,0.05)', 
    padding: 8, borderRadius: 10, alignSelf: 'flex-start' 
  },
  showEarlierText: { color: COLORS.primary, fontSize: 11, fontWeight: '800' },
  nextDayLabel: { color: COLORS.textMuted, fontSize: 8, fontWeight: '900', textTransform: 'uppercase', marginTop: 2 },
  helperText: { color: COLORS.textMuted, fontSize: 12, fontWeight: '600', marginBottom: 10 },
  durationRow: { marginTop: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  durationText: { color: COLORS.textMain, fontSize: 13, fontWeight: '800' },
  nextDayBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, backgroundColor: 'rgba(255, 159, 67, 0.14)', borderWidth: 1, borderColor: 'rgba(255, 159, 67, 0.25)' },
  nextDayText: { color: '#ff9f43', fontSize: 11, fontWeight: '900' },

  summaryCard: {
    backgroundColor: COLORS.surface, borderRadius: 32, padding: 24,
    marginHorizontal: 20, borderWidth: 1.2, borderColor: COLORS.border,
  },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  summaryKey: { color: COLORS.textMuted, fontSize: 14, fontWeight: '600' },
  summaryVal: { color: COLORS.textMain, fontSize: 14, fontWeight: '700' },
  divider: { height: 1.5, backgroundColor: COLORS.border, marginVertical: 14 },
  totalKey: { color: COLORS.textMain, fontSize: 18, fontWeight: '800' },
  totalVal: { color: COLORS.primary, fontSize: 22, fontWeight: '900' },

  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: COLORS.background, paddingHorizontal: 20,
    paddingTop: 16, paddingBottom: Platform.OS === 'ios' ? 40 : 24,
    borderTopWidth: 1.2, borderTopColor: COLORS.border,
  },
  bottomBarContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  totalBarLabel: { color: COLORS.textMuted, fontSize: 12, fontWeight: '600' },
  totalBarAmt: { color: COLORS.textMain, fontSize: 24, fontWeight: '800' },
  actionButtons: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  quickBookBtn: {
    paddingVertical: 12, paddingHorizontal: 16,
    borderRadius: 20, borderWidth: 1, borderColor: COLORS.primary,
    backgroundColor: 'rgba(137,233,0,0.1)', justifyContent: 'center', alignItems: 'center',
    height: 56,
  },
  quickBookText: { color: COLORS.primary, fontWeight: '800', fontSize: 13 },
  continueBtn: { borderRadius: 20, overflow: 'hidden' },
  continueGradient: { height: 56, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  continueText: { color: '#000', fontWeight: '900', fontSize: 15, letterSpacing: 0.5 },

  noSlotsCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    borderWidth: 1.2,
    borderColor: 'rgba(255, 107, 107, 0.3)',
    backgroundColor: 'rgba(255, 107, 107, 0.05)',
    padding: 16,
    gap: 16,
    marginTop: 8,
    marginBottom: 16,
    width: '100%',
  },
  noSlotsIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(255, 107, 107, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  noSlotsTitle: {
    color: '#ff6b6b',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 4,
  },
  noSlotsMessage: {
    color: COLORS.textMuted,
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 18,
  },
});
