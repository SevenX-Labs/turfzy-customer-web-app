import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Dimensions, Platform, StatusBar, ActivityIndicator, Alert, TextInput, KeyboardAvoidingView, Keyboard, Modal, Share } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons, MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/src/context/AppContext';
import { BookingService } from '@/src/services/bookingService';
import { SplitService, SplitDetails, SplitPlayer } from '@/src/services/splitService';
import { Booking } from '@/src/types/booking.types';

const { width } = Dimensions.get('window');

export default function SplitScreen() {
  const { COLORS, userProfile } = useApp();
  const styles = getStyles(COLORS);

  const { id: bookingId } = useLocalSearchParams<{ id: string }>();
  
  const [booking, setBooking] = useState<Booking | null>(null);
  const [split, setSplit] = useState<SplitDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [addingPlayer, setAddingPlayer] = useState(false);
  const [usernameInput, setUsernameInput] = useState('');
  const [customAmounts, setCustomAmounts] = useState<Record<string, string>>({});
  const [updatingPlayerId, setUpdatingPlayerId] = useState<string | null>(null);
  const [confirmingSplit, setConfirmingSplit] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const isDark = COLORS.isDark;

  const fetchData = useCallback(async () => {
    if (!bookingId) return;
    try {
      const [bookingRes, splitRes] = await Promise.all([
        BookingService.getBookingDetails(bookingId),
        SplitService.getSplitDetails(bookingId)
      ]);

      if (bookingRes.success) setBooking(bookingRes.data);
      if (splitRes.success) {
        setSplit(splitRes.data);
        // Initialize custom amounts state
        const amounts: Record<string, string> = {};
        splitRes.data.players.forEach(p => {
          amounts[p.id] = p.amount.toString();
        });
        setCustomAmounts(amounts);
      }
    } catch (err: any) {
      console.error('Fetch Split Error:', err);
    } finally {
      setLoading(false);
    }
  }, [bookingId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAddPlayer = async () => {
    if (!usernameInput.trim() || addingPlayer) return;
    
    const username = usernameInput.trim().replace(/^@/, '');
    const savedInput = usernameInput;
    
    // Immediate feedback
    Keyboard.dismiss();
    setAddingPlayer(true);
    setUsernameInput('');
    
    try {
      const res = await SplitService.addPlayers(bookingId!, [username]);
      if (res.success) {
        await fetchData();
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        setUsernameInput(savedInput);
        Alert.alert('Error', res.message || 'Failed to add player');
      }
    } catch (err: any) {
      setUsernameInput(savedInput);
      Alert.alert('Error', err.response?.data?.message || 'Failed to add player');
    } finally {
      setAddingPlayer(false);
    }
  };

  const handleRemovePlayer = async (playerId: string) => {
    try {
      const res = await SplitService.removePlayer(playerId);
      if (res.success) {
        await fetchData();
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      }
    } catch (err: any) {
      Alert.alert('Error', 'Failed to remove player');
    }
  };

  const handleUpdateAmount = (playerId: string, val: string) => {
    setCustomAmounts(prev => ({ ...prev, [playerId]: val }));
  };

  const saveCustomAmounts = async () => {
    if (!split) return;
    
    const amounts = Object.entries(customAmounts).map(([playerId, val]) => ({
      playerId,
      amount: parseFloat(val) || 0
    }));

    const total = amounts.reduce((sum, a) => sum + a.amount, 0);
    if (Math.abs(total - split.totalAmount) > 0.01) {
      Alert.alert('Invalid Total', `Total must equal ₹${split.totalAmount}. Current total: ₹${total}`);
      return;
    }

    try {
      setLoading(true);
      const res = await SplitService.setCustomAmounts(bookingId!, amounts);
      if (res.success) {
        await fetchData();
        Alert.alert('Success', 'Custom split amounts saved');
      }
    } catch (err: any) {
      Alert.alert('Error', err.response?.data?.message || 'Failed to save amounts');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmSplit = async () => {
    Keyboard.dismiss();
    Alert.alert(
      'Confirm Split',
      'This will lock the split and you won\'t be able to add more players. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Confirm', 
          onPress: async () => {
            setConfirmingSplit(true);
            try {
              const res = await SplitService.triggerSplit(bookingId!);
              if (res.success) {
                await fetchData();
                setShowSuccess(true);
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              }
            } catch (err: any) {
              Alert.alert('Error', 'Failed to confirm split');
            } finally {
              setConfirmingSplit(false);
            }
          }
        }
      ]
    );
  };

  const handleMarkPaid = async (playerId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'PAID' ? 'PENDING' : 'PAID';
    setUpdatingPlayerId(playerId);
    
    // Optimistic Update
    if (split) {
      const updatedPlayers = split.players.map(p => 
        p.id === playerId ? { ...p, status: nextStatus as any } : p
      );
      setSplit({ ...split, players: updatedPlayers });
    }

    try {
      const res = await SplitService.updatePlayerStatus(playerId, nextStatus as any);
      if (res.success) {
        await fetchData();
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } else {
        // Revert on failure
        await fetchData();
        Alert.alert('Error', res.message || 'Failed to update status');
      }
    } catch (err: any) {
      await fetchData();
      Alert.alert('Error', 'Failed to update player status');
    } finally {
      setUpdatingPlayerId(null);
    }
  };

  const summary = useMemo(() => {
    if (!split) return { paid: 0, pending: 0, total: 0 };
    const paid = split.players.filter(p => p.status === 'PAID').reduce((sum, p) => sum + p.amount, 0);
    const total = split.totalAmount;
    return { paid, pending: total - paid, total };
  }, [split]);

  if (loading && !booking) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  if (!booking || !split) return null;

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : undefined} 
      style={styles.container}
    >
      <StatusBar barStyle="light-content" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={styles.headerSub}>Split in Team</Text>
          <Text style={styles.headerTitle} numberOfLines={1}>{booking.turf?.name || 'Venue Name'}</Text>
        </View>
      </View>

      <ScrollView 
        contentContainerStyle={styles.scrollContent} 
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        
        {/* Booking Brief */}
        <View style={styles.briefCard}>
          <View style={styles.briefRow}>
            <View style={styles.briefItem}>
              <Ionicons name="calendar-outline" size={14} color={COLORS.primary} />
              <Text style={styles.briefText}>
                {new Date(booking.bookingDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              </Text>
            </View>
            <View style={styles.briefItem}>
              <Ionicons name="time-outline" size={14} color={COLORS.primary} />
              <Text style={styles.briefText}>{booking.startTime} - {booking.endTime}</Text>
            </View>
          </View>
          <Text style={styles.briefTagline}>
            {split.isSplitDone ? 'Settlement tracking in progress' : 'Split this booking with your team mates'}
          </Text>
        </View>

        {/* Summary Dashboard */}
        <View style={styles.summaryGrid}>
          <View style={[styles.summaryItem, { backgroundColor: isDark ? 'rgba(137,233,0,0.05)' : '#f0f9e8' }]}>
            <Text style={styles.summaryLabel}>Total Cost</Text>
            <Text style={styles.summaryVal}>₹{summary.total}</Text>
          </View>
          <View style={[styles.summaryItem, { backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : '#f5f5f5' }]}>
            <Text style={styles.summaryLabel}>Collected</Text>
            <Text style={[styles.summaryVal, { color: COLORS.primary }]}>₹{summary.paid}</Text>
          </View>
          <View style={[styles.summaryItem, { backgroundColor: isDark ? 'rgba(255,107,107,0.05)' : '#fef2f2' }]}>
            <Text style={styles.summaryLabel}>Pending</Text>
            <Text style={[styles.summaryVal, { color: '#ff6b6b' }]}>₹{summary.pending}</Text>
          </View>
        </View>

        {/* Step 1: Add Players */}
        {!split.isSplitDone && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>1. ADD TEAMMATES</Text>
            <View style={styles.addInputRow}>
              <View style={styles.inputWrapper}>
                <Ionicons name="at" size={18} color={COLORS.textMuted} style={styles.inputIcon} />
                <TextInput
                  placeholder="Username"
                  placeholderTextColor={COLORS.textMuted}
                  style={styles.input}
                  value={usernameInput}
                  onChangeText={setUsernameInput}
                  autoCapitalize="none"
                />
              </View>
              <TouchableOpacity 
                style={[styles.addBtn, !usernameInput.trim() && styles.disabledBtn]} 
                onPress={handleAddPlayer}
                disabled={addingPlayer || !usernameInput.trim()}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                {addingPlayer ? (
                  <ActivityIndicator size="small" color="#000" />
                ) : (
                  <Ionicons name="add" size={24} color="#000" />
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Step 2 & 3: Player List & Amounts */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionLabel}>
              {split.isSplitDone ? 'PAYMENT TRACKER' : '2. REVIEW SPLIT'}
            </Text>
            {split.isSplitDone && (
              <View style={styles.lockedBadge}>
                <Ionicons name="lock-closed" size={10} color={COLORS.primary} />
                <Text style={styles.lockedText}>LOCKED</Text>
              </View>
            )}
          </View>

          <View style={styles.playerList}>
            {split.players.map((p, idx) => {
              const isMe = p.username === userProfile?.username;
              
              return (
                <View key={p.id} style={styles.playerRow}>
                  <View style={styles.playerInfo}>
                    <View style={styles.avatar}>
                      <Text style={styles.avatarText}>{p.username.charAt(0).toUpperCase()}</Text>
                    </View>
                    <View>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                        <Text style={styles.playerName}>{isMe ? 'You' : p.username}</Text>
                        {isMe && <View style={[styles.meBadge, { backgroundColor: COLORS.primary + '20' }]}><Text style={[styles.meBadgeText, { color: COLORS.primary }]}>LEAD</Text></View>}
                      </View>
                      <Text style={styles.playerStatus}>{p.status}</Text>
                    </View>
                  </View>

                  <View style={styles.playerActions}>
                    {!split.isSplitDone ? (
                      <View style={styles.amountInputRow}>
                        <Text style={styles.currency}>₹</Text>
                        <TextInput
                          style={styles.amountInput}
                          keyboardType="numeric"
                          value={customAmounts[p.id]}
                          onChangeText={(val) => handleUpdateAmount(p.id, val)}
                        />
                        <TouchableOpacity 
                          style={styles.removeBtn} 
                          onPress={() => handleRemovePlayer(p.id)}
                        >
                          <Ionicons name="close-circle" size={20} color="#ff6b6b" />
                        </TouchableOpacity>
                      </View>
                    ) : (
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                        <Text style={styles.fixedAmount}>₹{p.amount}</Text>
                        <TouchableOpacity 
                          style={[
                            styles.statusBtn, 
                            p.status === 'PAID' ? styles.statusBtnPaid : styles.statusBtnPending
                          ]}
                          onPress={() => handleMarkPaid(p.id, p.status)}
                          disabled={updatingPlayerId === p.id}
                        >
                          {updatingPlayerId === p.id ? (
                            <ActivityIndicator size="small" color={p.status === 'PAID' ? '#000' : COLORS.primary} />
                          ) : (
                            <Text style={[
                              styles.statusBtnText,
                              p.status === 'PAID' ? styles.statusBtnTextPaid : styles.statusBtnTextPending
                            ]}>
                              {p.status === 'PAID' ? 'PAID' : 'MARK PAID'}
                            </Text>
                          )}
                        </TouchableOpacity>
                      </View>
                    )}
                  </View>
                </View>
              );
            })}
          </View>

          {!split.isSplitDone && split.players.length > 0 && (
            <TouchableOpacity style={styles.saveAmountsBtn} onPress={saveCustomAmounts}>
              <Text style={styles.saveAmountsText}>Update Custom Amounts</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Info Box */}
        {split.isSplitDone && (
          <View style={styles.infoBox}>
            <Feather name="info" size={16} color={COLORS.primary} />
            <Text style={styles.infoBoxText}>
              Share your UPI ID or QR with teammates. Mark them as paid once you receive the money.
            </Text>
          </View>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Footer CTA */}
      {!split.isSplitDone && (
        <View style={styles.footer}>
          <TouchableOpacity 
            style={[styles.confirmBtn, (split.players.length === 0 || confirmingSplit) && styles.disabledConfirmBtn]} 
            onPress={handleConfirmSplit}
            disabled={split.players.length === 0 || confirmingSplit}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <LinearGradient 
              colors={split.players.length === 0 || confirmingSplit ? [COLORS.border, COLORS.border] : [COLORS.primary, '#6FC000']} 
              style={styles.confirmGradient} 
              start={{ x: 0, y: 0 }} 
              end={{ x: 1, y: 0 }}
            >
              {confirmingSplit ? (
                <ActivityIndicator size="small" color="#000" />
              ) : (
                <>
                  <Text style={styles.confirmBtnText}>CONFIRM SPLIT</Text>
                  <Ionicons name="checkmark-done" size={20} color="#000" />
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {split.isSplitDone && (
        <View style={styles.confirmedFooter}>
          <TouchableOpacity 
            style={[styles.shareBtn, { borderColor: COLORS.primary }]} 
            onPress={() => {
              const text = `Hey team! Split for ${booking.turf?.name} is ready. Total ₹${split.totalAmount}. Please settle your amounts!`;
              Share.share({ message: text });
            }}
          >
            <Ionicons name="share-social-outline" size={18} color={COLORS.primary} />
            <Text style={[styles.shareBtnText, { color: COLORS.primary }]}>SHARE INFO</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.doneBtn} onPress={() => router.back()}>
            <Text style={styles.doneBtnText}>DONE</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* SUCCESS MODAL */}
      <Modal visible={showSuccess} transparent animationType="fade">
        <View style={styles.successOverlay}>
          <LinearGradient colors={['rgba(0,0,0,0.9)', 'rgba(0,0,0,0.95)']} style={StyleSheet.absoluteFill} />
          <View style={styles.successContent}>
            <View style={styles.successCircle}>
              <Ionicons name="checkmark" size={64} color="#000" />
            </View>
            <Text style={styles.successTitle}>Split Finalized!</Text>
            <Text style={styles.successSub}>
              Notifications have been sent to your team. You can now track who has paid you.
            </Text>
            <TouchableOpacity 
              style={styles.successCta} 
              onPress={() => setShowSuccess(false)}
            >
              <Text style={styles.successCtaText}>VIEW SETTLEMENTS</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const getStyles = (COLORS: any) => {
  const isDark = COLORS.isDark;
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: COLORS.background },
    header: {
      flexDirection: 'row', alignItems: 'center',
      paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 56 : 40, paddingBottom: 16,
      backgroundColor: COLORS.surface, borderBottomWidth: 1, borderBottomColor: COLORS.border,
    },
    backBtn: { width: 44, height: 44, borderRadius: 12, backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : '#f5f5f5', justifyContent: 'center', alignItems: 'center' },
    headerInfo: { marginLeft: 16, flex: 1 },
    headerSub: { color: COLORS.primary, fontSize: 10, fontWeight: '900', letterSpacing: 1.5, textTransform: 'uppercase' },
    headerTitle: { color: COLORS.textMain, fontSize: 18, fontWeight: '800' },

    scrollContent: { paddingHorizontal: 16, paddingTop: 20, paddingBottom: 120 },
    briefCard: { marginBottom: 24 },
    briefRow: { flexDirection: 'row', gap: 16, marginBottom: 8 },
    briefItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    briefText: { color: COLORS.textMuted, fontSize: 13, fontWeight: '600' },
    briefTagline: { color: COLORS.textMain, fontSize: 15, fontWeight: '700' },

    summaryGrid: { flexDirection: 'row', gap: 8, marginBottom: 32 },
    summaryItem: { flex: 1, paddingVertical: 16, paddingHorizontal: 4, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
    summaryLabel: { color: COLORS.textMuted, fontSize: 9, fontWeight: '800', textTransform: 'uppercase', marginBottom: 6, textAlign: 'center' },
    summaryVal: { color: COLORS.textMain, fontSize: 16, fontWeight: '900' },

    section: { marginBottom: 32 },
    sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
    sectionLabel: { color: COLORS.textMuted, fontSize: 12, fontWeight: '900', letterSpacing: 1 },
    lockedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(137,233,0,0.1)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
    lockedText: { color: COLORS.primary, fontSize: 9, fontWeight: '900' },

    addInputRow: { flexDirection: 'row', gap: 12 },
    inputWrapper: { flex: 1, height: 56, backgroundColor: COLORS.surface, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16 },
    inputIcon: { marginRight: 8 },
    input: { flex: 1, color: COLORS.textMain, fontSize: 15, fontWeight: '600' },
    addBtn: { width: 56, height: 56, backgroundColor: COLORS.primary, borderRadius: 16, justifyContent: 'center', alignItems: 'center', shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 },
    disabledBtn: { opacity: 0.5, shadowOpacity: 0 },
    meBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
    meBadgeText: { fontSize: 8, fontWeight: '900' },

    playerList: { gap: 12 },
    playerRow: { 
      flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', 
      backgroundColor: COLORS.surface, padding: 12, borderRadius: 16, 
      borderWidth: 1, borderColor: COLORS.border 
    },
    playerInfo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: isDark ? 'rgba(255,255,255,0.1)' : '#eee', justifyContent: 'center', alignItems: 'center' },
    avatarText: { color: COLORS.textMain, fontSize: 16, fontWeight: '800' },
    playerName: { color: COLORS.textMain, fontSize: 14, fontWeight: '700' },
    playerStatus: { color: COLORS.textMuted, fontSize: 10, fontWeight: '600', textTransform: 'uppercase' },
    
    playerActions: { alignItems: 'flex-end' },
    amountInputRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    currency: { color: COLORS.textMuted, fontSize: 14, fontWeight: '700' },
    amountInput: { 
      width: 70, height: 44, backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : '#f9f9f9', 
      borderRadius: 8, borderWidth: 1, borderColor: COLORS.border, 
      textAlign: 'center', color: COLORS.textMain, fontWeight: '800',
      padding: 0, paddingVertical: 0, textAlignVertical: 'center',
      fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System',
      fontSize: 16
    },
    removeBtn: { marginLeft: 8 },
    fixedAmount: { color: COLORS.textMain, fontSize: 16, fontWeight: '900', marginRight: 4 },
    
    statusBtn: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, borderWidth: 1.5 },
    statusBtnPending: { borderColor: COLORS.primary, backgroundColor: 'transparent' },
    statusBtnPaid: { borderColor: 'transparent', backgroundColor: COLORS.primary },
    statusBtnText: { fontSize: 10, fontWeight: '900' },
    statusBtnTextPending: { color: COLORS.primary },
    statusBtnTextPaid: { color: '#000' },

    saveAmountsBtn: { marginTop: 16, alignSelf: 'center' },
    saveAmountsText: { color: COLORS.primary, fontWeight: '800', fontSize: 13 },

    infoBox: { flexDirection: 'row', gap: 12, backgroundColor: isDark ? 'rgba(137,233,0,0.05)' : '#f0f9e8', padding: 16, borderRadius: 16, marginTop: 10 },
    infoBoxText: { flex: 1, color: COLORS.textMuted, fontSize: 12, lineHeight: 18, fontWeight: '600' },

    footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20, paddingTop: 10, backgroundColor: COLORS.background },
    confirmBtn: { height: 64, borderRadius: 22, overflow: 'hidden' },
    confirmGradient: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10 },
    confirmBtnText: { color: '#000', fontSize: 16, fontWeight: '900', letterSpacing: 0.5 },
    disabledConfirmBtn: { opacity: 0.4 },

    confirmedFooter: { 
      position: 'absolute', bottom: 0, left: 0, right: 0, 
      padding: 20, paddingTop: 10, backgroundColor: COLORS.surface,
      flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
      borderTopWidth: 1, borderTopColor: COLORS.border,
      paddingBottom: Platform.OS === 'ios' ? 40 : 20,
    },
    successOverlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center', zIndex: 1000 },
    successContent: { alignItems: 'center', padding: 30 },
    successCircle: { width: 100, height: 100, borderRadius: 50, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center', marginBottom: 24, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.5, shadowRadius: 20, elevation: 15 },
    successTitle: { color: '#fff', fontSize: 28, fontWeight: '900', marginBottom: 12 },
    successSub: { color: 'rgba(255,255,255,0.7)', fontSize: 16, textAlign: 'center', lineHeight: 24, marginBottom: 32 },
    successCta: { backgroundColor: COLORS.primary, paddingHorizontal: 32, paddingVertical: 16, borderRadius: 16 },
    successCtaText: { color: '#000', fontWeight: '900', letterSpacing: 0.5 },

    shareBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 50, borderRadius: 14, borderWidth: 1.5, marginRight: 12 },
    shareBtnText: { fontWeight: '900', fontSize: 13 },
    doneBtn: { flex: 1, height: 50, backgroundColor: COLORS.primary, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
    doneBtnText: { color: '#000', fontWeight: '900', fontSize: 14 },
  });
};
