import React, { useState, useEffect } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Dimensions, StatusBar, Platform, ActivityIndicator } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { Image } from 'expo-image';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useVideoPlayer, VideoView } from 'expo-video';
import { useApp } from '@/src/context/AppContext';
import { TurfService } from '@/src/services/turfService';
import { TurfCard } from '@/src/services/homeService';
import SkeletonLoader from '@/src/components/SkeletonLoader';


const { width, height } = Dimensions.get('window');

const SPORT_ICONS: Record<string, any> = {
  FOOTBALL: 'football',
  CRICKET: 'baseball',
  BASKETBALL: 'basketball',
  TENNIS: 'tennisball',
};

export default function TurfDetailScreen() {
  const { COLORS, setPendingBooking, isFavoriteTurf, toggleFavoriteTurf } = useApp();
  const styles = getStyles(COLORS);
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();

  const [turf, setTurf] = useState<TurfCard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeImg, setActiveImg] = useState(0);
  const [videoError, setVideoError] = useState(false);
  const [shouldPlayVideo, setShouldPlayVideo] = useState(false);
  const [videoLayout, setVideoLayout] = useState({ y: 0, height: 0 });

  useEffect(() => {
    if (id) {
      fetchDetails();
    }
  }, [id]);

  const fetchDetails = async () => {
    setLoading(true);
    setError(null);
    try {
      const res: any = await TurfService.getTurfDetails(id!);
      
      // Handle both wrapped {success, data} and raw turf objects
      if (res && (res.success || res.id)) {
        const turfData = res.success ? res.data : res;
        setTurf(turfData);
      } else {
        setError(res?.message || 'Could not load turf details.');
      }
    } catch (err: any) {
      console.error('Failed to fetch turf details:', err);
      setError(err.message || 'Network error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const isFav = turf ? isFavoriteTurf(turf.id) : false;
  const isUnavailable = turf && turf.status !== 'ACTIVE';
  const unavailableText = turf?.status ? turf.status.replace('_', ' ') : 'UNAVAILABLE';

  const handleBook = () => {
    if (!turf) return;
    setPendingBooking({
      turfId: turf.id,
      turfName: turf.name,
      turfImage: turf.images[0],
      location: turf.city,
      pricePerHour: turf.weekdayDayPrice,
    });
    router.push({ pathname: '/customer/booking/book', params: { id: turf.id } });
  };

  const handleScroll = (event: any) => {
    const scrollY = event.nativeEvent.contentOffset.y;
    const screenCenter = scrollY + (height / 2);
    
    // Play video if the center of the screen is within the video's vertical bounds
    // We add a small buffer for better UX
    if (videoLayout.y > 0) {
      const isVisible = screenCenter > videoLayout.y && screenCenter < (videoLayout.y + videoLayout.height + 100);
      if (isVisible !== shouldPlayVideo) {
        setShouldPlayVideo(isVisible);
      }
    }
  };

  if (loading) {
    return <DetailSkeleton COLORS={COLORS} insets={insets} />;
  }


  if (error || !turf) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 20 }]}>
        <Ionicons name="alert-circle-outline" size={60} color={COLORS.textMuted} />
        <Text style={{ color: COLORS.textMain, fontSize: 18, marginTop: 16, textAlign: 'center' }}>
          {error || 'Turf details not found.'}
        </Text>
        <TouchableOpacity style={{ marginTop: 20, padding: 12, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 12 }} onPress={() => router.back()}>
          <Text style={{ color: COLORS.kiwi, fontWeight: '700' }}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const amenities = [
    { label: 'Floodlights', active: turf.floodLights, icon: 'flashlight-outline' },
    { label: 'Parking', active: turf.parking, icon: 'car-outline' },
    { label: 'Washroom', active: turf.washroom, icon: 'water-outline' },
    { label: 'Changing Room', active: turf.changingRoom, icon: 'shirt-outline' },
    { label: 'Drinking Water', active: turf.drinkingWater, icon: 'pint-outline' },
    { label: 'Seating Area', active: turf.seatingArea, icon: 'people-outline' },
    { label: 'Cafeteria', active: turf.cafeteria, icon: 'cafe-outline' },
  ].filter(a => a.active);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Image Header */}
      <View style={styles.imageContainer}>
        <Image 
          source={{ uri: turf.entranceUrl || turf.images[0] }} 
          style={styles.heroImage} 
          contentFit="cover"
        />
        <LinearGradient colors={['rgba(8,9,10,0.6)', 'transparent', 'rgba(8,9,10,0.95)']} style={StyleSheet.absoluteFill} />

        {/* Top Nav */}
        <View style={styles.topNav}>
          <TouchableOpacity style={styles.navBtn} onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.navBtn} onPress={() => toggleFavoriteTurf(turf.id)}>
            <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={22} color={isFav ? '#FF453A' : '#fff'} />
          </TouchableOpacity>
        </View>

        {/* Availability Badge */}
        <View style={[styles.availBadge, { borderColor: COLORS.kiwi }]}>
          <View style={[styles.availDot, { backgroundColor: COLORS.kiwi }]} />
          <Text style={[styles.availText, { color: COLORS.kiwi }]}>{turf.status.toUpperCase()}</Text>
        </View>
      </View>

      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        {isUnavailable && (
          <View style={styles.maintenanceBanner}>
            <Ionicons name={turf.status === 'MAINTENANCE' ? 'construct' : 'alert-circle'} size={20} color="#FF9500" />
            <Text style={styles.maintenanceBannerText}>
              This turf is currently {unavailableText.toLowerCase()}. Booking is disabled.
            </Text>
          </View>
        )}

        {/* Basic Info */}
        <View style={styles.infoSection}>
          <View style={styles.titleRow}>
            <Text style={styles.turfName}>{turf.name}</Text>
            <View style={styles.ratingPill}>
              <Ionicons name="star" size={12} color={COLORS.kiwi} />
              <Text style={styles.ratingText}>{Number(turf.rating || 0).toFixed(1)}</Text>
            </View>
          </View>

          <View style={styles.metaRow}>
            <Ionicons name="location-outline" size={14} color={COLORS.textMuted} />
            <Text style={styles.metaText}>{turf.city}, {turf.address}</Text>
          </View>

          <View style={styles.metaRow}>
            <Ionicons name="chatbubble-outline" size={14} color={COLORS.textMuted} />
            <Text style={styles.metaText}>{turf.reviewCount || turf.customerReviews?.length || 0} reviews</Text>
            <Text style={styles.dot2}>•</Text>
            <Ionicons name="time-outline" size={14} color={COLORS.textMuted} />
            <Text style={styles.metaText}> {turf.openTime} – {turf.closeTime}</Text>
          </View>
        </View>

        {/* Sports */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>SPORTS & DIMENSIONS</Text>
          <View style={styles.pillRow}>
            <View style={styles.sportPill}>
              <Ionicons name={SPORT_ICONS[turf.sportsType] ?? 'football'} size={16} color={COLORS.kiwi} />
              <Text style={styles.sportText}>{turf.sportsType}</Text>
            </View>
            <View style={styles.sizePill}>
              <MaterialCommunityIcons name="arrow-all" size={16} color={COLORS.textMuted} />
              <Text style={styles.sizeText}>{turf.turfSize}</Text>
            </View>
          </View>
        </View>

        {/* Day & Night Views & Video Section */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>VENUE GLIMPSE</Text>
          
          {turf && !videoError && (
            <View 
              style={[styles.videoWrapper, { marginBottom: 12 }]}
              onLayout={(e) => {
                // Adjust for the header height (approx 32% of screen)
                const headerHeight = height * 0.32;
                setVideoLayout({ 
                  y: e.nativeEvent.layout.y + headerHeight, 
                  height: e.nativeEvent.layout.height 
                });
              }}
            >
              <TurfVideoPlayer 
                url={turf.videoUrl || `https://zgryqgoajdousrqdofcs.supabase.co/storage/v1/object/public/uploads/turfs/${turf.id}/video.mp4`}
                shouldPlay={shouldPlayVideo}
              />
            </View>
          )}

          <View style={styles.glimpseGrid}>
            <View style={styles.glimpseItem}>
              <Image source={{ uri: turf.groundDayUrl || turf.images[1] }} style={styles.glimpseImage} contentFit="cover" />
              <View style={styles.glimpseLabel}>
                <Ionicons name="sunny" size={10} color="#000" />
                <Text style={styles.glimpseLabelText}>DAY VIEW</Text>
              </View>
            </View>
            <View style={styles.glimpseItem}>
              <Image source={{ uri: turf.groundNightUrl || turf.images[2] }} style={styles.glimpseImage} contentFit="cover" />
              <View style={styles.glimpseLabel}>
                <Ionicons name="moon" size={10} color="#000" />
                <Text style={styles.glimpseLabelText}>NIGHT VIEW</Text>
              </View>
            </View>
          </View>
        </View>


        {/* Description */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>ABOUT</Text>
          <Text style={styles.description}>{turf.description}</Text>
        </View>

        {/* Amenities */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>AMENITIES</Text>
          <View style={styles.amenititesGrid}>
            {amenities.map(a => (
              <View key={a.label} style={styles.amenityChip}>
                <Ionicons name={a.icon as any} size={16} color={COLORS.kiwi} />
                <Text style={styles.amenityText}>{a.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Rules Section */}
        {turf.rules && turf.rules.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>TURF RULES</Text>
            <View style={styles.rulesCard}>
              {turf.rules.map((rule, idx) => (
                <View key={idx} style={styles.ruleItem}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.kiwi} />
                  <Text style={styles.ruleText}>{rule}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Owner Info */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>MANAGED BY</Text>
          <View style={styles.ownerCard}>
            <View style={styles.ownerAvatar}>
              <Text style={styles.ownerInitial}>{turf.owner.name.charAt(0)}</Text>
            </View>
            <View style={styles.ownerInfo}>
              <Text style={styles.ownerName}>{turf.owner.name}</Text>
              <Text style={styles.ownerRole}>Venue Owner</Text>
            </View>
            <TouchableOpacity style={styles.callBtn}>
              <Ionicons name="call" size={20} color={COLORS.kiwi} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Reviews Section */}
        {turf.customerReviews && turf.customerReviews.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionLabel}>PLAYER REVIEWS</Text>
              <Text style={styles.reviewCount}>{turf.customerReviews.length} total</Text>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.reviewsScroll}>
              {turf.customerReviews.map((rev, idx) => (
                <View key={idx} style={styles.reviewCard}>
                  <View style={styles.reviewHeader}>
                    <Text style={styles.reviewerName}>{rev.reviewerName}</Text>
                    <View style={styles.reviewerRating}>
                      <Ionicons name="star" size={10} color={COLORS.kiwi} />
                      <Text style={styles.ratingValueText}>{Number(rev.rating || 0).toFixed(1)}</Text>
                    </View>
                  </View>
                  <Text style={styles.reviewComment} numberOfLines={3}>{rev.comment}</Text>
                </View>
              ))}
            </ScrollView>
          </View>
        )}

        <View style={{ height: 140 }} />
      </ScrollView>

      {/* Bottom CTA */}
      <View style={[styles.bottomBar, { paddingBottom: Math.max(insets.bottom, 24) }]}>
        <View>
          <Text style={styles.priceLabel}>Price starting from</Text>
          <Text style={styles.price}>₹{turf.weekdayDayPrice.toLocaleString()}<Text style={styles.perHr}>/hr</Text></Text>
        </View>
        <TouchableOpacity 
          style={[styles.bookBtn, isUnavailable && { opacity: 0.8 }]} 
          activeOpacity={0.9} 
          onPress={handleBook}
          disabled={isUnavailable}
        >
          <LinearGradient 
            colors={isUnavailable ? [COLORS.surface, COLORS.border] : [COLORS.kiwi, '#6FC000']} 
            style={styles.bookGradient} 
            start={{ x: 0, y: 0 }} 
            end={{ x: 1, y: 0 }}
          >
            <Text style={[styles.bookText, isUnavailable && { color: COLORS.textMuted, fontSize: 13 }]}>
              {isUnavailable ? unavailableText : 'BOOK NOW'}
            </Text>
            {!isUnavailable && <Ionicons name="arrow-forward" size={18} color="#000" />}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const TurfVideoPlayer = ({ url, shouldPlay }: { url: string, shouldPlay: boolean }) => {
  const player = useVideoPlayer(url, player => {
    player.loop = true;
    player.muted = true;
  });

  useEffect(() => {
    if (shouldPlay) {
      player.play();
    } else {
      player.pause();
    }
  }, [shouldPlay, player]);

  return (
    <VideoView
      style={{ width: '100%', height: '100%' }}
      player={player}
      allowsFullscreen
      contentFit="cover"
    />
  );
};

const DetailSkeleton = ({ COLORS, insets }: any) => {
  const styles = getStyles(COLORS);
  return (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <SkeletonLoader width="100%" height="100%" borderRadius={0} />
      </View>
      <ScrollView style={styles.content}>
        <View style={styles.infoSection}>
          <SkeletonLoader width={200} height={30} style={{ marginBottom: 12 }} />
          <SkeletonLoader width={250} height={20} style={{ marginBottom: 12 }} />
          <SkeletonLoader width={150} height={15} />
        </View>
        <View style={styles.section}>
          <SkeletonLoader width={120} height={15} style={{ marginBottom: 12 }} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <SkeletonLoader width={100} height={40} borderRadius={12} />
            <SkeletonLoader width={100} height={40} borderRadius={12} />
          </View>
        </View>
        <View style={styles.section}>
          <SkeletonLoader width={120} height={15} style={{ marginBottom: 12 }} />
          {/* Video Skeleton */}
          <SkeletonLoader width="100%" height={200} borderRadius={20} style={{ marginBottom: 12 }} />
          {/* Day/Night Skeletons */}
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <SkeletonLoader width={(width - 60) / 2} height={120} borderRadius={16} />
            <SkeletonLoader width={(width - 60) / 2} height={120} borderRadius={16} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({

  container: { flex: 1, backgroundColor: COLORS.night },

  imageContainer: { height: height * 0.32, position: 'relative' },
  heroImage: { width: '100%', height: '100%' },
  topNav: {
    position: 'absolute', top: Platform.OS === 'ios' ? 56 : 40, left: 0, right: 0,
    flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, zIndex: 10,
  },
  navBtn: {
    width: 44, height: 44, borderRadius: 14, backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
  },
  availBadge: {
    position: 'absolute', top: Platform.OS === 'ios' ? 56 : 40,
    alignSelf: 'center',
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: 20, borderWidth: 1, zIndex: 10,
  },
  availDot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
  availText: { fontSize: 10, fontWeight: '900', letterSpacing: 1 },

  maintenanceBanner: {
    backgroundColor: 'rgba(255, 149, 0, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 149, 0, 0.3)',
    borderRadius: 12,
    padding: 12,
    marginHorizontal: 24,
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  maintenanceBannerText: {
    color: '#FF9500',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },

  content: { flex: 1 },
  infoSection: { padding: 24, paddingBottom: 0 },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  turfName: { color: COLORS.textMain, fontSize: 26, fontWeight: '800', flex: 1, letterSpacing: -0.5 },
  ratingPill: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(137,233,0,0.1)',
    paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, marginLeft: 8,
  },
  ratingText: { color: COLORS.kiwi, fontWeight: '800', fontSize: 14, marginLeft: 4 },
  metaRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6, gap: 6 },
  metaText: { color: COLORS.textMuted, fontSize: 13, fontWeight: '500' },
  dot2: { color: COLORS.textMuted },

  section: { paddingHorizontal: 24, marginTop: 28 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  sectionLabel: { color: COLORS.textMuted, fontSize: 11, fontWeight: '900', letterSpacing: 2, marginBottom: 14 },
  reviewCount: { color: COLORS.textMuted, fontSize: 11, fontWeight: '600', marginBottom: 14 },

  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  sportPill: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(137,233,0,0.1)', paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 12, borderWidth: 1, borderColor: 'rgba(137,233,0,0.2)',
  },
  sportText: { color: COLORS.kiwi, fontWeight: '700', fontSize: 13 },
  sizePill: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: COLORS.surface, paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 12, borderWidth: 1, borderColor: COLORS.border,
  },
  sizeText: { color: COLORS.textMuted, fontWeight: '700', fontSize: 13 },

  description: { color: COLORS.textMuted, fontSize: 14, lineHeight: 22 },

  glimpseGrid: { flexDirection: 'row', gap: 12 },
  glimpseItem: { flex: 1, height: 120, borderRadius: 16, overflow: 'hidden', position: 'relative' },
  glimpseImage: { width: '100%', height: '100%' },
  glimpseLabel: {
    position: 'absolute', bottom: 8, left: 8, right: 8,
    backgroundColor: COLORS.kiwi, paddingVertical: 4, paddingHorizontal: 8,
    borderRadius: 8, flexDirection: 'row', alignItems: 'center', gap: 4,
  },
  glimpseLabelText: { color: '#000', fontSize: 8, fontWeight: '900' },

  amenititesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  amenityChip: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: COLORS.surface, paddingHorizontal: 14, paddingVertical: 10,
    borderRadius: 14, borderWidth: 1, borderColor: COLORS.border,
  },
  amenityText: { color: COLORS.textMain, fontSize: 13, fontWeight: '600' },

  rulesCard: { backgroundColor: COLORS.surface, borderRadius: 20, padding: 16, gap: 12, borderWidth: 1, borderColor: COLORS.border },
  ruleItem: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  ruleText: { color: COLORS.textMuted, fontSize: 13, flex: 1, lineHeight: 18 },

  ownerCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.surface, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  ownerAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(137,233,0,0.1)', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(137,233,0,0.2)' },
  ownerInitial: { color: COLORS.kiwi, fontSize: 20, fontWeight: '800' },
  ownerInfo: { flex: 1, marginLeft: 12 },
  ownerName: { color: COLORS.textMain, fontSize: 15, fontWeight: '700' },
  ownerRole: { color: COLORS.textMuted, fontSize: 11 },
  callBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: 'rgba(137,233,0,0.1)', justifyContent: 'center', alignItems: 'center' },

  reviewsScroll: { paddingRight: 24, gap: 12 },
  reviewCard: { width: width * 0.7, backgroundColor: COLORS.surface, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  reviewHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  reviewerName: { color: COLORS.textMain, fontSize: 14, fontWeight: '700' },
  reviewerRating: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(137,233,0,0.1)', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  ratingValueText: { color: COLORS.kiwi, fontSize: 10, fontWeight: '800' },
  reviewComment: { color: COLORS.textMuted, fontSize: 12, lineHeight: 18 },

  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: COLORS.night, paddingHorizontal: 24,
    paddingTop: 16, paddingBottom: Platform.OS === 'ios' ? 36 : 24,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderTopWidth: 1, borderTopColor: COLORS.border, zIndex: 100,
  },
  priceLabel: { color: COLORS.textMuted, fontSize: 12, fontWeight: '600', marginBottom: 2 },
  price: { color: COLORS.textMain, fontSize: 24, fontWeight: '800' },
  perHr: { color: COLORS.textMuted, fontSize: 14, fontWeight: '400' },
  bookBtn: { borderRadius: 18, overflow: 'hidden', flex: 1, maxWidth: 200, marginLeft: 20 },
  bookGradient: { height: 56, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  bookText: { color: '#000', fontWeight: '900', fontSize: 15 },
  
  videoWrapper: {
    width: '100%',
    height: 200,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  video: {
    width: '100%',
    height: '100%',
  },
});
