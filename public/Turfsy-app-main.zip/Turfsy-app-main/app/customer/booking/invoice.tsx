import React, { useState, useEffect } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Dimensions, StatusBar, Platform, ActivityIndicator, Alert } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons, MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '@/src/context/AppContext';
import { InvoiceService, InvoiceData } from '@/src/services/invoiceService';
import * as Haptics from 'expo-haptics';

const { width } = Dimensions.get('window');

export default function InvoiceScreen() {
  const { COLORS, authToken } = useApp();
  const styles = getStyles(COLORS);
  const insets = useSafeAreaInsets();
  const { bookingId } = useLocalSearchParams<{ bookingId: string }>();

  const [invoice, setInvoice] = useState<InvoiceData['data'] | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (bookingId) {
      fetchInvoice();
    }
  }, [bookingId]);

  const fetchInvoice = async () => {
    setLoading(true);
    try {
      const res = await InvoiceService.getInvoiceDetails(bookingId!);
      if (res.success) {
        setInvoice(res.data);
      } else {
        Alert.alert('Error', 'Unable to load invoice details.');
      }
    } catch (err: any) {
      console.error('Failed to fetch invoice:', err);
      Alert.alert('Error', err.message || 'Network error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!bookingId) return;
    
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setDownloading(true);
    try {
      await InvoiceService.downloadInvoicePdf(bookingId, authToken);
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (err: any) {
      Alert.alert('Download Failed', err.message || 'Unable to download invoice PDF.');
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={COLORS.kiwi} />
      </View>
    );
  }

  if (!invoice) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 40 }]}>
        <Ionicons name="alert-circle-outline" size={60} color={COLORS.textMuted} />
        <Text style={{ color: COLORS.textMain, fontSize: 18, marginTop: 16, textAlign: 'center' }}>
          Invoice not found.
        </Text>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Header */}
      <View style={[styles.header, { paddingTop: Math.max(insets.top, 20) }]}>
        <TouchableOpacity style={styles.roundBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Invoice Details</Text>
        <View style={{ width: 44 }} />
      </View>

      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 140, paddingTop: 10 }}
      >
        {/* Main Invoice Card */}
        <View style={styles.invoiceCard}>
          <LinearGradient 
            colors={['rgba(137, 233, 0, 0.1)', 'transparent']} 
            style={styles.cardGradient} 
          />
          
          <View style={styles.cardHeader}>
            <View>
              <Text style={styles.bookingIdLabel}>BOOKING ID</Text>
              <Text style={styles.bookingIdValue}>#{invoice.bookingId}</Text>
            </View>
            <View style={[styles.statusBadge, { 
              backgroundColor: invoice.paymentStatus.toUpperCase() === 'PAID' ? 'rgba(137, 233, 0, 0.1)' : 'rgba(255, 69, 58, 0.1)',
              borderColor: invoice.paymentStatus.toUpperCase() === 'PAID' ? COLORS.kiwi : '#FF453A'
            }]}>
              <Text style={[styles.statusText, { 
                color: invoice.paymentStatus.toUpperCase() === 'PAID' ? COLORS.kiwi : '#FF453A'
              }]}>
                {invoice.paymentStatus.toUpperCase()}
              </Text>
            </View>
          </View>

          <View style={styles.divider} />

          {/* Turf Info */}
          <View style={styles.infoRow}>
            <View style={styles.iconBox}>
              <MaterialCommunityIcons name="soccer" size={20} color={COLORS.kiwi} />
            </View>
            <View style={styles.infoTextWrapper}>
              <Text style={styles.infoLabel}>VENUE</Text>
              <Text style={styles.infoValue}>{invoice.turf.name}</Text>
              <Text style={styles.infoSubValue}>{invoice.turf.address}, {invoice.turf.city} {invoice.turf.pincode}</Text>
              {invoice.turf.owner && (
                <Text style={[styles.infoSubValue, { fontSize: 11, marginTop: 4 }]}>
                  Contact: {invoice.turf.owner.name} ({invoice.turf.owner.contactNumber})
                </Text>
              )}
            </View>
          </View>

          {/* Date & Time */}
          <View style={styles.infoRow}>
            <View style={styles.iconBox}>
              <Ionicons name="calendar-outline" size={20} color={COLORS.kiwi} />
            </View>
            <View style={styles.infoTextWrapper}>
              <Text style={styles.infoLabel}>DATE & TIME</Text>
              <Text style={styles.infoValue}>{new Date(invoice.bookingDate).toDateString()}</Text>
              <Text style={styles.infoSubValue}>{invoice.slot}</Text>
            </View>
          </View>

          {invoice.customer && (
            <View style={styles.infoRow}>
              <View style={styles.iconBox}>
                <Ionicons name="person-outline" size={20} color={COLORS.kiwi} />
              </View>
              <View style={styles.infoTextWrapper}>
                <Text style={styles.infoLabel}>BOOKED BY</Text>
                <Text style={styles.infoValue}>{invoice.customer.name}</Text>
                <Text style={styles.infoSubValue}>{invoice.customer.phone}</Text>
                {invoice.customer.email && invoice.customer.email !== 'N/A' && (
                  <Text style={styles.infoSubValue}>{invoice.customer.email}</Text>
                )}
              </View>
            </View>
          )}

          <View style={styles.divider} />

          {/* Payment Summary */}
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Total Amount</Text>
            <Text style={styles.summaryValue}>₹{invoice.amount}</Text>
          </View>
          {invoice.paymentType && (
            <View style={styles.summaryRow}>
              <Text style={styles.summarySubLabel}>Payment Method</Text>
              <Text style={styles.summarySubValue}>{invoice.paymentType.replace(/_/g, ' ')}</Text>
            </View>
          )}
        </View>

        {/* Note Section */}
        <View style={styles.noteBox}>
          <Ionicons name="information-circle-outline" size={18} color={COLORS.textMuted} />
          <Text style={styles.noteText}>
            This is a computer-generated invoice and does not require a physical signature.
          </Text>
        </View>
      </ScrollView>

      {/* Download Button */}
      <View style={[styles.footer, { paddingBottom: Math.max(insets.bottom, 20) }]}>
        <TouchableOpacity 
          style={[styles.downloadBtn, downloading && { opacity: 0.7 }]} 
          onPress={handleDownload}
          disabled={downloading}
          activeOpacity={0.8}
        >
          <LinearGradient 
            colors={[COLORS.kiwi, '#6FC000']} 
            style={styles.btnGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            {downloading ? (
              <ActivityIndicator color="#000" size="small" />
            ) : (
              <>
                <Feather name="download" size={20} color="#000" style={{ marginRight: 10 }} />
                <Text style={styles.downloadBtnText}>Download Invoice</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.night,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  roundBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  headerTitle: {
    color: COLORS.textMain,
    fontSize: 18,
    fontWeight: '800',
  },
  content: {
    padding: 20,
  },
  invoiceCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
    borderColor: COLORS.border,
    overflow: 'hidden',
    position: 'relative',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  cardGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 100,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  bookingIdLabel: {
    color: COLORS.textMuted,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginBottom: 6,
  },
  bookingIdValue: {
    color: COLORS.textMain,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 1,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  divider: {
    height: 1,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderStyle: 'dashed',
    marginVertical: 24,
    width: '100%',
    opacity: 0.6,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  iconBox: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(137, 233, 0, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    borderWidth: 1,
    borderColor: 'rgba(137, 233, 0, 0.2)',
  },
  infoTextWrapper: {
    flex: 1,
  },
  infoLabel: {
    color: COLORS.textMuted,
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1,
    marginBottom: 4,
  },
  infoValue: {
    color: COLORS.textMain,
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  infoSubValue: {
    color: COLORS.textMuted,
    fontSize: 13,
    marginTop: 4,
    lineHeight: 18,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryLabel: {
    color: COLORS.textMain,
    fontSize: 16,
    fontWeight: '700',
  },
  summaryValue: {
    color: COLORS.kiwi,
    fontSize: 26,
    fontWeight: '900',
  },
  summarySubLabel: {
    color: COLORS.textMuted,
    fontSize: 14,
    fontWeight: '500',
  },
  summarySubValue: {
    color: COLORS.textMain,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  noteBox: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    paddingHorizontal: 10,
    gap: 10,
  },
  noteText: {
    color: COLORS.textMuted,
    fontSize: 12,
    flex: 1,
    lineHeight: 18,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingTop: 15,
    backgroundColor: COLORS.night,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  downloadBtn: {
    borderRadius: 18,
    overflow: 'hidden',
    height: 56,
  },
  btnGradient: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  downloadBtnText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '900',
  },
  backBtn: {
    marginTop: 24,
    paddingVertical: 12,
    paddingHorizontal: 24,
    backgroundColor: COLORS.surface,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  backBtnText: {
    color: COLORS.kiwi,
    fontWeight: '700',
  },
});
