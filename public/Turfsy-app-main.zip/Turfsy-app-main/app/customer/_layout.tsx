import { Stack } from 'expo-router';

export default function CustomerLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="booking/detail" options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="booking/book" options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="booking/payment" options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="booking/confirm" options={{ animation: 'slide_from_bottom', presentation: 'modal' }} />
    </Stack>
  );
}
