import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, TextInput, KeyboardAvoidingView, Platform, Alert, ActivityIndicator, StatusBar } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/src/context/AppContext';
import { UserSettingsService } from '@/src/services/userSettingsService';

export default function SecurityScreen() {
  const { COLORS, userInfo, setUserInfo, showStatusModal } = useApp();
  const [step, setStep] = useState<1 | 2>(1);
  const [loading, setLoading] = useState(false);
  const [newPhone, setNewPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [sessionToken, setSessionToken] = useState('');

  const handleRequestOtp = async () => {
    if (newPhone.length !== 10) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      showStatusModal({
        type: 'warning',
        title: 'Invalid Number',
        message: 'Please enter a valid 10-digit mobile number to proceed with account verification.'
      });
      return;
    }

    setLoading(true);
    try {
      const res = await UserSettingsService.requestPhoneChange(newPhone);
      if (res.success) {
        setSessionToken(res.data.sessionToken);
        setStep(2);
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      }
    } catch (error: any) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      showStatusModal({
        type: 'error',
        title: 'Request Failed',
        message: error.message || 'We could not send a code to that number. Please try again later.'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyChange = async () => {
    if (otp.length !== 6) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      showStatusModal({
        type: 'warning',
        title: 'Authentication Required',
        message: 'Please enter the complete 6-digit verification code sent to your phone.'
      });
      return;
    }

    setLoading(true);
    try {
      const res = await UserSettingsService.verifyPhoneChange({
        newPhone,
        otp,
        sessionToken
      });

      if (res.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        // Update local session info
        if (userInfo) {
          setUserInfo({ ...userInfo, phone: res.data.phone });
        }
        showStatusModal({
          type: 'success',
          title: 'Identity Updated',
          message: 'Your phone number has been successfully updated. Use this number for all subsequent logins.',
          onAction: () => router.back(),
          actionText: 'Return Home'
        });
      }
    } catch (error: any) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      showStatusModal({
        type: 'error',
        title: 'Verification Failed',
        message: error.message || 'The code you entered is invalid or has expired. Please try requesting a new one.'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />
      
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain }]}>Security Settings</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>Account Security</Text>
            <View style={[styles.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
               <View style={styles.currentInfo}>
                  <Ionicons name="phone-portrait-outline" size={20} color={COLORS.textMuted} />
                  <View>
                    <Text style={[styles.currentLabel, { color: COLORS.textMuted }]}>Current Phone Number</Text>
                    <Text style={[styles.currentValue, { color: COLORS.textMain }]}>+91 {userInfo?.phone || '9876543210'}</Text>
                  </View>
               </View>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>
              {step === 1 ? 'Step 1: New Phone Number' : 'Step 2: Verification'}
            </Text>
            
            {step === 1 ? (
              <View style={[styles.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
                <Text style={[styles.label, { color: COLORS.textMuted }]}>ENTER NEW NUMBER</Text>
                <View style={styles.inputWrapper}>
                   <Text style={[styles.prefix, { color: COLORS.textMuted }]}>+91</Text>
                   <TextInput
                     style={[styles.input, { color: COLORS.textMain }]}
                     value={newPhone}
                     onChangeText={setNewPhone}
                     placeholder="98765 43210"
                     placeholderTextColor={COLORS.placeholder}
                     keyboardType="phone-pad"
                     maxLength={10}
                   />
                </View>
                <TouchableOpacity 
                   style={[styles.actionBtn, { backgroundColor: COLORS.kiwi }]}
                   onPress={handleRequestOtp}
                   disabled={loading}
                >
                   {loading ? <ActivityIndicator color="#000" /> : <Text style={styles.actionBtnText}>Request OTP</Text>}
                </TouchableOpacity>
              </View>
            ) : (
              <View style={[styles.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
                <Text style={[styles.label, { color: COLORS.textMuted }]}>VERIFICATION CODE</Text>
                <TextInput
                  style={[styles.otpInput, { backgroundColor: COLORS.background, color: COLORS.textMain, borderColor: COLORS.border, letterSpacing: 8 }]}
                  value={otp}
                  onChangeText={setOtp}
                  placeholder="Enter 6-digit OTP"
                  placeholderTextColor={COLORS.placeholder}
                  keyboardType="number-pad"
                  maxLength={6}
                  textAlign="center"
                />
                <Text style={[styles.hint, { color: COLORS.textMuted }]}>
                  We sent a code to +91 {newPhone}.
                </Text>
                <TouchableOpacity 
                   style={[styles.actionBtn, { backgroundColor: COLORS.kiwi }]}
                   onPress={handleVerifyChange}
                   disabled={loading}
                >
                   {loading ? <ActivityIndicator color="#000" /> : <Text style={styles.actionBtnText}>Verify & Update</Text>}
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setStep(1)} style={styles.resendBtn}>
                   <Text style={[styles.resendText, { color: COLORS.kiwi }]}>Change Number</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          <View style={styles.securityNote}>
             <Ionicons name="information-circle" size={16} color={COLORS.textMuted} />
             <Text style={[styles.noteText, { color: COLORS.textMuted }]}>
               Phone number is used for OTP-based secure login. Changing this will update your primary account credential.
             </Text>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 60 : 40, paddingBottom: 20, borderBottomWidth: 1
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scrollContent: { padding: 24 },
  section: { marginBottom: 32 },
  sectionTitle: { fontSize: 11, fontWeight: '900', letterSpacing: 1.5, marginBottom: 12, textTransform: 'uppercase' },
  card: { padding: 20, borderRadius: 24, borderWidth: 1 },
  currentInfo: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  currentLabel: { fontSize: 11, fontWeight: '700', textTransform: 'uppercase' },
  currentValue: { fontSize: 18, fontWeight: '800', marginTop: 2 },
  label: { fontSize: 10, fontWeight: '800', marginBottom: 12 },
  inputWrapper: { 
    flexDirection: 'row', alignItems: 'center', 
    backgroundColor: 'rgba(0,0,0,0.05)', borderRadius: 16, paddingHorizontal: 16 
  },
  prefix: { fontSize: 16, fontWeight: '700', marginRight: 8 },
  input: { flex: 1, height: 56, fontSize: 16, fontWeight: '800' },
  otpInput: { height: 60, borderRadius: 16, borderWidth: 1, fontSize: 20, fontWeight: '900' },
  actionBtn: { 
    height: 56, borderRadius: 18, justifyContent: 'center', alignItems: 'center', 
    marginTop: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 8 
  },
  actionBtnText: { color: '#000', fontSize: 15, fontWeight: '900', textTransform: 'uppercase' },
  hint: { fontSize: 12, textAlign: 'center', marginTop: 16, opacity: 0.7 },
  resendBtn: { marginTop: 20, alignSelf: 'center' },
  resendText: { fontSize: 14, fontWeight: '700' },
  securityNote: { flexDirection: 'row', gap: 10, padding: 16, opacity: 0.8 },
  noteText: { flex: 1, fontSize: 11, lineHeight: 16 },
});
