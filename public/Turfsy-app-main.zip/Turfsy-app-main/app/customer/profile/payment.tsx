import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, TextInput, KeyboardAvoidingView, Platform, Alert, ActivityIndicator, StatusBar } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/src/context/AppContext';
import { UserSettingsService, PaymentSettings } from '@/src/services/userSettingsService';

export default function PaymentSettingsScreen() {
  const { COLORS, showStatusModal, refreshProfile } = useApp();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [upiId, setUpiId] = useState('');
  const [method, setMethod] = useState<'UPI' | 'NET_BANKING' | 'CARD'>('UPI');

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await UserSettingsService.getPaymentSettings();
      if (res.success) {
        setUpiId(res.data.upiId || '');
        setMethod(res.data.defaultPaymentMethod || 'UPI');
      }
    } catch (error) {
      console.error('Failed to fetch payment settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!upiId) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      showStatusModal({
        type: 'warning',
        title: 'UPI Required',
        message: 'Please provide a valid UPI ID (e.g. name@upi) to receive refunds and payouts.'
      });
      return;
    }

    setSaving(true);
    try {
      const res = await UserSettingsService.updatePaymentSettings({
        upiId,
        defaultPaymentMethod: method
      });

      if (res.success) {
        // Refresh global profile state to remove "Payment Setup Required" nudges
        await refreshProfile();
        
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        showStatusModal({
          type: 'success',
          title: 'Settings Saved',
          message: 'Your payment configuration has been updated successfully.'
        });
        setTimeout(() => router.back(), 1500);
      }
    } catch (error: any) {
      const msg = error.response?.data?.message || 'We could not update your payment settings at this time.';
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      showStatusModal({
        type: 'error',
        title: 'Update Failed',
        message: msg
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: COLORS.background, justifyContent: 'center' }]}>
        <ActivityIndicator color={COLORS.kiwi} size="large" />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />
      
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain }]}>Payment Settings</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>UPI Configuration</Text>
            <View style={[styles.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
               <Text style={[styles.label, { color: COLORS.textMuted }]}>PRIMARY UPI ID</Text>
               <TextInput
                 style={[styles.input, { backgroundColor: COLORS.background, color: COLORS.textMain, borderColor: COLORS.border }]}
                 value={upiId}
                 onChangeText={setUpiId}
                 placeholder="yourname@upi"
                 placeholderTextColor={COLORS.placeholder}
                 autoCapitalize="none"
               />
               <Text style={[styles.hint, { color: COLORS.textMuted }]}>
                 This ID will be used for your 50% cash deposit refunds and priority payouts.
               </Text>
            </View>
          </View>

          {/* Payout method section removed since UPI is the only option */}

          <TouchableOpacity 
            style={[styles.saveBtn, { backgroundColor: COLORS.kiwi }]} 
            onPress={handleSave}
            disabled={saving}
          >
            {saving ? <ActivityIndicator color="#000" /> : <Text style={styles.saveBtnText}>Save Settings</Text>}
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 60 : 40, paddingBottom: 20, borderBottomWidth: 1
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scrollContent: { padding: 24 },
  section: { marginBottom: 32 },
  sectionTitle: { fontSize: 11, fontWeight: '900', letterSpacing: 1.5, marginBottom: 12, textTransform: 'uppercase' },
  card: { padding: 20, borderRadius: 24, borderWidth: 1 },
  label: { fontSize: 10, fontWeight: '800', marginBottom: 10 },
  input: { height: 56, borderRadius: 16, borderWidth: 1, paddingHorizontal: 20, fontSize: 15, fontWeight: '600' },
  hint: { fontSize: 12, marginTop: 12, lineHeight: 18, opacity: 0.8 },
  methodList: { gap: 12 },
  methodItem: { 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', 
    padding: 18, borderRadius: 20, borderWidth: 1.5 
  },
  methodInfo: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  methodLabel: { fontSize: 15, fontWeight: '700' },
  radio: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, justifyContent: 'center', alignItems: 'center' },
  radioDot: { width: 10, height: 10, borderRadius: 5 },
  saveBtn: { 
    height: 60, borderRadius: 20, justifyContent: 'center', alignItems: 'center', 
    marginTop: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 
  },
  saveBtnText: { color: '#000', fontSize: 17, fontWeight: '900' },
});
