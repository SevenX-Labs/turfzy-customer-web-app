import React, { useState, useCallback } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, Platform, StatusBar, Switch, ActivityIndicator } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '@/src/context/AppContext';
import { AppLockService } from '@/src/services/appLockService';

export default function SecurityMenuScreen() {
  const { COLORS } = useApp();
  const [appLockEnabled, setAppLockEnabled] = useState(false);
  const [useBiometric, setUseBiometric] = useState(false);
  const [settings, setSettings] = useState<any>(null);
  const [isChecking, setIsChecking] = useState(false);

  useFocusEffect(
    useCallback(() => {
      const loadSettings = async () => {
        const s = await AppLockService.getSettings();
        setSettings(s);
        setAppLockEnabled(s.enabled);
        setUseBiometric(s.method === 'BIOMETRIC');
      };
      loadSettings();
    }, [])
  );

  const toggleAppLock = async (value: boolean) => {
    if (value) {
      // Check if MPIN is actually set on the backend
      setIsChecking(true);
      const isMpinSet = await AppLockService.checkMpinStatus();
      setIsChecking(false);

      if (!isMpinSet) {
        // No MPIN created yet — redirect to MPIN setup
        router.push({ pathname: '/auth/mpin-setup', params: { next: '/customer/profile/security' } } as any);
        return;
      }
    }

    setAppLockEnabled(value);
    if (settings) {
      const newSettings = { ...settings, enabled: value };
      await AppLockService.saveSettings(newSettings);
      setSettings(newSettings);
    }
  };

  const toggleBiometric = async (value: boolean) => {
    setUseBiometric(value);
    if (settings) {
      const newSettings = {
        ...settings,
        method: value ? 'BIOMETRIC' : 'MPIN',
      };
      await AppLockService.saveSettings(newSettings);
      setSettings(newSettings);
    }
  };

  const Row = ({ icon, label, onPress, isLast }: any) => (
    <TouchableOpacity
      style={[styles.row, !isLast && { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}
      onPress={onPress} activeOpacity={0.7}
    >
      <View style={[styles.rowIcon, { backgroundColor: COLORS.kiwi + '14' }]}>
        <Ionicons name={icon} size={18} color={COLORS.kiwi} />
      </View>
      <Text style={[styles.rowLabel, { color: COLORS.textMain }]}>{label}</Text>
      <Ionicons name="chevron-forward" size={16} color={COLORS.textMuted} style={{ opacity: 0.45 }} />
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />
      
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain }]}>Security & Privacy</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>App Security</Text>
        <View style={[styles.group, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
          
          <View style={[styles.row, { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}>
            <View style={[styles.rowIcon, { backgroundColor: COLORS.kiwi + '14' }]}>
              <Ionicons name="lock-closed" size={18} color={COLORS.kiwi} />
            </View>
            <Text style={[styles.rowLabel, { color: COLORS.textMain }]}>Enable App Lock</Text>
            {isChecking ? (
              <ActivityIndicator size="small" color={COLORS.kiwi} />
            ) : (
              <Switch
                value={appLockEnabled}
                onValueChange={toggleAppLock}
                disabled={isChecking}
                trackColor={{ false: COLORS.border, true: COLORS.kiwi }}
                thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : (appLockEnabled ? '#FFFFFF' : '#f4f3f4')}
              />
            )}
          </View>

          {appLockEnabled && (
            <>
              <View style={[styles.row, { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}>
                <View style={[styles.rowIcon, { backgroundColor: COLORS.kiwi + '14' }]}>
                  <Ionicons name="finger-print" size={18} color={COLORS.kiwi} />
                </View>
                <Text style={[styles.rowLabel, { color: COLORS.textMain }]}>Use Biometrics</Text>
                <Switch
                  value={useBiometric}
                  onValueChange={toggleBiometric}
                  trackColor={{ false: COLORS.border, true: COLORS.kiwi }}
                  thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : (useBiometric ? '#FFFFFF' : '#f4f3f4')}
                />
              </View>
              <Row icon="keypad-outline" label="Change MPIN" onPress={() => router.push('/auth/change-mpin' as any)} />
            </>
          )}
          
          <Row icon="phone-portrait-outline" label="Change Phone Number" onPress={() => router.push('/customer/profile/change-phone' as any)} isLast />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 60 : 40, paddingBottom: 20, borderBottomWidth: 1
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scrollContent: { padding: 24 },
  sectionTitle: { fontSize: 11, fontWeight: '900', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 12, marginLeft: 2 },
  group: { borderRadius: 20, borderWidth: 1, overflow: 'hidden' },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 13, gap: 12 },
  rowIcon: { width: 34, height: 34, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  rowLabel: { flex: 1, fontSize: 14, fontWeight: '600' },
});
