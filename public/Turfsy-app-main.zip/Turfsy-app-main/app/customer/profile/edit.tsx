import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, TextInput, KeyboardAvoidingView, Platform, Alert, Image, ActivityIndicator, StatusBar, Modal, Dimensions } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { Animated } from 'react-native';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/src/context/AppContext';
import { UserService } from '@/src/services/userService';
import LoadingOverlay from '@/src/components/LoadingOverlay';

const { width } = Dimensions.get('window');

export default function EditProfileScreen() {
  const { COLORS, userProfile, setUserProfile, showStatusModal } = useApp();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const scrollRef = useRef<ScrollView | null>(null);
  const upiInputRef = useRef<TextInput | null>(null);
  const [upiSectionY, setUpiSectionY] = useState<number | null>(null);

  // ─── Profile Fields ───────────────────────────────────────────────────────
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [sport, setSport] = useState<'FOOTBALL' | 'CRICKET'>('FOOTBALL');
  const [upiId, setUpiId] = useState('');
  const [avatarUri, setAvatarUri] = useState<string | null>(null);

  // ─── Username Availability ────────────────────────────────────────────────
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameStatus, setUsernameStatus] = useState<'available' | 'taken' | 'invalid' | null>(null);
  const [initialUsername, setInitialUsername] = useState('');

  useEffect(() => {
    if (!username || username === initialUsername) {
      setUsernameStatus(null);
      return;
    }

    if (username.length < 4) {
      setUsernameStatus('invalid');
      return;
    }

    const timer = setTimeout(async () => {
      setCheckingUsername(true);
      try {
        const res = await UserService.checkUsername(username);
        setUsernameStatus(res.available ? 'available' : 'taken');
      } catch (err) {
        setUsernameStatus(null);
      } finally {
        setCheckingUsername(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [username, initialUsername]);

  // ─── Home Address Fields ──────────────────────────────────────────────────
  const [houseNumber, setHouseNumber] = useState('');
  const [societyName, setSocietyName] = useState('');
  const [landmark, setLandmark] = useState('');
  const [roadName, setRoadName] = useState('');

  // ─── Address section toggle ───────────────────────────────────────────────
  const [addressExpanded, setAddressExpanded] = useState(false);

  useEffect(() => {
    const initProfile = async () => {
      if (!userProfile) {
        setLoading(true);
        try {
          const response = await UserService.getProfile();
          if (response.success) {
            setUserProfile(response.data);
          }
        } catch (error) {
          console.warn('Failed to fetch profile on edit mount:', error);
        } finally {
          setLoading(false);
        }
      }
    };
    initProfile();
  }, []);

  useEffect(() => {
    if (userProfile) {
      setName(userProfile.name || '');
      setUsername(userProfile.username || '');
      setInitialUsername(userProfile.username || '');
      setEmail(userProfile.email || '');
      setCity(userProfile.city || '');
      setSport((userProfile.preferredSport as any) || 'FOOTBALL');
      setUpiId(userProfile.payment?.upiId || '');
      setAvatarUri(userProfile.avatarUrl || null);
    }
  }, [userProfile]);

  const handleImagePick = async (fromCamera: boolean) => {
    const permissionResult = fromCamera
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      Alert.alert('Permission Denied', `We need access to your ${fromCamera ? 'camera' : 'gallery'} to upload a photo.`);
      return;
    }

    const result = fromCamera
      ? await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.5 })
      : await ImagePicker.launchImageLibraryAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.5 });

    if (!result.canceled) {
      setAvatarUri(result.assets[0].uri);
    }
  };

  const handleSave = async () => {
    if (!name || !email) {
      Alert.alert('Required Fields', 'Please fill in at least your name and email.');
      return;
    }

    setSaving(true);
    let stage: 'profile' | 'address' | 'upi' | 'avatar' | 'refresh' = 'profile';
    const extractMessages = (err: any): string[] => {
      const msgs: string[] = [];
      const push = (m: any) => {
        if (typeof m === 'string' && m.trim()) msgs.push(m.trim());
      };
      if (Array.isArray(err?.message)) err.message.forEach(push);
      push(err?.message);
      if (Array.isArray(err?.messages)) err.messages.forEach(push);
      push(err?.error);
      push(err?.error?.message);
      if (Array.isArray(err?.error?.message)) err.error.message.forEach(push);
      return msgs;
    };

    const hasUpiMissing = (messages: string[]) => {
      const all = messages.join(' ').toLowerCase();
      const mentionsUpi = all.includes('upi');
      const indicatesMissing =
        all.includes('missing') ||
        all.includes('required') ||
        all.includes('not added') ||
        all.includes('not provided') ||
        all.includes('empty') ||
        all.includes('should not be empty');
      return mentionsUpi && indicatesMissing;
    };

    try {
      // 1. Update core profile fields
      stage = 'profile';
      await UserService.updateProfile({
        name,
        username,
        email,
        city,
        preferredSport: sport,
      });

      // 2. Update home address if any field was entered
      const hasAddress = houseNumber || societyName || landmark || roadName;
      if (hasAddress) {
        stage = 'address';
        await UserService.updateHomeAddress({
          houseNumber: houseNumber || undefined,
          societyName: societyName || undefined,
          landmark: landmark || undefined,
          roadName: roadName || undefined,
        });
      }

      // 3. Update UPI if changed and NOT empty
      // We skip empty strings to avoid triggering backend validation errors 
      // when a user just wants to update their name/email without adding UPI.
      if (upiId && upiId.trim() !== '' && upiId !== userProfile?.payment?.upiId) {
        stage = 'upi';
        await UserService.savePaymentDetails(upiId);
      }

      // 4. Upload Avatar if it's a local URI (starting with file://)
      if (avatarUri && avatarUri.startsWith('file://')) {
        stage = 'avatar';
        const formData = new FormData();
        // @ts-ignore
        formData.append('file', {
          uri: avatarUri,
          name: 'avatar.jpg',
          type: 'image/jpeg',
        });
        await UserService.uploadAvatar(formData);
      }

      // 5. Reload full profile
      stage = 'refresh';
      const response = await UserService.getProfile();
      if (response.success) {
        setUserProfile(response.data);
        // Clear address fields — they're now embedded in the returned `address` string
        setHouseNumber('');
        setSocietyName('');
        setLandmark('');
        setRoadName('');
        setAddressExpanded(false);
      }

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      showStatusModal({
        type: 'success',
        title: 'Profile Updated!',
        message: 'Your changes have been saved to your professional profile.',
      });
      setTimeout(() => {
        router.back();
      }, 2500);
    } catch (error: any) {
      console.error(error);
      const messages = extractMessages(error);

      const title =
        stage === 'avatar' ? 'Photo Upload Failed' :
        stage === 'address' ? 'Address Update Failed' :
        stage === 'upi' ? 'UPI Update Failed' : 'Update Failed';

      let message = messages.length ? messages[0] : 'Something went wrong while saving your profile. Please try again.';
      
      // Clean up common backend technical terms for users
      if (message.toLowerCase().includes('validation')) message = 'Please ensure all fields are filled correctly.';
      if (message.toLowerCase().includes('internal server')) message = 'Our servers are a bit busy. Please try again in a moment.';

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      showStatusModal({
        type: 'error',
        title: title,
        message: message,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />
      {saving && <LoadingOverlay message="Saving updates..." />}

      {/* HEADER */}
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain, marginLeft: -20 }]}>Edit Profile</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView ref={(r) => { scrollRef.current = r; }} contentContainerStyle={styles.scrollContent}>

          {/* AVATAR SECTION */}
          <View style={styles.avatarSection}>
            <View style={[styles.avatarWrapper, { borderColor: COLORS.kiwi }]}>
              {avatarUri ? (
                <Image
                  source={{
                    uri: avatarUri.startsWith('http') || avatarUri.startsWith('file') || avatarUri.startsWith('data')
                      ? avatarUri
                      : `https://turfsy.onrender.com${avatarUri.startsWith('/') ? '' : '/'}${avatarUri}`
                  }}
                  style={styles.avatar}
                />
              ) : (
                <Ionicons name="person" size={50} color={COLORS.textMuted} />
              )}
              <TouchableOpacity
                style={[styles.cameraBadge, { backgroundColor: COLORS.kiwi }]}
                onPress={() => {
                  Alert.alert('Profile Photo', 'Choose a source', [
                    { text: 'Camera', onPress: () => handleImagePick(true) },
                    { text: 'Gallery', onPress: () => handleImagePick(false) },
                    { text: 'Cancel', style: 'cancel' }
                  ]);
                }}
              >
                <Ionicons name="camera" size={20} color="#000" />
              </TouchableOpacity>
            </View>
            <Text style={[styles.avatarHint, { color: COLORS.textMuted }]}>Tap camera to change photo</Text>
          </View>

          {/* ── PERSONAL INFO FORM ── */}
          <View style={styles.form}>

            <Text style={[styles.sectionLabel, { color: COLORS.textMuted }]}>PERSONAL INFORMATION</Text>

            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: COLORS.textMuted }]}>FULL NAME</Text>
              <TextInput
                style={[styles.input, { backgroundColor: COLORS.surface, color: COLORS.textMain, borderColor: COLORS.border }]}
                value={name}
                onChangeText={setName}
                placeholder="Your Name"
                placeholderTextColor={COLORS.placeholder}
              />
            </View>

            <View style={styles.inputGroup}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <Text style={[styles.label, { color: COLORS.textMuted, marginBottom: 0 }]}>USERNAME HANDLE</Text>
                {checkingUsername && <ActivityIndicator size="small" color={COLORS.kiwi} />}
                {!checkingUsername && usernameStatus === 'available' && (
                  <View style={{ backgroundColor: COLORS.kiwi + '20', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 }}>
                    <Text style={{ color: COLORS.kiwi, fontSize: 9, fontWeight: '900' }}>AVAILABLE</Text>
                  </View>
                )}
                {!checkingUsername && usernameStatus === 'taken' && (
                  <View style={{ backgroundColor: '#FF453A20', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 }}>
                    <Text style={{ color: '#FF453A', fontSize: 9, fontWeight: '900' }}>ALREADY TAKEN</Text>
                  </View>
                )}
                {!checkingUsername && usernameStatus === 'invalid' && (
                  <View style={{ backgroundColor: COLORS.surface, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: COLORS.border }}>
                    <Text style={{ color: COLORS.textMuted, fontSize: 9, fontWeight: '900' }}>MIN 4 CHARS</Text>
                  </View>
                )}
              </View>
              <TextInput
                style={[styles.input, { backgroundColor: COLORS.surface, color: COLORS.textMain, borderColor: usernameStatus === 'taken' ? '#FF453A' : COLORS.border }]}
                value={username}
                onChangeText={(val) => setUsername(val.replace(/\s/g, '').toLowerCase())}
                placeholder="unique_handle"
                placeholderTextColor={COLORS.placeholder}
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: COLORS.textMuted }]}>EMAIL ADDRESS</Text>
              <TextInput
                style={[styles.input, { backgroundColor: COLORS.surface, color: COLORS.textMain, borderColor: COLORS.border }]}
                value={email}
                onChangeText={setEmail}
                placeholder="email@example.com"
                placeholderTextColor={COLORS.placeholder}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: COLORS.textMuted }]}>CITY</Text>
              <TextInput
                style={[styles.input, { backgroundColor: COLORS.surface, color: COLORS.textMain, borderColor: COLORS.border }]}
                value={city}
                onChangeText={setCity}
                placeholder="Mumbai / Thane / Pune"
                placeholderTextColor={COLORS.placeholder}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: COLORS.textMuted }]}>UPI ID (FOR PAYMENTS)</Text>
              <View onLayout={(e) => setUpiSectionY(e.nativeEvent.layout.y)}>
                <TextInput
                  ref={(r) => { upiInputRef.current = r; }}
                  style={[styles.input, { backgroundColor: COLORS.surface, color: COLORS.textMain, borderColor: COLORS.border }]}
                  value={upiId}
                  onChangeText={setUpiId}
                  placeholder="username@upi"
                  placeholderTextColor={COLORS.placeholder}
                  autoCapitalize="none"
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: COLORS.textMuted }]}>PREFERRED SPORT</Text>
              <View style={styles.sportRow}>
                {[
                  { id: 'FOOTBALL', label: 'Football', icon: 'football' },
                  { id: 'CRICKET', label: 'Cricket', icon: 'tennisball' },
                ].map((s) => {
                  const isSelected = sport === s.id;
                  return (
                    <TouchableOpacity
                      key={s.id}
                      style={[
                        styles.sportBtn,
                        { backgroundColor: isSelected ? COLORS.kiwi + '20' : COLORS.surface, borderColor: isSelected ? COLORS.kiwi : COLORS.border }
                      ]}
                      onPress={() => setSport(s.id as any)}
                    >
                      <Ionicons name={s.icon as any} size={20} color={isSelected ? COLORS.kiwi : COLORS.textMuted} />
                      <Text style={[styles.sportText, { color: isSelected ? COLORS.textMain : COLORS.textMuted }]}>{s.label}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>

            {/* ── HOME ADDRESS SECTION ── */}
            <View style={[styles.addressCard, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
              <TouchableOpacity
                style={styles.addressHeader}
                activeOpacity={0.8}
                onPress={() => setAddressExpanded(!addressExpanded)}
              >
                <View style={styles.addressHeaderLeft}>
                  <View style={[styles.addressIconBox, { backgroundColor: COLORS.kiwi + '18' }]}>
                    <Ionicons name="home" size={20} color={COLORS.kiwi} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.addressTitle, { color: COLORS.textMain }]}>Home Address</Text>
                    {userProfile?.address ? (
                      <Text style={[styles.addressPreview, { color: COLORS.textMuted }]} numberOfLines={1}>
                        {userProfile.address}
                      </Text>
                    ) : (
                      <Text style={[styles.addressPreview, { color: COLORS.placeholder }]}>
                        Tap to add your home details
                      </Text>
                    )}
                  </View>
                </View>
                <Ionicons
                  name={addressExpanded ? 'chevron-up' : 'chevron-down'}
                  size={20}
                  color={COLORS.textMuted}
                />
              </TouchableOpacity>

              {addressExpanded && (
                <View style={styles.addressFields}>
                  <View style={[styles.addressDivider, { backgroundColor: COLORS.border }]} />

                  <View style={styles.inputGroup}>
                    <Text style={[styles.label, { color: COLORS.textMuted }]}>HOUSE / FLAT NO.</Text>
                    <TextInput
                      style={[styles.input, { backgroundColor: COLORS.background, color: COLORS.textMain, borderColor: COLORS.border }]}
                      value={houseNumber}
                      onChangeText={setHouseNumber}
                      placeholder="e.g. C-1204"
                      placeholderTextColor={COLORS.placeholder}
                    />
                  </View>

                  <View style={styles.inputGroup}>
                    <Text style={[styles.label, { color: COLORS.textMuted }]}>SOCIETY / BUILDING NAME</Text>
                    <TextInput
                      style={[styles.input, { backgroundColor: COLORS.background, color: COLORS.textMain, borderColor: COLORS.border }]}
                      value={societyName}
                      onChangeText={setSocietyName}
                      placeholder="e.g. Blue Diamond Society"
                      placeholderTextColor={COLORS.placeholder}
                    />
                  </View>

                  <View style={styles.inputGroup}>
                    <Text style={[styles.label, { color: COLORS.textMuted }]}>LANDMARK</Text>
                    <TextInput
                      style={[styles.input, { backgroundColor: COLORS.background, color: COLORS.textMain, borderColor: COLORS.border }]}
                      value={landmark}
                      onChangeText={setLandmark}
                      placeholder="e.g. Near Central Bank"
                      placeholderTextColor={COLORS.placeholder}
                    />
                  </View>

                  <View style={styles.inputGroup}>
                    <Text style={[styles.label, { color: COLORS.textMuted }]}>ROAD / STREET NAME</Text>
                    <TextInput
                      style={[styles.input, { backgroundColor: COLORS.background, color: COLORS.textMain, borderColor: COLORS.border }]}
                      value={roadName}
                      onChangeText={setRoadName}
                      placeholder="e.g. Link Road"
                      placeholderTextColor={COLORS.placeholder}
                    />
                  </View>

                  <View style={[styles.addressNote, { backgroundColor: COLORS.kiwi + '12' }]}>
                    <Ionicons name="information-circle-outline" size={16} color={COLORS.kiwi} />
                    <Text style={[styles.addressNoteText, { color: COLORS.kiwi }]}>
                      Fields will be combined into a single home address on save.
                    </Text>
                  </View>
                </View>
              )}
            </View>

            <TouchableOpacity
              style={[styles.updateBtn, { backgroundColor: COLORS.kiwi }]}
              activeOpacity={0.9}
              onPress={handleSave}
              disabled={saving}
            >
              {saving ? (
                <ActivityIndicator color="#000" />
              ) : (
                <>
                  <Text style={styles.updateBtnText}>Update Changes</Text>
                  <Ionicons name="checkmark-circle" size={20} color="#000" />
                </>
              )}
            </TouchableOpacity>
          </View>

          <View style={{ height: 100 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : (StatusBar.currentHeight || 0) + 10,
    paddingBottom: 20,
    borderBottomWidth: 1,
  },
  backBtn: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '800',
  },
  scrollContent: {
    paddingBottom: 40,
  },
  avatarSection: {
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 20,
  },
  avatarWrapper: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    overflow: 'visible',
  },
  avatar: {
    width: '100%',
    height: '100%',
    borderRadius: 60,
  },
  cameraBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    borderColor: '#000',
  },
  avatarHint: {
    fontSize: 12,
    marginTop: 10,
    fontWeight: '500',
  },
  form: {
    paddingHorizontal: 24,
    marginTop: 20,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.5,
    marginBottom: 10,
  },
  input: {
    height: 56,
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 20,
    fontSize: 15,
    fontWeight: '600',
  },
  sportRow: {
    flexDirection: 'row',
    gap: 12,
  },
  sportBtn: {
    flex: 1,
    height: 56,
    borderRadius: 16,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  sportText: {
    fontSize: 14,
    fontWeight: '700',
  },
  // ── Address Card ──
  addressCard: {
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 24,
    overflow: 'hidden',
  },
  addressHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 18,
  },
  addressHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 14,
  },
  addressIconBox: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addressTitle: {
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  addressPreview: {
    fontSize: 12,
    fontWeight: '500',
  },
  addressDivider: {
    height: 1,
    marginHorizontal: 18,
    marginBottom: 18,
  },
  addressFields: {
    paddingHorizontal: 18,
    paddingBottom: 18,
  },
  addressNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginTop: 4,
  },
  addressNoteText: {
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  updateBtn: {
    height: 60,
    borderRadius: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
    gap: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  updateBtnText: {
    fontSize: 17,
    fontWeight: '900',
    color: '#000',
    letterSpacing: 0.2,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  successCard: {
    width: width * 0.85,
    padding: 32,
    borderRadius: 32,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.4,
    shadowRadius: 30,
    elevation: 20,
  },
  successIconBox: {
    width: 80,
    height: 80,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: '900',
    textAlign: 'center',
    marginBottom: 10,
  },
  successSub: {
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 22,
    opacity: 0.8,
  },
});
