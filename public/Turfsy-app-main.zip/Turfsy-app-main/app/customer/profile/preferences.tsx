import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, Switch, ActivityIndicator, StatusBar, Alert, Platform } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/src/context/AppContext';
import { UserSettingsService, UserPreferences } from '@/src/services/userSettingsService';

export default function PreferencesScreen() {
  const { COLORS } = useApp();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [prefs, setPrefs] = useState<UserPreferences>({
    notificationsEnabled: true,
    preferredTime: 'EVENING',
    favoriteSport: 'FOOTBALL',
    favoriteTurfIds: []
  });

  useEffect(() => {
    fetchPrefs();
  }, []);

  const fetchPrefs = async () => {
    try {
      const res = await UserSettingsService.getPreferences();
      if (res.success) {
        setPrefs(res.data);
      }
    } catch (error) {
      console.error('Failed to fetch preferences:', error);
    } finally {
      setLoading(false);
    }
  };

  const updatePref = (key: keyof UserPreferences, value: any) => {
    setPrefs(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await UserSettingsService.updatePreferences(prefs);
      if (res.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('Success', 'Preferences updated');
        router.back();
      }
    } catch (error) {
       Alert.alert('Error', 'Failed to update preferences');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: COLORS.background, justifyContent: 'center' }]}>
        <ActivityIndicator color={COLORS.kiwi} size="large" />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />
      
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain }]}>Preferences</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>General</Text>
          <View style={[styles.row, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            <View style={styles.rowInfo}>
               <Text style={[styles.rowLabel, { color: COLORS.textMain }]}>Enable Notifications</Text>
               <Text style={[styles.rowSub, { color: COLORS.textMuted }]}>Get alerts for bookings and offers</Text>
            </View>
            <Switch 
              value={prefs.notificationsEnabled} 
              onValueChange={(val) => updatePref('notificationsEnabled', val)}
              trackColor={{ false: '#3a3a3c', true: COLORS.kiwi }}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>Favorite Sport</Text>
          <View style={styles.grid}>
            {['FOOTBALL', 'CRICKET', 'TENNIS', 'BASKETBALL'].map((s) => {
              const isSelected = prefs.favoriteSport === s;
              return (
                <TouchableOpacity
                  key={s}
                  style={[
                    styles.gridItem,
                    { backgroundColor: COLORS.surface, borderColor: isSelected ? COLORS.kiwi : COLORS.border }
                  ]}
                  onPress={() => updatePref('favoriteSport', s)}
                >
                  <Ionicons 
                    name={s === 'FOOTBALL' ? 'football' : s === 'CRICKET' ? 'tennisball' : s === 'TENNIS' ? 'analytics' : 'basketball'} 
                    size={24} 
                    color={isSelected ? COLORS.kiwi : COLORS.textMuted} 
                  />
                  <Text style={[styles.gridLabel, { color: isSelected ? COLORS.textMain : COLORS.textMuted }]}>
                    {s.charAt(0) + s.slice(1).toLowerCase()}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>Preferred Playing Time</Text>
          <View style={styles.timeRow}>
            {['MORNING', 'AFTERNOON', 'EVENING', 'NIGHT'].map((t) => {
              const isSelected = prefs.preferredTime === t;
              return (
                <TouchableOpacity
                  key={t}
                  style={[
                    styles.timeChip,
                    { backgroundColor: isSelected ? COLORS.kiwi : COLORS.surface, borderColor: isSelected ? COLORS.kiwi : COLORS.border }
                  ]}
                  onPress={() => updatePref('preferredTime', t)}
                >
                  <Text style={[styles.timeText, { color: isSelected ? '#000' : COLORS.textMuted }]}>
                    {t.charAt(0) + t.slice(1).toLowerCase()}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <TouchableOpacity 
          style={[styles.saveBtn, { backgroundColor: COLORS.kiwi }]} 
          onPress={handleSave}
          disabled={saving}
        >
          {saving ? <ActivityIndicator color="#000" /> : <Text style={styles.saveBtnText}>Save Preferences</Text>}
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 60 : 40, paddingBottom: 20, borderBottomWidth: 1
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scrollContent: { padding: 24, paddingBottom: 60 },
  section: { marginBottom: 32 },
  sectionTitle: { fontSize: 11, fontWeight: '900', letterSpacing: 1.5, marginBottom: 12, textTransform: 'uppercase' },
  row: { 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', 
    padding: 20, borderRadius: 24, borderWidth: 1 
  },
  rowInfo: { flex: 1, marginRight: 10 },
  rowLabel: { fontSize: 16, fontWeight: '700', marginBottom: 4 },
  rowSub: { fontSize: 12, lineHeight: 18 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  gridItem: { 
    width: '48%', aspectRatio: 1, borderRadius: 24, borderWidth: 1.5, 
    justifyContent: 'center', alignItems: 'center', gap: 10 
  },
  gridLabel: { fontSize: 14, fontWeight: '700' },
  timeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  timeChip: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12, borderWidth: 1 },
  timeText: { fontSize: 13, fontWeight: '700' },
  saveBtn: { 
    height: 60, borderRadius: 20, justifyContent: 'center', alignItems: 'center', 
    marginTop: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 
  },
  saveBtnText: { color: '#000', fontSize: 17, fontWeight: '900' },
});
