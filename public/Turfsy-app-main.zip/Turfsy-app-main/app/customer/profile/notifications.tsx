import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, Switch, ActivityIndicator, StatusBar, Alert, Platform } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/src/context/AppContext';
import { UserSettingsService, NotificationSettings } from '@/src/services/userSettingsService';

export default function NotificationsSettingsScreen() {
  const { COLORS } = useApp();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [settings, setSettings] = useState<NotificationSettings>({
    bookingAlerts: true,
    offerAlerts: true,
    reminderAlerts: true
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await UserSettingsService.getNotificationSettings();
      if (res.success) {
        setSettings(res.data);
      }
    } catch (error) {
      console.error('Failed to fetch notification settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSetting = (key: keyof NotificationSettings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await UserSettingsService.updateNotificationSettings(settings);
      if (res.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('Success', 'Notification settings updated');
        router.back();
      }
    } catch (error) {
       Alert.alert('Error', 'Failed to update notification settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: COLORS.background, justifyContent: 'center' }]}>
        <ActivityIndicator color={COLORS.kiwi} size="large" />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />
      
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain }]}>Notifications</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>Alert Preferences</Text>
          
          <View style={[styles.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            <NotificationRow 
               label="Booking Alerts" 
               sub="Get notified when a booking is confirmed"
               value={settings.bookingAlerts}
               onToggle={() => toggleSetting('bookingAlerts')}
               COLORS={COLORS}
            />
            <View style={[styles.divider, { backgroundColor: COLORS.border }]} />
            <NotificationRow 
               label="Offer Alerts" 
               sub="Receive updates on discounts and turf offers"
               value={settings.offerAlerts}
               onToggle={() => toggleSetting('offerAlerts')}
               COLORS={COLORS}
            />
            <View style={[styles.divider, { backgroundColor: COLORS.border }]} />
            <NotificationRow 
               label="Reminder Alerts" 
               sub="Reminders for your upcoming match sessions"
               value={settings.reminderAlerts}
               onToggle={() => toggleSetting('reminderAlerts')}
               COLORS={COLORS}
            />
          </View>
        </View>

        <TouchableOpacity 
          style={[styles.saveBtn, { backgroundColor: COLORS.kiwi }]} 
          onPress={handleSave}
          disabled={saving}
        >
          {saving ? <ActivityIndicator color="#000" /> : <Text style={styles.saveBtnText}>Save Settings</Text>}
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

function NotificationRow({ label, sub, value, onToggle, COLORS }: any) {
  return (
    <View style={styles.row}>
      <View style={styles.rowInfo}>
         <Text style={[styles.rowLabel, { color: COLORS.textMain }]}>{label}</Text>
         <Text style={[styles.rowSub, { color: COLORS.textMuted }]}>{sub}</Text>
      </View>
      <Switch 
        value={value} 
        onValueChange={onToggle}
        trackColor={{ false: '#3a3a3c', true: COLORS.kiwi }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 60 : 40, paddingBottom: 20, borderBottomWidth: 1
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scrollContent: { padding: 24 },
  section: { marginBottom: 32 },
  sectionTitle: { fontSize: 11, fontWeight: '900', letterSpacing: 1.5, marginBottom: 12, textTransform: 'uppercase' },
  card: { borderRadius: 24, borderWidth: 1, overflow: 'hidden' },
  row: { 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', 
    padding: 20
  },
  rowInfo: { flex: 1, marginRight: 10 },
  rowLabel: { fontSize: 16, fontWeight: '700', marginBottom: 4 },
  rowSub: { fontSize: 12, lineHeight: 18 },
  divider: { height: 1, marginHorizontal: 20 },
  saveBtn: { 
    height: 60, borderRadius: 20, justifyContent: 'center', alignItems: 'center', 
    marginTop: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 
  },
  saveBtnText: { color: '#000', fontSize: 17, fontWeight: '900' },
});
