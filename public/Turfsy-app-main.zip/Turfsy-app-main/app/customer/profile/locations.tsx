import React, { useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, StatusBar, Platform } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/src/context/AppContext';
import { UserService } from '@/src/services/userService';

export default function SavedLocationsScreen() {
  const { COLORS, userProfile, setUserProfile } = useApp();
  const [loading, setLoading] = React.useState(false);

  // Refresh profile data on mount so the address is always fresh
  useEffect(() => {
    const refresh = async () => {
      if (!userProfile) {
        setLoading(true);
      }
      try {
        const res = await UserService.getProfile();
        if (res.success) {
          setUserProfile(res.data);
        }
      } catch (e) {
        console.warn('Failed to refresh profile on locations screen:', e);
      } finally {
        setLoading(false);
      }
    };
    refresh();
  }, []);

  // Derived address display pieces
  const homeAddress = userProfile?.address ?? null;
  const city = userProfile?.city ?? null;
  const state = userProfile?.state ?? null;
  const pincode = userProfile?.pincode ?? null;

  const cityLine = [city, state, pincode].filter(Boolean).join(', ');

  const hasLocation = !!(homeAddress || cityLine);

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />

      {/* HEADER */}
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain }]}>Saved Address</Text>
        {/* Navigate directly to edit profile to add/change address */}
        <TouchableOpacity
          style={styles.editBtnHeader}
          onPress={() => router.push('/customer/profile/edit')}
        >
          <Ionicons name="create-outline" size={24} color={COLORS.kiwi} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={COLORS.kiwi} />
          </View>
        ) : hasLocation ? (
          <View style={styles.list}>

            {/* ── PRIMARY (GPS) CITY CARD ── */}
            {!!cityLine && (
              <View style={[styles.locCard, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
                <View style={[styles.iconBox, { backgroundColor: COLORS.kiwi + '18' }]}>
                  <Ionicons name="navigate-circle-outline" size={24} color={COLORS.kiwi} />
                </View>
                <View style={styles.locInfo}>
                  <View style={styles.locLabelRow}>
                    <Text style={[styles.locLabel, { color: COLORS.textMain }]}>Current Location</Text>
                    <View style={[styles.gpsChip, { backgroundColor: COLORS.kiwi + '22' }]}>
                      <Ionicons name="locate" size={10} color={COLORS.kiwi} />
                      <Text style={[styles.gpsChipText, { color: COLORS.kiwi }]}>GPS</Text>
                    </View>
                  </View>
                  <Text style={[styles.locAddress, { color: COLORS.textMuted }]}>{cityLine}</Text>
                </View>
              </View>
            )}

            {/* ── HOME ADDRESS CARD ── */}
            {homeAddress ? (
              <View style={[styles.locCard, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
                <View style={[styles.iconBox, { backgroundColor: COLORS.primary + '18' }]}>
                  <Ionicons name="home" size={22} color={COLORS.primary} />
                </View>
                <View style={styles.locInfo}>
                  <Text style={[styles.locLabel, { color: COLORS.textMain }]}>Home</Text>
                  <Text style={[styles.locAddress, { color: COLORS.textMuted }]}>{homeAddress}</Text>
                </View>
                {/* Edit button */}
                <TouchableOpacity
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    router.push('/customer/profile/edit');
                  }}
                  style={styles.editCardBtn}
                >
                  <Ionicons name="pencil" size={16} color={COLORS.textMuted} />
                </TouchableOpacity>
              </View>
            ) : (
              /* If we have GPS city but no manual home address, show "Add Home" prompt */
              <TouchableOpacity
                style={[styles.addHomeCard, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}
                activeOpacity={0.8}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  router.push('/customer/profile/edit');
                }}
              >
                <View style={[styles.iconBox, { backgroundColor: COLORS.kiwi + '18' }]}>
                  <Ionicons name="add-circle-outline" size={24} color={COLORS.kiwi} />
                </View>
                <View style={styles.locInfo}>
                  <Text style={[styles.locLabel, { color: COLORS.textMain }]}>Add Home Address</Text>
                  <Text style={[styles.locAddress, { color: COLORS.textMuted }]}>
                    House no, society, landmark…
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
              </TouchableOpacity>
            )}

          </View>
        ) : (
          /* EMPTY STATE */
          <View style={styles.emptyContainer}>
            <View style={[styles.emptyIconBox, { backgroundColor: COLORS.surface }]}>
              <Ionicons name="location-outline" size={40} color={COLORS.textMuted} />
            </View>
            <Text style={[styles.emptyTitle, { color: COLORS.textMain }]}>No Address Saved</Text>
            <Text style={[styles.emptySub, { color: COLORS.textMuted }]}>
              Add your home address in Edit Profile to help us show turfs near you.
            </Text>
            <TouchableOpacity
              style={[styles.addBtnLarge, { backgroundColor: COLORS.kiwi }]}
              activeOpacity={0.85}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                router.push('/customer/profile/edit');
              }}
            >
              <Ionicons name="create-outline" size={18} color="#000" />
              <Text style={styles.addBtnText}>Add in Edit Profile</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* HINT BANNER */}
        {hasLocation && (
          <View style={[styles.hintBanner, { backgroundColor: COLORS.kiwi + '12', borderColor: COLORS.kiwi + '30' }]}>
            <Ionicons name="information-circle-outline" size={18} color={COLORS.kiwi} style={{ marginTop: 1 }} />
            <Text style={[styles.hintText, { color: COLORS.textMuted }]}>
              To update or add a detailed home address, tap the{' '}
              <Text style={{ color: COLORS.kiwi, fontWeight: '800' }}>edit icon</Text> at the top or the pencil on your Home card.
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : (StatusBar.currentHeight || 0) + 10,
    paddingBottom: 20, borderBottomWidth: 1
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  editBtnHeader: { width: 40, height: 40, justifyContent: 'center', alignItems: 'flex-end' },
  scrollContent: { padding: 24 },
  loadingContainer: { alignItems: 'center', marginTop: 80 },
  list: { gap: 16 },
  locCard: {
    flexDirection: 'row', alignItems: 'center', padding: 18,
    borderRadius: 24, borderWidth: 1, gap: 14
  },
  addHomeCard: {
    flexDirection: 'row', alignItems: 'center', padding: 18,
    borderRadius: 24, borderWidth: 1.5, borderStyle: 'dashed', gap: 14
  },
  iconBox: { width: 48, height: 48, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  locInfo: { flex: 1 },
  locLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  locLabel: { fontSize: 15, fontWeight: '700' },
  locAddress: { fontSize: 13, lineHeight: 19 },
  editCardBtn: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  gpsChip: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8,
  },
  gpsChipText: { fontSize: 10, fontWeight: '800' },

  emptyContainer: { alignItems: 'center', marginTop: 80 },
  emptyIconBox: { width: 80, height: 80, borderRadius: 30, justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  emptyTitle: { fontSize: 20, fontWeight: '800', marginBottom: 10 },
  emptySub: { fontSize: 14, textAlign: 'center', paddingHorizontal: 40, lineHeight: 22, marginBottom: 8 },
  addBtnLarge: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 28, paddingVertical: 14, borderRadius: 16, marginTop: 18
  },
  addBtnText: { color: '#000', fontWeight: '900', fontSize: 15 },

  hintBanner: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 10,
    borderWidth: 1, borderRadius: 16, padding: 16, marginTop: 24
  },
  hintText: { flex: 1, fontSize: 13, lineHeight: 19, fontWeight: '500' },
});
