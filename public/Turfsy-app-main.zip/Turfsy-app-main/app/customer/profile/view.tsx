import React from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, Image, Platform, StatusBar, Dimensions } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/src/context/AppContext';

const { width } = Dimensions.get('window');

export default function ProfileViewScreen() {
  const { COLORS, userProfile, userInfo } = useApp();

  const cityLine = [userProfile?.city, userProfile?.state, userProfile?.pincode].filter(Boolean).join(', ');

  const infoItems = [
    { label: 'Full Name', value: userProfile?.name || 'Not Set', icon: 'person-outline' },
    { label: 'Email Address', value: userProfile?.email || 'Not Set', icon: 'mail-outline' },
    { label: 'Phone Number', value: `+91 ${userInfo?.phone || 'Not Set'}`, icon: 'call-outline' },
    { label: 'Location', value: cityLine || 'Not Set', icon: 'location-outline' },
    { label: 'Home Address', value: userProfile?.address || 'Not Set', icon: 'home-outline' },
    { label: 'Date of Birth', value: userProfile?.dob ? new Date(userProfile.dob).toLocaleDateString() : 'Not Set', icon: 'calendar-outline' },
    { label: 'Gender', value: userProfile?.gender || 'Not Set', icon: 'male-female-outline' },
    { label: 'Preferred Sport', value: userProfile?.preferredSport || 'Football', icon: 'football-outline' },
  ];

  return (
    <View style={[styles.container, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" />
      
      {/* HEADER */}
      <View style={[styles.header, { borderBottomColor: COLORS.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: COLORS.textMain }]}>Personal Information</Text>
        <TouchableOpacity onPress={() => router.push('/customer/profile/edit')} style={styles.editBtnHeader}>
           <Ionicons name="create-outline" size={22} color={COLORS.kiwi} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        
        {/* PROFILE CARD */}
        <View style={styles.profileSection}>
           <View style={[styles.imageContainer, { borderColor: COLORS.kiwi }]}>
              {userProfile?.avatarUrl ? (
                <Image source={{ uri: userProfile.avatarUrl }} style={styles.avatar} />
              ) : (
                <Ionicons name="person" size={50} color={COLORS.textMuted} />
              )}
           </View>
           <Text style={[styles.name, { color: COLORS.textMain }]}>{userProfile?.name || 'Player'}</Text>
           <Text style={[styles.role, { color: COLORS.textMuted }]}>Verified Member</Text>
        </View>

        {/* INFO GRID */}
        <View style={styles.infoSection}>
           <Text style={[styles.sectionTitle, { color: COLORS.textMuted }]}>Profile Details</Text>
           <View style={[styles.infoCard, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
              {infoItems.map((item, index) => (
                <View key={item.label}>
                  <View style={styles.infoRow}>
                    <View style={[styles.iconBox, { backgroundColor: COLORS.kiwi + '15' }]}>
                       <Ionicons name={item.icon as any} size={20} color={COLORS.kiwi} />
                    </View>
                    <View style={styles.itemTextContent}>
                       <Text style={[styles.itemLabel, { color: COLORS.textMuted }]}>{item.label}</Text>
                       <Text style={[styles.itemValue, { color: COLORS.textMain }]}>{item.value}</Text>
                    </View>
                  </View>
                  {index < infoItems.length - 1 && <View style={[styles.divider, { backgroundColor: COLORS.border }]} />}
                </View>
              ))}
           </View>
        </View>

        {/* FOOTER ACTION */}
        <TouchableOpacity 
          style={[styles.editActionBtn, { backgroundColor: COLORS.kiwi }]}
          onPress={() => router.push('/customer/profile/edit')}
        >
          <Text style={styles.editActionText}>Update Information</Text>
          <Ionicons name="chevron-forward" size={18} color="#000" />
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 60 : 40, paddingBottom: 20, borderBottomWidth: 1
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  editBtnHeader: { width: 40, height: 40, justifyContent: 'center', alignItems: 'flex-end' },
  
  scrollContent: { paddingBottom: 40 },
  profileSection: { alignItems: 'center', marginTop: 32, marginBottom: 24 },
  imageContainer: { 
    width: 100, height: 100, borderRadius: 50, borderWidth: 3, 
    justifyContent: 'center', alignItems: 'center', marginBottom: 16, overflow: 'hidden' 
  },
  avatar: { width: '100%', height: '100%', borderRadius: 50 },
  name: { fontSize: 22, fontWeight: '800', marginBottom: 4 },
  role: { fontSize: 13, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1 },

  infoSection: { paddingHorizontal: 24, marginBottom: 32 },
  sectionTitle: { fontSize: 11, fontWeight: '900', letterSpacing: 1.5, marginBottom: 12, textTransform: 'uppercase', marginLeft: 8 },
  infoCard: { borderRadius: 24, borderWidth: 1, overflow: 'hidden' },
  infoRow: { flexDirection: 'row', alignItems: 'center', padding: 18, gap: 16 },
  iconBox: { width: 42, height: 42, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  itemTextContent: { flex: 1 },
  itemLabel: { fontSize: 11, fontWeight: '700', textTransform: 'uppercase', marginBottom: 4 },
  itemValue: { fontSize: 16, fontWeight: '700' },
  divider: { height: 1, marginLeft: 76 },

  editActionBtn: { 
    marginHorizontal: 24, height: 60, borderRadius: 20, 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 
  },
  editActionText: { color: '#000', fontSize: 16, fontWeight: '900' },
});
