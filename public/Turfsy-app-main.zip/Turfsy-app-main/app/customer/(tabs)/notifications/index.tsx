import { AppText as Text } from '@/src/components/AppText';
import { useApp } from '@/src/context/AppContext';
import { clearAllNotifications, deleteNotification, getNotificationInbox, markAllNotificationsAsRead, markNotificationAsRead, NotificationInboxResponse } from '@/src/services/notificationService';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Dimensions, FlatList, Platform, RefreshControl, StyleSheet, TouchableOpacity, View } from 'react-native';
import { Swipeable } from 'react-native-gesture-handler';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
;

const { width } = Dimensions.get('window');

export default function NotificationsScreen() {
  const insets = useSafeAreaInsets();
  const { COLORS, setUnreadCount, userProfile } = useApp();
  const styles = useMemo(() => getStyles(COLORS, insets), [COLORS, insets]);

  const [notifications, setNotifications] = useState<NotificationInboxResponse['data']>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const fetchInbox = async (pageNum = 1, shouldRefresh = false) => {
    if (shouldRefresh) setRefreshing(true);
    else if (pageNum === 1) setLoading(true);

    try {
      const res = await getNotificationInbox(pageNum, 20);
      if (res.success) {
        let incomingList = res.data;
        let currentCount = res.meta.unreadCount;

        if (pageNum === 1) {
          setNotifications(incomingList);
        } else {
          setNotifications(prev => [...prev, ...res.data]);
        }

        setHasMore(res.data.length > 0 && res.meta.page * res.meta.limit < res.meta.total);
        setPage(pageNum);
        setUnreadCount(currentCount);
      }
    } catch (err: any) {
      console.error('Failed to fetch inbox:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchInbox(1);
  }, [userProfile?.payment?.upiId]);

  const handleRefresh = useCallback(() => {
    fetchInbox(1, true);
  }, [userProfile?.payment?.upiId]);

  const handleLoadMore = () => {
    if (!loading && !refreshing && hasMore) {
      fetchInbox(page + 1);
    }
  };

  const handleMarkAsRead = async (id: string, isRead: boolean) => {
    if (isRead) return;
    try {
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
      setUnreadCount((prev: number) => Math.max(0, prev - 1));
      await markNotificationAsRead(id);
    } catch (err: any) {
      console.error('Failed to mark read:', err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
      await markAllNotificationsAsRead();
    } catch (err) {
      console.error('Failed to mark all read:', err);
    }
  };


  const handleDeleteSingle = async (id: string) => {
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      setNotifications(prev => prev.filter(n => n.id !== id));
      await deleteNotification(id);
    } catch (err) {
      console.error('Failed to delete notification:', err);
    }
  };

  const handleClearAll = async () => {
    Alert.alert(
      'Clear All Notifications?',
      'This will permanently delete all notifications from your inbox.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear All', 
          style: 'destructive',
          onPress: async () => {
            try {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              setNotifications([]);
              setUnreadCount(0);
              await clearAllNotifications();
            } catch (err) {
              console.error('Failed to clear notifications:', err);
            }
          }
        }
      ]
    );
  };

  const getIconForType = (type: string) => {
    switch (type) {
      case 'BOOKING_CONFIRMED': return 'checkmark-circle-outline';
      case 'PAYMENT_PARTIAL': return 'cash-outline';
      case 'PAYMENT_FULL': return 'cash';
      case 'NO_SHOW': return 'alert-circle-outline';
      case 'SPLIT_ADDED': return 'people-outline';
      case 'GAME_COMPLETED': return 'trophy-outline';
      case 'PAYMENT_NUDGE': return 'alert-circle';
      default: return 'notifications-outline';
    }
  };

  const handleNotifPress = (item: any) => {
    handleMarkAsRead(item.id, item.isRead);
  };

  const formatNotifDate = (dateStr: string) => {
    const d = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const hours = diff / (1000 * 60 * 60);
    
    if (hours < 24 && d.getDate() === now.getDate()) {
       return 'Today';
    } else if (hours < 48 && d.getDate() === now.getDate() - 1) {
       return 'Yesterday';
    }
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  const renderRightActions = (id: string) => {
    return (
      <TouchableOpacity 
        onPress={() => handleDeleteSingle(id)}
        activeOpacity={0.8}
        style={styles.swipeDeleteAction}
      >
        <Ionicons name="trash" size={24} color="#FFF" />
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.ambientGlowPrimary} />
      <View style={styles.ambientGlowSecondary} />

      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollPadding}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.kiwi} />
        }
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        ListHeaderComponent={
          <View style={styles.header}>
            <View style={styles.headerTop}>
              <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                <Ionicons name="chevron-back" size={20} color={COLORS.textMain} />
              </TouchableOpacity>
              <View style={styles.headerActions}>
                {(() => {
                  const hasUnread = notifications.some(n => !n.isRead);
                  const isEmpty = notifications.length === 0;
                  const isDisabled = isEmpty || !hasUnread;
                  
                  return (
                    <TouchableOpacity 
                      onPress={handleMarkAllRead} 
                      disabled={isDisabled}
                      style={[
                        styles.markAllBtn, 
                        isDisabled && { opacity: 0.4, backgroundColor: 'transparent', borderColor: COLORS.border }
                      ]}
                    >
                       <Ionicons 
                         name="checkmark-done" 
                         size={18} 
                         color={isDisabled ? COLORS.textMuted : COLORS.kiwi} 
                         style={{ marginRight: 6 }} 
                       />
                       <Text style={[styles.markAllText, isDisabled && { color: COLORS.textMuted }]}>
                         Mark all read
                       </Text>
                    </TouchableOpacity>
                  );
                })()}
                {notifications.length > 0 && (
                  <TouchableOpacity onPress={handleClearAll} style={styles.clearAllBtn}>
                    <Ionicons name="trash-outline" size={20} color={COLORS.error || '#FF4444'} />
                  </TouchableOpacity>
                )}
              </View>
            </View>
            <Text style={styles.headerSub}>STAY UPDATED</Text>
            <View style={styles.titleRow}>
              <Text style={styles.headerTitle}>Notifications</Text>
              <View style={styles.titleUnderline} />
            </View>
          </View>
        }
        ListEmptyComponent={
          loading && page === 1 ? (
             <ActivityIndicator size="large" color={COLORS.kiwi} style={{ marginTop: 40 }} />
          ) : (
             <View style={styles.emptyContainer}>
               <View style={styles.emptyIconWrap}>
                 <Ionicons name="notifications-off-outline" size={48} color={COLORS.textMuted} />
               </View>
               <Text style={styles.emptyTitle}>All caught up!</Text>
               <Text style={styles.emptySub}>You have no new notifications right now.</Text>
             </View>
          )
        }
        renderItem={({ item }) => (
          <Swipeable 
            renderRightActions={() => renderRightActions(item.id)}
            friction={2}
            rightThreshold={40}
            containerStyle={[styles.swipeContainer, { backgroundColor: 'transparent' }]}
            childrenContainerStyle={{ backgroundColor: 'transparent' }}
          >
            <TouchableOpacity 
              style={[
                styles.card, 
                !item.isRead && styles.unreadCard
              ]}
              activeOpacity={0.8}
              onPress={() => handleNotifPress(item)}
            >
              <View style={[
                styles.iconWrap, 
                !item.isRead && styles.unreadIconWrap
              ]}>
                <Ionicons 
                  name={getIconForType(item.type)} 
                  size={width < 380 ? 16 : 18} 
                  color={!item.isRead ? '#000000' : COLORS.textMain} 
                />
              </View>
              <View style={styles.content}>
                <Text 
                  style={[styles.title, !item.isRead && styles.unreadText]} 
                  numberOfLines={2}
                >
                  {item.title}
                </Text>
                <Text style={styles.message} numberOfLines={3}>{item.body}</Text>
                <View style={styles.footerRow}>
                   <Ionicons name="time-outline" size={12} color={COLORS.textMuted} />
                   <Text style={styles.time}>{formatNotifDate(item.createdAt)}</Text>
                   {!item.isRead && (
                      <View style={styles.unreadTag}>
                        <Text style={styles.unreadTagText}>NEW</Text>
                      </View>
                   )}
                   <TouchableOpacity 
                        onPress={() => handleDeleteSingle(item.id)} 
                        style={styles.deleteBtn}
                        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                      >
                        <Ionicons name="trash-outline" size={14} color={COLORS.textMuted} />
                      </TouchableOpacity>
                </View>
              </View>
            </TouchableOpacity>
          </Swipeable>
        )}
        ListFooterComponent={
          hasMore ? (
            <ActivityIndicator size="small" color={COLORS.kiwi} style={{ marginVertical: 20 }} />
          ) : null
        }
      />
    </View>
  );
}

const getStyles = (COLORS: any, insets: any) => {
  const isSmallValue = width < 380;
  const isTablet = width > 600;
  
  // Responsive values
  const horizontalPadding = isTablet ? width * 0.15 : 20;
  const cardBorderRadius = isTablet ? 32 : 24;
  const headerFontSize = isTablet ? 48 : isSmallValue ? 30 : 38;
  const titleFontSize = isTablet ? 20 : isSmallValue ? 15 : 17;
  const bodyFontSize = isTablet ? 16 : isSmallValue ? 12 : 14;

  return StyleSheet.create({
    container: { flex: 1, backgroundColor: COLORS.night },
    swipeContainer: { 
      marginBottom: 16, 
      paddingHorizontal: horizontalPadding 
    },
    swipeDeleteAction: {
      backgroundColor: '#FF4444',
      justifyContent: 'center',
      alignItems: 'center',
      width: isTablet ? 100 : 80,
      height: '92%', 
      borderRadius: cardBorderRadius,
      marginLeft: 10,
    },
    ambientGlowPrimary: {
      position: 'absolute',
      top: -100,
      right: -80,
      width: width * 0.8,
      height: width * 0.8,
      borderRadius: (width * 0.8) / 2,
      backgroundColor: COLORS.kiwi,
      opacity: 0.04,
    },
    ambientGlowSecondary: {
      position: 'absolute',
      bottom: -150,
      left: -100,
      width: width * 0.9,
      height: width * 0.9,
      borderRadius: (width * 0.9) / 2,
      backgroundColor: COLORS.kiwi,
      opacity: 0.03,
    },
    scrollPadding: { paddingTop: Platform.OS === 'ios' ? 60 : 40, paddingBottom: 100 },
    header: { 
      paddingHorizontal: horizontalPadding, 
      paddingTop: Math.max(insets.top, 20),
      marginBottom: 28 
    },
    headerTop: { 
      flexDirection: 'row', 
      justifyContent: 'space-between', 
      alignItems: 'center',
      marginBottom: 20 
    },
    headerActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    backButton: {
      width: isTablet ? 54 : 44,
      height: isTablet ? 54 : 44,
      borderRadius: isTablet ? 18 : 15,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
    },
    headerSub: { color: COLORS.kiwi, fontSize: isTablet ? 13 : 11, fontWeight: '900', letterSpacing: 3, marginBottom: 4 },
    titleRow: { alignSelf: 'flex-start' },
    headerTitle: { color: COLORS.textMain, fontSize: headerFontSize, fontWeight: '900', letterSpacing: -1 },
    titleUnderline: { width: isTablet ? 60 : 40, height: 4, backgroundColor: COLORS.kiwi, borderRadius: 2, marginTop: 2 },
    markAllBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: isTablet ? 18 : 14,
      paddingVertical: isTablet ? 10 : 8,
      borderRadius: isTablet ? 16 : 14,
      backgroundColor: COLORS.isDark ? 'rgba(137,233,0,0.1)' : 'rgba(137,233,0,0.06)',
      borderWidth: 1,
      borderColor: 'rgba(137,233,0,0.2)',
    },
    markAllText: { color: COLORS.kiwi, fontSize: isTablet ? 15 : 13, fontWeight: '800' },
    clearAllBtn: {
      width: isTablet ? 54 : 44,
      height: isTablet ? 54 : 44,
      borderRadius: isTablet ? 18 : 14,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
    },
    card: {
      flexDirection: 'row',
      gap: 16,
      backgroundColor: COLORS.surface,
      borderRadius: cardBorderRadius,
      borderWidth: 1,
      borderColor: COLORS.border,
      padding: isTablet ? 24 : isSmallValue ? 16 : 20,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.05,
      shadowRadius: 10,
      elevation: 2,
    },
    iconWrap: {
      width: isTablet ? 60 : 48,
      height: isTablet ? 60 : 48,
      borderRadius: isTablet ? 20 : 16,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: COLORS.isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)',
    },
    content: { flex: 1 },
    title: { color: COLORS.textMain, fontSize: titleFontSize, fontWeight: '800', lineHeight: isTablet ? 28 : 22, marginBottom: 4 },
    footerRow: { flexDirection: 'row', alignItems: 'center', marginTop: isTablet ? 14 : 10, gap: 8 },
    deleteBtn: { marginLeft: 'auto', padding: 6 },
    time: { color: COLORS.textMuted, fontSize: isTablet ? 13 : 11, fontWeight: '700', textTransform: 'uppercase' },
    message: { color: COLORS.textMuted, fontSize: bodyFontSize, lineHeight: isTablet ? 24 : 20, opacity: 0.85 },
    unreadCard: { 
      borderColor: 'rgba(137,233,0,0.25)', 
      backgroundColor: COLORS.isDark ? '#141C15' : '#F2FBEF' 
    },
    unreadIconWrap: { backgroundColor: COLORS.kiwi },
    unreadText: { color: COLORS.textMain },
    unreadTag: { 
      paddingHorizontal: 8, 
      paddingVertical: 3, 
      backgroundColor: COLORS.kiwi, 
      borderRadius: 8, 
      marginLeft: 'auto' 
    },
    unreadTagText: { color: '#000000', fontSize: isTablet ? 11 : 9, fontWeight: '900' },
    nudgeCard: { 
      borderColor: COLORS.kiwi, 
      backgroundColor: COLORS.isDark ? 'rgba(137,233,0,0.05)' : 'rgba(137,233,0,0.03)',
      borderWidth: 1.5 
    },
    nudgeIconWrap: { backgroundColor: COLORS.kiwi },
    emptyContainer: { alignItems: 'center', marginTop: 100, paddingHorizontal: horizontalPadding },
    emptyIconWrap: { width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(137,233,0,0.03)', alignItems: 'center', justifyContent: 'center', marginBottom: 24 },
    emptyTitle: { color: COLORS.textMain, fontSize: isTablet ? 28 : 22, fontWeight: '800', marginBottom: 12 },
    emptySub: { color: COLORS.textMuted, fontSize: isTablet ? 18 : 14, textAlign: 'center', lineHeight: isTablet ? 28 : 22 },
  });
};
