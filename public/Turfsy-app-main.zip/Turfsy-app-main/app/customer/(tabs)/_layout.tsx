import React, { useEffect } from 'react';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Platform, StyleSheet, View, TouchableOpacity, Dimensions, StatusBar } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as NavigationBar from 'expo-navigation-bar';
import { useApp } from '@/src/context/AppContext';


export default function TabLayout() {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);

  useEffect(() => {
    StatusBar.setHidden(true, 'slide');
    if (Platform.OS === 'android') {
      NavigationBar.setVisibilityAsync('hidden');
    }
  }, []);

  return (
    <Tabs
      screenOptions={{ headerShown: false, tabBarStyle: { display: 'none' } }}
      tabBar={(props) => <CustomTabBar props={props} />}
    >
      <Tabs.Screen name="home/index" />
      <Tabs.Screen name="bookings/index" />
      <Tabs.Screen name="explore/index" />
      <Tabs.Screen name="leaderboard/index" />
      <Tabs.Screen name="profile/index" />
      <Tabs.Screen name="liked/index" options={{ href: null }} />
      <Tabs.Screen name="notifications/index" options={{ href: null }} />
    </Tabs>
  );
}

function CustomTabBar({ props }: any) {
  const { state, navigation } = props;
  const insets = useSafeAreaInsets();
  const { COLORS, isTabBarHidden } = useApp();
  const styles = getStyles(COLORS);
  const currentRoute = state.routes[state.index]?.name;

  if (isTabBarHidden) return null;

  const TAB_ITEMS = ['home/index', 'bookings/index', 'explore/index', 'leaderboard/index', 'profile/index'];

  return (
    <View style={[styles.mainContainer, { bottom: Platform.OS === 'ios' ? insets.bottom : 12 }]}>
      <View style={styles.pillContainer}>
        {TAB_ITEMS.map((name) => {
          const isFocused = currentRoute === name;
          const iconColor = isFocused ? '#000' : COLORS.textMuted;
          const iconName = getIcon(name, isFocused);

          return (
            <TouchableOpacity
              key={name}
              onPress={() => navigation.navigate(name)}
              style={styles.tabItem}
              activeOpacity={0.8}
            >
              <View style={[
                styles.iconWrapper, 
                isFocused && styles.activeIconCircle,
                { transform: [{ scale: isFocused ? 1.05 : 1 }] }
              ]}>
                <Ionicons 
                  name={iconName} 
                  size={isFocused ? 24 : 22} 
                  color={iconColor} 
                />
              </View>
              {isFocused && <View style={styles.activeDot} />}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const getIcon = (name: string, focused: boolean): any => {
  if (name.includes('home')) return focused ? 'home' : 'home-outline';
  if (name.includes('bookings')) return focused ? 'calendar' : 'calendar-outline';
  if (name.includes('explore')) return focused ? 'search' : 'search-outline';
  if (name.includes('leaderboard')) return focused ? 'trophy' : 'trophy-outline';
  if (name.includes('profile')) return focused ? 'person' : 'person-outline';
  return 'ellipse';
};

const getStyles = (COLORS: any) => {
  const { width } = Dimensions.get('window');
  const isSmall = width < 380;
  
  return StyleSheet.create({
    mainContainer: { 
      position: 'absolute', 
      left: isSmall ? 16 : 24, 
      right: isSmall ? 16 : 24, 
      zIndex: 1000, 
      elevation: 10, 
      alignItems: 'center' 
    },
    pillContainer: { 
      width: '100%', 
      height: isSmall ? 60 : 66, 
      backgroundColor: COLORS.isDark ? 'rgba(15, 17, 18, 0.95)' : 'rgba(255, 255, 255, 0.95)', 
      borderRadius: 33, 
      flexDirection: 'row', 
      alignItems: 'center', 
      justifyContent: 'space-around', 
      paddingHorizontal: 8, 
      borderWidth: 1.5, 
      borderColor: COLORS.isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.2,
      shadowRadius: 12,
    },
    tabItem: { 
      height: '100%', 
      justifyContent: 'center', 
      alignItems: 'center', 
      paddingVertical: 4,
      flex: 1 
    },
    iconWrapper: { 
      width: isSmall ? 40 : 44, 
      height: isSmall ? 40 : 44, 
      justifyContent: 'center', 
      alignItems: 'center',
    },
    activeIconCircle: { 
      backgroundColor: COLORS.kiwi, 
      width: isSmall ? 44 : 50, 
      height: isSmall ? 44 : 50, 
      borderRadius: isSmall ? 22 : 25, 
      shadowColor: COLORS.kiwi, 
      shadowOffset: { width: 0, height: 6 }, 
      shadowOpacity: 0.5, 
      shadowRadius: 12, 
      elevation: 8 
    },
    activeDot: {
      position: 'absolute',
      bottom: 6,
      width: 4,
      height: 4,
      borderRadius: 2,
      backgroundColor: COLORS.kiwi,
      shadowColor: COLORS.kiwi,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 1,
      shadowRadius: 6,
      elevation: 4
    }
  });
};
