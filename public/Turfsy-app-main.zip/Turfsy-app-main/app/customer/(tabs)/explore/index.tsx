import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Dimensions, TextInput, Platform, Modal, PanResponder, Animated, ActivityIndicator, StatusBar, FlatList, InteractionManager } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { Image } from 'expo-image';
import { BlurView } from 'expo-blur';
import * as Haptics from 'expo-haptics';
import { Ionicons, Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useApp } from '@/src/context/AppContext';
import { TurfService, FilterParams } from '@/src/services/turfService';
import { TurfCard } from '@/src/services/homeService';
import SkeletonLoader from '@/src/components/SkeletonLoader';


const { width, height } = Dimensions.get('window');

type FilterType = 'All' | 'Nearby' | 'Top Rated' | 'Budget' | 'Premium';

export default function ExploreScreen() {
  const { COLORS, setIsTabBarHidden, userLocation } = useApp();
  const styles = useMemo(() => getStyles(COLORS), [COLORS]);
  const isDark = COLORS.isDark;
  const isSmall = width < 380;
  const itemHeight = isSmall ? 280 : 340;

  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<FilterType>('All');
  const [isFilterVisible, setIsFilterVisible] = useState(false);
  const [turfs, setTurfs] = useState<TurfCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filter States
  const [selectedCity, setSelectedCity] = useState<string | null>(null);
  const [selectedSport, setSelectedSport] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<FilterParams['sortBy']>('newest');
  
  // Price Slider State
  const SLIDER_WIDTH = width - 48;
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(3000);
  const leftThumb = useState(new Animated.Value(0))[0];
  const rightThumb = useState(new Animated.Value(SLIDER_WIDTH))[0];

  const fetchTurfs = useCallback(async (isKeywordSearch: boolean = false) => {
    setLoading(true);
    setError(null);
    InteractionManager.runAfterInteractions(async () => {
      try {
        // Priority: If user typed something but hasn't picked many filters, use text search
        // Otherwise use filtration logic
        const hasStrictFilters = selectedCity || selectedSport || minPrice > 0 || maxPrice < 3000 || activeTab !== 'All';

        if (isKeywordSearch && search.trim() && !hasStrictFilters) {
          const res = await TurfService.searchTurfs(search);
          setTurfs(res.data || []);
        } else {
          const params: FilterParams = {
            minPrice,
            maxPrice,
            sortBy,
            city: search.trim() || selectedCity || undefined,
            sportsType: selectedSport || undefined,
          };

          // Quick Tab Overrides
          if (activeTab === 'Nearby') params.sortBy = 'distance';
          else if (activeTab === 'Top Rated') params.sortBy = 'popular';
          else if (activeTab === 'Budget') params.maxPrice = 800;
          else if (activeTab === 'Premium') params.minPrice = 1500;

          // Geolocation support
          if (userLocation) {
            params.userLat = userLocation.coords.lat;
            params.userLng = userLocation.coords.lng;
          }

          const res = await TurfService.filterTurfs(params);
          setTurfs(res.data || []);
        }
      } catch (err: any) {
        console.error('Explore Fetch Error:', err);
        setError(err.message || 'Network error occurred. Please try again.');
      } finally {
        setLoading(false);
      }
    });
  }, [search, activeTab, minPrice, maxPrice, sortBy, selectedCity, selectedSport, userLocation]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchTurfs(search.length > 0);
    }, 500);
    return () => clearTimeout(timer);
  }, [search, activeTab, sortBy, selectedCity, selectedSport, minPrice, maxPrice]);

  const toggleFilter = (visible: boolean) => {
    Haptics.impactAsync(visible ? Haptics.ImpactFeedbackStyle.Light : Haptics.ImpactFeedbackStyle.Medium);
    setIsFilterVisible(visible);
    setIsTabBarHidden(visible);
  };

  const handlePillPress = () => Haptics.selectionAsync();

  const resetFilters = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    setSelectedCity(null);
    setSelectedSport(null);
    setMinPrice(0);
    setMaxPrice(3000);
    setSortBy('newest');
    leftThumb.setValue(0);
    rightThumb.setValue(SLIDER_WIDTH);
    setActiveTab('All');
  };

  const panResponderLeft = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (_, gestureState) => {
      const newVal = Math.max(0, Math.min(gestureState.moveX - 24, SLIDER_WIDTH * 0.9));
      leftThumb.setValue(newVal);
    },
    onPanResponderRelease: (_, gestureState) => {
      const newVal = Math.max(0, Math.min(gestureState.moveX - 24, SLIDER_WIDTH * 0.9));
      setMinPrice(Math.round((newVal / SLIDER_WIDTH) * 3000));
    }
  });

  const panResponderRight = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (_, gestureState) => {
      const newVal = Math.max(SLIDER_WIDTH * 0.1, Math.min(gestureState.moveX - 24, SLIDER_WIDTH));
      rightThumb.setValue(newVal);
    },
    onPanResponderRelease: (_, gestureState) => {
      const newVal = Math.max(SLIDER_WIDTH * 0.1, Math.min(gestureState.moveX - 24, SLIDER_WIDTH));
      setMaxPrice(Math.round((newVal / SLIDER_WIDTH) * 3000));
    }
  });
  const renderExploreItem = useCallback(({ item: turf }: { item: TurfCard }) => (
    <ExploreTurfCard turf={turf} COLORS={COLORS} styles={styles} />
  ), [COLORS, styles]);
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={styles.ambientGlow} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollPadding}>
        <View style={styles.header}>
          <View>
            <Text style={styles.headerSub}>DISCOVER</Text>
            <Text style={styles.headerTitle}>Elite Venues</Text>
          </View>
          <TouchableOpacity style={styles.filterButton} onPress={() => toggleFilter(true)}>
            <Ionicons name="options-outline" size={22} color={COLORS.kiwi} />
          </TouchableOpacity>
        </View>

        <View style={styles.searchWrapper}>
          <Feather name="search" size={20} color={COLORS.kiwi} />
          <TextInput
            placeholder="Search city, turf or sport..."
            placeholderTextColor={COLORS.textMuted}
            value={search}
            onChangeText={setSearch}
            style={styles.searchInput}
          />
          {loading ? (
            null
          ) : search.length > 0 && (

            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={20} color={COLORS.textMuted} />
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.listContainer}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterSection} contentContainerStyle={{ paddingRight: 24 }}>
            {(['All', 'Nearby', 'Top Rated', 'Budget', 'Premium'] as FilterType[]).map((tab) => {
              const isActive = activeTab === tab;
              return (
                <TouchableOpacity
                  key={tab}
                  onPress={() => { handlePillPress(); setActiveTab(tab); }}
                  style={[styles.filterPill, isActive && styles.activePill]}
                >
                  <Text style={[styles.filterText, isActive && styles.activeFilterText]}>{tab}</Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          <View style={styles.resultsRow}>
            <Text style={styles.resultsText}>{turfs.length} venue{turfs.length !== 1 ? 's' : ''} found</Text>
          </View>

          {loading && turfs.length === 0 ? (
            <ExploreSkeleton COLORS={COLORS} itemHeight={itemHeight} isSmall={isSmall} />
          ) : error ? (
            <View style={[styles.emptyState, { paddingHorizontal: 20 }]}>
              <Ionicons name="alert-circle-outline" size={40} color={COLORS.textMuted} />
              <Text style={[styles.emptyText, { textAlign: 'center' }]}>{error}</Text>
              <TouchableOpacity style={{ marginTop: 20, padding: 12, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 12 }} onPress={() => fetchTurfs(search.length > 0)}>
                <Text style={{ color: COLORS.kiwi, fontWeight: '700' }}>Retry</Text>
              </TouchableOpacity>
            </View>
          ) : turfs.length === 0 ? (
            <View style={styles.emptyState}>
              <Ionicons name="search-outline" size={40} color={COLORS.textMuted} />
              <Text style={styles.emptyText}>No venues match your search</Text>
            </View>
          ) : (
            <FlatList
              data={turfs}
              keyExtractor={(item) => item.id}
              initialNumToRender={4}
              maxToRenderPerBatch={4}
              windowSize={5}
              removeClippedSubviews={true}
              scrollEnabled={false}
              renderItem={renderExploreItem}
              getItemLayout={(data, index) => (
                { length: itemHeight, offset: itemHeight * index, index }
              )}
            />
          )}
        </View>
      </ScrollView>

      {/* Advanced Filter Modal */}
      <Modal visible={isFilterVisible} animationType="slide" transparent={true} onRequestClose={() => toggleFilter(false)}>
        <View style={styles.modalOverlay}>
          <BlurView intensity={isDark ? 30 : 45} tint={isDark ? 'dark' : 'light'} style={[StyleSheet.absoluteFill, { backgroundColor: isDark ? 'rgba(0, 10, 30, 0.4)' : 'rgba(0, 80, 255, 0.08)' }]} />
          <TouchableOpacity activeOpacity={1} style={{ flex: 1 }} onPress={() => toggleFilter(false)} />
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => toggleFilter(false)}>
                <Ionicons name="close" size={24} color={COLORS.textMain} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>Filters</Text>
              <TouchableOpacity onPress={resetFilters}>
                <Text style={styles.resetText}>Reset</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 110 }}>
              <View style={styles.filterBlock}>
                <Text style={styles.blockLabel}>City</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
                  {['Thane', 'Mumbai', 'Pune', 'Bangalore'].map(city => (
                    <TouchableOpacity key={city} onPress={() => { handlePillPress(); setSelectedCity(city === selectedCity ? null : city); }} style={[styles.pillBtn, city === selectedCity && styles.pillBtnActive]}>
                      <Text style={[styles.pillBtnText, city === selectedCity && styles.pillBtnTextActive]}>{city}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>

              <View style={styles.filterBlock}>
                <Text style={styles.blockLabel}>Sports Category</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
                  {['FOOTBALL', 'CRICKET', 'BASKETBALL', 'TENNIS'].map(sport => (
                    <TouchableOpacity key={sport} onPress={() => { handlePillPress(); setSelectedSport(sport === selectedSport ? null : sport); }} style={[styles.pillBtn, sport === selectedSport && styles.pillBtnActive]}>
                      <Text style={[styles.pillBtnText, sport === selectedSport && styles.pillBtnTextActive]}>{sport}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>

              <View style={styles.filterBlock}>
                <Text style={styles.blockLabel}>Price range (hourly)</Text>
                <View style={styles.histogramContainer}>
                  {[8, 12, 18, 25, 35, 42, 30, 48, 40, 45, 38, 52, 44, 35, 25, 18, 12, 10].map((h, i) => {
                    const barPos = (i / 18) * SLIDER_WIDTH;
                    // @ts-ignore
                    const isActive = barPos >= leftThumb._value && barPos <= rightThumb._value;
                    return <View key={i} style={[styles.histoBar, { height: h }, isActive ? { backgroundColor: COLORS.kiwi } : { backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)' }]} />;
                  })}
                </View>
                <View style={styles.sliderTrackLine}>
                  <Animated.View style={[styles.sliderActiveSection, { left: leftThumb, width: Animated.subtract(rightThumb, leftThumb) }]} />
                  <Animated.View {...panResponderLeft.panHandlers} style={[styles.sliderThumb, { left: leftThumb, transform: [{ translateX: -12 }] }]} />
                  <Animated.View {...panResponderRight.panHandlers} style={[styles.sliderThumb, { left: rightThumb, transform: [{ translateX: -12 }] }]} />
                </View>
                <View style={styles.priceRangeLabels}>
                  <Text style={styles.priceLabelText}>₹{minPrice}</Text>
                  <Text style={styles.priceLabelText}>₹{maxPrice}</Text>
                </View>
              </View>

              <View style={styles.filterBlock}>
                <Text style={styles.blockLabel}>Sort by</Text>
                <View style={styles.rowWrap}>
                  {[
                    { id: 'newest', label: 'Newest' },
                    { id: 'price_low', label: 'Price: Low' },
                    { id: 'price_high', label: 'Price: High' },
                    { id: 'popular', label: 'Popular' },
                    { id: 'distance', label: 'Nearby' },
                  ].map(item => (
                    <TouchableOpacity key={item.id} onPress={() => { handlePillPress(); setSortBy(item.id as any); }} style={[styles.pillBtn, sortBy === item.id && styles.pillBtnActive]}>
                      <Text style={[styles.pillBtnText, sortBy === item.id && styles.pillBtnTextActive]}>{item.label}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </ScrollView>

            <View style={styles.modalFooter}>
              <TouchableOpacity style={styles.applyBtn} onPress={() => { fetchTurfs(); toggleFilter(false); }}>
                <Text style={styles.applyBtnText}>Apply Now</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const ExploreTurfCard = React.memo(({ turf, COLORS, styles }: any) => {
  const onPress = useCallback(() => {
    router.push({ pathname: '/customer/booking/detail', params: { id: turf.id } });
  }, [turf.id]);

  const imageUrl = turf.images?.[0] || turf.image || turf.entranceUrl || turf.groundDayUrl || null;

  return (
    <TouchableOpacity
      style={styles.exploreCard}
      activeOpacity={0.95}
      onPress={onPress}
    >
      {imageUrl && (
        <Image 
          source={{ uri: imageUrl }} 
          style={[styles.cardImage, turf.status !== 'ACTIVE' && { opacity: 0.6 }]} 
          contentFit="cover"
        />
      )}
      <LinearGradient colors={['transparent', 'rgba(8, 9, 10, 0.98)']} style={styles.cardOverlay} />
      <View style={[styles.cardBadge, turf.status !== 'ACTIVE' && { backgroundColor: 'rgba(255, 149, 0, 0.8)' }]}>
        <View style={[styles.statusDot, { backgroundColor: turf.status !== 'ACTIVE' ? '#fff' : COLORS.kiwi }]} />
        <Text style={styles.badgeText}>{turf.status !== 'ACTIVE' ? turf.status.replace('_', ' ') : 'ACTIVE'}</Text>
      </View>
      <View style={styles.cardDetails}>
        <View style={styles.titleRow}>
          <Text style={styles.turfName}>{turf.name}</Text>
          <View style={styles.ratingBox}>
            <Ionicons name="star" size={12} color={COLORS.kiwi} />
            <Text style={styles.ratingText}>{Number(turf.rating || 0).toFixed(1)}</Text>
          </View>
        </View>
        <Text style={styles.turfLocation}>
          {turf.city} {turf.distanceKm ? `• ${turf.distanceKm.toFixed(1)} km` : ''}
        </Text>
        <View style={styles.footerRow}>
          <View>
            <Text style={styles.priceText}>₹{turf.weekdayDayPrice.toLocaleString()}</Text>
            <Text style={styles.perHr}>starts from</Text>
          </View>
          <TouchableOpacity style={styles.bookNowBtn} onPress={onPress}>
            <Text style={styles.bookNowText}>BOOK</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
});

const ExploreSkeleton = ({ COLORS, itemHeight, isSmall }: any) => {
  const styles = getStyles(COLORS);
  return (
    <View style={{ gap: 20, marginTop: 10 }}>
      {[1, 2, 3].map(i => (
        <View key={i} style={[styles.exploreCard, { marginBottom: 0 }]}>
           <SkeletonLoader width="100%" height={isSmall ? 260 : 320} borderRadius={28} />
        </View>
      ))}
    </View>
  );
};

const getStyles = (COLORS: any) => {

  const isSmall = width < 380;
  const isDark = COLORS.isDark;
  
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: COLORS.night },
    ambientGlow: { 
      position: 'absolute', top: -100, left: -width*0.2, 
      width: width, height: width, 
      backgroundColor: COLORS.kiwi, borderRadius: width/2, 
      opacity: 0.03 
    },
    scrollPadding: { paddingBottom: 130, paddingTop: Platform.OS === 'ios' ? 60 : 40 },
    header: { 
      flexDirection: 'row', justifyContent: 'space-between', 
      alignItems: 'center', paddingHorizontal: 20, marginBottom: 20 
    },
    headerSub: { color: COLORS.kiwi, fontSize: 11, fontWeight: '900', letterSpacing: 3, marginBottom: 4 },
    headerTitle: { color: COLORS.textMain, fontSize: isSmall ? 28 : 36, fontWeight: '800', letterSpacing: -1 },
    filterButton: { 
      width: isSmall ? 44 : 50, height: isSmall ? 44 : 50, 
      borderRadius: 16, backgroundColor: COLORS.surface, 
      justifyContent: 'center', alignItems: 'center', 
      borderWidth: 1.2, borderColor: COLORS.border 
    },
    searchWrapper: {
      flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.surface,
      marginHorizontal: 20, paddingHorizontal: 16, height: isSmall ? 52 : 58, borderRadius: 16,
      borderWidth: 1.2, borderColor: COLORS.border, marginBottom: 20,
    },
    searchInput: { flex: 1, color: COLORS.textMain, marginLeft: 12, fontSize: 15, fontWeight: '500' },
    filterSection: { marginBottom: 20, paddingLeft: 4 },
    filterPill: { 
      paddingHorizontal: isSmall ? 16 : 20, 
      paddingVertical: isSmall ? 8 : 10, 
      borderRadius: 12, backgroundColor: COLORS.surface, 
      marginRight: 8, borderWidth: 1, borderColor: COLORS.border 
    },
    activePill: { backgroundColor: COLORS.kiwi, borderColor: COLORS.kiwi },
    filterText: { color: COLORS.textMuted, fontWeight: '700', fontSize: isSmall ? 12 : 13 },
    activeFilterText: { color: '#000' },
    resultsRow: { marginBottom: 16, paddingHorizontal: 20 },
    resultsText: { color: COLORS.textMuted, fontSize: 10, fontWeight: '900', textTransform: 'uppercase', letterSpacing: 1.5, opacity: 0.6 },
    listContainer: { },
    emptyState: { alignItems: 'center', paddingTop: 60, gap: 12 },
    emptyText: { color: COLORS.textMuted, fontSize: 15 },
    exploreCard: { 
      width: width - 40, height: isSmall ? 260 : 320, 
      borderRadius: 28, overflow: 'hidden', 
      marginBottom: 20, backgroundColor: COLORS.surface, 
      marginHorizontal: 20,
      borderWidth: 1.5, borderColor: COLORS.border,
      position: 'relative'
    },
    cardImage: { position: 'absolute', width: '100%', height: '100%' },
    cardOverlay: { position: 'absolute', width: '100%', height: '100%' },
    cardBadge: {
      position: 'absolute', top: 16, left: 16, backgroundColor: 'rgba(0,0,0,0.6)',
      paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, flexDirection: 'row', alignItems: 'center',
    },
    statusDot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
    badgeText: { color: '#fff', fontSize: 10, fontWeight: '900', letterSpacing: 0.5 },
    cardDetails: { position: 'absolute', bottom: 20, left: 20, right: 20 },
    titleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 2 },
    turfName: { color: '#fff', fontSize: isSmall ? 22 : 26, fontWeight: '900', flex: 1, letterSpacing: -0.5 },
    ratingBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
    ratingText: { color: '#fff', fontSize: 12, fontWeight: '800', marginLeft: 4 },
    turfLocation: { color: 'rgba(255,255,255,0.8)', fontSize: 13, marginTop: 4, fontWeight: '600' },
    footerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 14 },
    priceText: { color: COLORS.kiwi, fontSize: isSmall ? 22 : 28, fontWeight: '900', letterSpacing: -0.5 },
    perHr: { color: 'rgba(255,255,255,0.6)', fontSize: 11, fontWeight: '700', textTransform: 'uppercase', marginTop: 2 },
    bookNowBtn: { backgroundColor: COLORS.kiwi, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
    bookNowText: { color: '#000', fontWeight: '900', fontSize: 14 },

    modalOverlay: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 9999, justifyContent: 'flex-end' },
    modalContent: { 
      height: height * 0.82, 
      backgroundColor: isDark ? '#151718' : '#FFFFFF', 
      borderTopLeftRadius: 32, borderTopRightRadius: 32, 
      paddingHorizontal: 24, paddingTop: 24,
    },
    modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 },
    modalTitle: { color: COLORS.textMain, fontSize: 22, fontWeight: '900' },
    resetText: { color: COLORS.kiwi, fontWeight: '800', fontSize: 15 },
    filterBlock: { marginBottom: 32 },
    blockLabel: { color: COLORS.textMain, fontSize: 17, fontWeight: '800', marginBottom: 16 },
    pillBtn: { 
      paddingHorizontal: 18, paddingVertical: 12, 
      borderRadius: 16, 
      backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)', 
      marginRight: 10, marginBottom: 10, 
      borderWidth: 1.2, borderColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.02)' 
    },
    pillBtnActive: { backgroundColor: COLORS.kiwi, borderColor: COLORS.kiwi },
    pillBtnText: { color: COLORS.textMuted, fontWeight: '800', fontSize: 14 },
    pillBtnTextActive: { color: '#000' },
    rowWrap: { flexDirection: 'row', flexWrap: 'wrap' },
    histogramContainer: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', height: 60, marginBottom: 12 },
    histoBar: { width: (width - 48 - 36) / 18, borderRadius: 4 },
    sliderTrackLine: { height: 4, backgroundColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)', borderRadius: 2, justifyContent: 'center' },
    sliderActiveSection: { position: 'absolute', height: '100%', backgroundColor: COLORS.kiwi, borderRadius: 2 },
    sliderThumb: { position: 'absolute', width: 24, height: 24, borderRadius: 12, backgroundColor: '#fff', borderWidth: 2, borderColor: COLORS.kiwi },
    priceRangeLabels: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },
    priceLabelText: { color: COLORS.textMuted, fontSize: 12, fontWeight: '800' },
    modalFooter: { 
      position: 'absolute', bottom: 0, left: 0, right: 0, 
      padding: 24, 
      backgroundColor: isDark ? '#151718' : '#FFFFFF', 
      borderTopWidth: 1, borderTopColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)',
      paddingBottom: Platform.OS === 'ios' ? 40 : 24 
    },
    applyBtn: { 
      height: 64, borderRadius: 32, backgroundColor: COLORS.kiwi, 
      justifyContent: 'center', alignItems: 'center', 
    },
    applyBtnText: { color: '#000', fontSize: 17, fontWeight: '900' },
  });
};
