import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, Platform, TouchableOpacity, Image, Dimensions, ActivityIndicator, RefreshControl } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';

import { useApp } from '@/src/context/AppContext';
import { GamificationService, OverallGamificationResponse } from '@/src/services/gamificationService';

const { width } = Dimensions.get('window');

export default function LeaderboardScreen() {
  const { COLORS, userProfile } = useApp();
  const styles = getStyles(COLORS);

  const [data, setData] = useState<OverallGamificationResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = async (isRefreshing = false) => {
    if (!isRefreshing) setLoading(true);
    try {
      const response = await GamificationService.getOverallStats();
      if (response.success) {
        setData(response.data);
      }
    } catch (error) {
      console.error('Failed to fetch leaderboard data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchStats(true);
  };

  const players = data?.leaderboard?.top10 || [];
  const currentUser = data?.leaderboard?.currentUser;
  const userAvatarUrl = currentUser?.avatarUrl || userProfile?.avatarUrl || null;

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollPadding}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.kiwi} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.push('/customer/home')}
            activeOpacity={0.7}
          >
            <Ionicons name="chevron-back" size={24} color={COLORS.textMain} />
          </TouchableOpacity>
          <Text style={styles.headerSub}>LEADERBOARD</Text>
          <Text style={styles.headerTitle}>Rankings</Text>
        </View>

        {loading && !refreshing ? (
          <View style={{ padding: 60, alignItems: 'center' }}>
            <ActivityIndicator size="large" color={COLORS.kiwi} />
          </View>
        ) : (
          <>
            {/* Nudge Banner */}
            {data?.nudge && (
              <View style={styles.nudgeBanner}>
                <Ionicons name="flame" size={16} color={COLORS.kiwi} />
                <Text style={styles.nudgeText}>{data.nudge}</Text>
              </View>
            )}

            {/* Stats Card */}
            <View style={styles.statsCard}>
              <View style={styles.statsHeaderRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.statsEyebrow}>YOUR STATS</Text>
                  <Text style={styles.statsTitle}>
                    {data?.streak && data.streak > 0 ? 'KEEP IT GOING!' : 'START YOUR STREAK'}
                  </Text>
                </View>
                {currentUser?.rank && (
                  <View style={styles.rankBadge}>
                    <Ionicons name="trophy-outline" size={13} color={COLORS.kiwi} />
                    <Text style={styles.rankBadgeText}>#{currentUser.rank}</Text>
                  </View>
                )}
              </View>

              <View style={styles.statsRow}>
                <View style={styles.statBox}>
                  <Text style={styles.statNumber}>{currentUser?.totalMatches ?? data?.totalMatches ?? 0}</Text>
                  <Text style={styles.statLabel}>MATCHES</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statBox}>
                  <Text style={styles.statNumber}>{currentUser?.points ?? data?.points ?? 0}</Text>
                  <Text style={styles.statLabel}>POINTS</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statBox}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={styles.statNumber}>{data?.streak ?? 0}D</Text>
                    <Ionicons name="flame" size={14} color={COLORS.kiwi} style={{ marginLeft: 3 }} />
                  </View>
                  <Text style={styles.statLabel}>STREAK</Text>
                </View>
              </View>
            </View>

            {/* Podium - Only show if 3+ players */}
            {players.length >= 3 && (
              <>
                <Text style={styles.podiumTitle}>Top 3</Text>
                <View style={styles.podiumContainer}>
                  {/* 2nd */}
                  <View style={styles.podiumItem}>
                    <View style={styles.podiumAvatarWrap}>
                      <Image
                        source={{ uri: players[1].avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(players[1].name)}&background=C7CDD6&color=000&size=120` }}
                        style={[styles.podiumAvatar, { borderColor: COLORS.silver }]}
                      />
                      <View style={[styles.podiumBadge, { backgroundColor: COLORS.silver }]}>
                        <Text style={styles.podiumBadgeText}>2</Text>
                      </View>
                    </View>
                    <Text style={styles.podiumName} numberOfLines={1}>{players[1].name.split(' ')[0]}</Text>
                    <Text style={styles.podiumPts}>{players[1].points.toLocaleString()} pts</Text>
                  </View>

                  {/* 1st */}
                  <View style={[styles.podiumItem, styles.podiumItemFirst]}>
                    <View style={styles.crownWrap}>
                      <MaterialCommunityIcons name="crown" size={22} color={COLORS.gold} />
                    </View>
                    <View style={styles.podiumAvatarWrap}>
                      <Image
                        source={{ uri: players[0].avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(players[0].name)}&background=F6C453&color=000&size=120` }}
                        style={[styles.podiumAvatar, styles.podiumAvatarFirst, { borderColor: COLORS.gold }]}
                      />
                      <View style={[styles.podiumBadge, styles.podiumBadgeFirst, { backgroundColor: COLORS.gold }]}>
                        <Text style={styles.podiumBadgeText}>1</Text>
                      </View>
                    </View>
                    <Text style={[styles.podiumName, { fontSize: 16, fontWeight: '900' }]} numberOfLines={1}>{players[0].name.split(' ')[0]}</Text>
                    <Text style={[styles.podiumPts, { color: COLORS.kiwi }]}>{players[0].points.toLocaleString()} pts</Text>
                  </View>

                  {/* 3rd */}
                  <View style={styles.podiumItem}>
                    <View style={styles.podiumAvatarWrap}>
                      <Image
                        source={{ uri: players[2].avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(players[2].name)}&background=C98752&color=000&size=120` }}
                        style={[styles.podiumAvatar, { borderColor: COLORS.bronze }]}
                      />
                      <View style={[styles.podiumBadge, { backgroundColor: COLORS.bronze }]}>
                        <Text style={styles.podiumBadgeText}>3</Text>
                      </View>
                    </View>
                    <Text style={styles.podiumName} numberOfLines={1}>{players[2].name.split(' ')[0]}</Text>
                    <Text style={styles.podiumPts}>{players[2].points.toLocaleString()} pts</Text>
                  </View>
                </View>
              </>
            )}

            {/* Rankings Section Title */}
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>
                {players.length > 0 ? 'All Rankings' : 'Rankings'}
              </Text>
              {players.length > 0 && (
                <View style={styles.countPill}>
                  <Text style={styles.countPillText}>{players.length}</Text>
                </View>
              )}
            </View>

            {/* Rankings List */}
            <View style={styles.rankingsCard}>
              {players.length === 0 ? (
                <View style={styles.emptyState}>
                  <MaterialCommunityIcons name="trophy-outline" size={48} color={COLORS.textMuted} />
                  <Text style={styles.emptyTitle}>No Rankings Yet</Text>
                  <Text style={styles.emptyText}>Be the first to play and climb the leaderboard!</Text>
                </View>
              ) : (
                (players.length >= 3 ? players.slice(3) : players).map((player, index) => {
                  const rank = players.length >= 3 ? index + 4 : index + 1;
                  return (
                    <View key={`${player.name}-${rank}`} style={[
                      styles.playerRow,
                      index === (players.length >= 3 ? players.length - 4 : players.length - 1) && { borderBottomWidth: 0 },
                    ]}>
                      <View style={styles.playerLeft}>
                        <View style={styles.rankWrap}>
                          {rank <= 3 ? (
                            <MaterialCommunityIcons name="medal" size={22} color={getMedalColor(rank, COLORS)} />
                          ) : (
                            <Text style={styles.rankNum}>{rank}</Text>
                          )}
                        </View>

                        <Image
                          source={{ uri: player.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(player.name)}&background=2A2C2E&color=fff&size=100` }}
                          style={styles.playerAvatar}
                        />

                        <View style={styles.playerInfo}>
                          <Text style={styles.playerName} numberOfLines={1}>{player.name}</Text>
                          <Text style={styles.playerSubtitle}>
                            {rank <= 3 ? getMedalLabel(rank) : `Rank #${rank}`}
                          </Text>
                        </View>
                      </View>

                      <View style={styles.playerRight}>
                        <Text style={styles.playerPts}>{player.points.toLocaleString()}</Text>
                        <Text style={styles.playerPtsLabel}>PTS</Text>
                      </View>
                    </View>
                  );
                })
              )}
            </View>

            {/* Your Standing Card - OUTSIDE the rankings card */}
            {currentUser && (
              <View style={styles.youCard}>
                <LinearGradient
                  colors={['rgba(137,233,0,0.12)', 'rgba(137,233,0,0.03)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.youCardInner}
                >
                  <View style={styles.youHeaderRow}>
                    <Text style={styles.youLabel}>YOUR POSITION</Text>
                    <View style={styles.climbBadge}>
                      <Ionicons name="trending-up" size={12} color={COLORS.kiwi} />
                      <Text style={styles.climbBadgeText}>CLIMB</Text>
                    </View>
                  </View>

                  <View style={styles.youRow}>
                    <View style={styles.youRankBox}>
                      <Text style={styles.youRankHash}>#</Text>
                      <Text style={styles.youRankNum}>{currentUser.rank ?? '-'}</Text>
                    </View>

                    <Image
                      source={{ uri: userAvatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}&background=89E900&color=000&size=100` }}
                      style={styles.youAvatar}
                    />

                    <View style={styles.youInfo}>
                      <Text style={styles.youName}>{currentUser.name}</Text>
                      <View style={styles.youStreakRow}>
                        <Ionicons name="flame" size={12} color={COLORS.kiwi} />
                        <Text style={styles.youStreakText}>{data?.streak || 0}D Streak</Text>
                      </View>
                    </View>

                    <View style={styles.youPtsWrap}>
                      <Text style={styles.youPts}>{currentUser.points.toLocaleString()}</Text>
                      <Text style={styles.youPtsLabel}>PTS</Text>
                    </View>
                  </View>

                  <TouchableOpacity
                    style={styles.ctaBtn}
                    activeOpacity={0.8}
                    onPress={() => router.push('/customer/explore')}
                  >
                    <LinearGradient
                      colors={[COLORS.kiwi, COLORS.primaryDark || '#6FC000']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={styles.ctaBtnGradient}
                    >
                      <Text style={styles.ctaBtnText}>Book Your Next Match</Text>
                      <Ionicons name="arrow-forward" size={16} color={COLORS.night} />
                    </LinearGradient>
                  </TouchableOpacity>
                </LinearGradient>
              </View>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

function getMedalColor(rank: number, COLORS: any) {
  if (rank === 1) return COLORS.gold;
  if (rank === 2) return COLORS.silver;
  return COLORS.bronze;
}

function getMedalLabel(rank: number) {
  if (rank === 1) return 'Gold';
  if (rank === 2) return 'Silver';
  return 'Bronze';
}

const getStyles = (COLORS: any) => {
  const isSmall = width < 380;

  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: COLORS.night,
    },
    scrollPadding: {
      paddingTop: Platform.OS === 'ios' ? 60 : 50,
      paddingBottom: 120,
    },

    // Header
    header: {
      paddingHorizontal: 20,
      marginBottom: 20,
    },
    backButton: {
      width: 40,
      height: 40,
      borderRadius: 12,
      backgroundColor: COLORS.surface,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 16,
      borderWidth: 1,
      borderColor: COLORS.border,
    },
    headerSub: {
      color: COLORS.kiwi,
      fontSize: 11,
      fontWeight: '800',
      letterSpacing: 3,
      marginBottom: 6,
    },
    headerTitle: {
      color: COLORS.textMain,
      fontSize: isSmall ? 30 : 34,
      fontWeight: '800',
    },

    // Nudge
    nudgeBanner: {
      flexDirection: 'row',
      alignItems: 'center',
      marginHorizontal: 20,
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderRadius: 14,
      backgroundColor: 'rgba(137,233,0,0.06)',
      borderWidth: 1,
      borderColor: 'rgba(137,233,0,0.12)',
      marginBottom: 16,
      gap: 10,
    },
    nudgeText: {
      color: COLORS.textMain,
      fontSize: 13,
      fontWeight: '700',
      flex: 1,
    },

    // Stats Card
    statsCard: {
      marginHorizontal: 20,
      marginBottom: 24,
      padding: 20,
      borderRadius: 24,
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
    },
    statsHeaderRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 20,
    },
    statsEyebrow: {
      color: COLORS.textMuted,
      fontSize: 10,
      fontWeight: '900',
      letterSpacing: 2,
      marginBottom: 4,
    },
    statsTitle: {
      color: COLORS.textMain,
      fontSize: isSmall ? 18 : 20,
      fontWeight: '800',
    },
    rankBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 5,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 20,
      backgroundColor: 'rgba(137,233,0,0.1)',
      borderWidth: 1,
      borderColor: 'rgba(137,233,0,0.2)',
    },
    rankBadgeText: {
      color: COLORS.kiwi,
      fontSize: 13,
      fontWeight: '900',
    },
    statsRow: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    statBox: {
      flex: 1,
      alignItems: 'center',
    },
    statNumber: {
      color: COLORS.textMain,
      fontSize: 22,
      fontWeight: '900',
    },
    statLabel: {
      color: COLORS.textMuted,
      fontSize: 10,
      fontWeight: '800',
      letterSpacing: 1,
      marginTop: 4,
    },
    statDivider: {
      width: 1,
      height: 36,
      backgroundColor: COLORS.border,
    },

    // Podium
    podiumTitle: {
      color: COLORS.textMain,
      fontSize: 20,
      fontWeight: '800',
      marginHorizontal: 20,
      marginBottom: 16,
    },
    podiumContainer: {
      flexDirection: 'row',
      alignItems: 'flex-end',
      justifyContent: 'center',
      marginHorizontal: 20,
      marginBottom: 28,
      paddingTop: 30,
    },
    podiumItem: {
      flex: 1,
      alignItems: 'center',
    },
    podiumItemFirst: {
      marginTop: -30,
    },
    podiumAvatarWrap: {
      position: 'relative',
      alignItems: 'center',
      marginBottom: 10,
    },
    podiumAvatar: {
      width: 64,
      height: 64,
      borderRadius: 32,
      borderWidth: 3,
      backgroundColor: COLORS.surface,
    },
    podiumAvatarFirst: {
      width: 80,
      height: 80,
      borderRadius: 40,
    },
    podiumBadge: {
      position: 'absolute',
      bottom: -5,
      width: 22,
      height: 22,
      borderRadius: 11,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 2,
      borderColor: COLORS.night,
    },
    podiumBadgeFirst: {
      width: 26,
      height: 26,
      borderRadius: 13,
    },
    podiumBadgeText: {
      color: COLORS.night,
      fontSize: 11,
      fontWeight: '900',
    },
    podiumName: {
      color: COLORS.textMain,
      fontSize: 13,
      fontWeight: '700',
      marginBottom: 2,
      maxWidth: 90,
      textAlign: 'center',
    },
    podiumPts: {
      color: COLORS.textMuted,
      fontSize: 11,
      fontWeight: '600',
    },
    crownWrap: {
      alignItems: 'center',
      marginBottom: 4,
    },

    // Section Header
    sectionHeaderRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginHorizontal: 20,
      marginBottom: 12,
      gap: 10,
    },
    sectionTitle: {
      color: COLORS.textMain,
      fontSize: 20,
      fontWeight: '800',
    },
    countPill: {
      backgroundColor: 'rgba(137,233,0,0.12)',
      paddingHorizontal: 10,
      paddingVertical: 3,
      borderRadius: 20,
    },
    countPillText: {
      color: COLORS.kiwi,
      fontSize: 12,
      fontWeight: '900',
    },

    // Rankings Card
    rankingsCard: {
      marginHorizontal: 20,
      borderRadius: 20,
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
      overflow: 'hidden',
    },

    // Empty State
    emptyState: {
      paddingVertical: 48,
      alignItems: 'center',
      gap: 12,
    },
    emptyTitle: {
      color: COLORS.textMain,
      fontSize: 18,
      fontWeight: '800',
    },
    emptyText: {
      color: COLORS.textMuted,
      fontSize: 14,
      textAlign: 'center',
      maxWidth: '80%',
    },

    // Player Row
    playerRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingVertical: 12,
      paddingHorizontal: 16,
      borderBottomWidth: 1,
      borderBottomColor: COLORS.border,
    },
    playerLeft: {
      flexDirection: 'row',
      alignItems: 'center',
      flex: 1,
    },
    rankWrap: {
      width: 32,
      alignItems: 'center',
      marginRight: 10,
    },
    rankNum: {
      color: COLORS.textMuted,
      fontSize: 15,
      fontWeight: '800',
    },
    playerAvatar: {
      width: 40,
      height: 40,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: COLORS.border,
      marginRight: 12,
      backgroundColor: COLORS.surface,
    },
    playerInfo: {
      flex: 1,
    },
    playerName: {
      color: COLORS.textMain,
      fontSize: 15,
      fontWeight: '700',
      marginBottom: 2,
    },
    playerSubtitle: {
      color: COLORS.textMuted,
      fontSize: 11,
      fontWeight: '600',
    },
    playerRight: {
      alignItems: 'flex-end',
      marginLeft: 10,
    },
    playerPts: {
      color: COLORS.textMain,
      fontSize: 17,
      fontWeight: '900',
    },
    playerPtsLabel: {
      color: COLORS.textMuted,
      fontSize: 10,
      fontWeight: '700',
    },

    // Your Standing Card
    youCard: {
      marginHorizontal: 20,
      marginTop: 20,
      borderRadius: 22,
      overflow: 'hidden',
      borderWidth: 1.5,
      borderColor: 'rgba(137,233,0,0.2)',
    },
    youCardInner: {
      padding: 16,
    },
    youHeaderRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 14,
    },
    youLabel: {
      color: COLORS.textMuted,
      fontSize: 10,
      fontWeight: '900',
      letterSpacing: 2,
    },
    climbBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
      backgroundColor: 'rgba(137,233,0,0.12)',
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 12,
    },
    climbBadgeText: {
      color: COLORS.kiwi,
      fontSize: 9,
      fontWeight: '900',
      letterSpacing: 1,
    },
    youRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 16,
    },
    youRankBox: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      marginRight: 10,
    },
    youRankHash: {
      color: COLORS.kiwi,
      fontSize: 13,
      fontWeight: '900',
      marginTop: 2,
    },
    youRankNum: {
      color: COLORS.textMain,
      fontSize: 24,
      fontWeight: '900',
      letterSpacing: -1,
    },
    youAvatar: {
      width: 44,
      height: 44,
      borderRadius: 22,
      borderWidth: 2,
      borderColor: COLORS.kiwi,
      marginRight: 12,
      backgroundColor: COLORS.surface,
    },
    youInfo: {
      flex: 1,
    },
    youName: {
      color: COLORS.textMain,
      fontSize: 16,
      fontWeight: '800',
      marginBottom: 3,
    },
    youStreakRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
    },
    youStreakText: {
      color: COLORS.kiwi,
      fontSize: 11,
      fontWeight: '800',
    },
    youPtsWrap: {
      alignItems: 'flex-end',
    },
    youPts: {
      color: COLORS.textMain,
      fontSize: 20,
      fontWeight: '900',
    },
    youPtsLabel: {
      color: COLORS.textMuted,
      fontSize: 10,
      fontWeight: '700',
    },

    // CTA Button
    ctaBtn: {
      borderRadius: 16,
      overflow: 'hidden',
    },
    ctaBtnGradient: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 14,
      gap: 8,
    },
    ctaBtnText: {
      color: COLORS.night,
      fontSize: 15,
      fontWeight: '900',
    },
  });
};
