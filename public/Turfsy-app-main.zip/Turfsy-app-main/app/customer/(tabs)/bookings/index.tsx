import React, { useState, useEffect, useCallback } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Dimensions, Platform, StatusBar, ActivityIndicator, Modal, TextInput, Alert, KeyboardAvoidingView } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';
import { Ionicons, Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import { useApp } from '@/src/context/AppContext';
import { Booking } from '@/src/types/booking.types';
import { BookingService } from '@/src/services/bookingService';

const { width } = Dimensions.get('window');

function formatDisplayDate(dateValue?: unknown) {
  if (!dateValue) return '—';
  if (typeof dateValue !== 'string') return '—';
  const d = new Date(dateValue);
  if (!Number.isFinite(d.getTime())) return '—';
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

const DashedLine = ({ color }: { color: string }) => (
  <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', overflow: 'hidden', height: 2 }}>
    {Array.from({ length: 30 }).map((_, i) => (
      <View 
        key={i} 
        style={{ 
          width: 6, 
          height: 1.5, 
          backgroundColor: color, 
          marginRight: 5, 
          borderRadius: 1 
        }} 
      />
    ))}
  </View>
);

function BookingCard({ booking, onRatePress }: { booking: Booking, onRatePress?: (b: Booking) => void }) {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);
  
  const isDark = COLORS.isDark;

  const getStatusColor = (status: string) => {
    const s = status.toUpperCase();
    if (s === 'CONFIRMED' || s === 'UPCOMING') return '#7ED321'; // Green
    if (s === 'PENDING' || s === 'PENDING_APPROVAL') return '#FFB800'; // Orange/Yellow
    if (s === 'COMPLETED') return '#007AFF'; // Blue
    if (s === 'NO_SHOW') return '#8E8E93'; // Gray
    if (s === 'CANCELLED' || s === 'REJECTED') return '#FF453A'; // Red
    return '#666';
  };
  
  const turfName = booking.turf?.name || booking.turfName || 'Turf Venue';
  const displayId = booking.displayId || booking.bookingCode || 'N/A';
  const timeStr = booking.startTime ? `${booking.startTime} - ${booking.endTime}` : (booking.timeSlot || '');
  const dateValue =
    typeof booking.bookingDate === 'string'
      ? booking.bookingDate
      : typeof booking.date === 'string'
        ? booking.date
        : booking.bookingDate;
  const hoursCount = booking.durationMins ? (booking.durationMins / 60) : (booking.hours || 0);
  const sportType = booking.turf?.sportsType || booking.sport || 'Sport';
  const total = booking.amount || booking.totalAmount || 0;
  
  const status = (booking.bookingStatus || booking.status || '').toUpperCase();
  const isUpcoming = status === 'CONFIRMED' || status === 'UPCOMING';
  const isPending = status === 'PENDING' || status === 'PENDING_APPROVAL';
  const isCompleted = status === 'COMPLETED';
  const isCancelled = status === 'CANCELLED';
  const isNoShow = status === 'NO_SHOW';

  const statusLabel = isNoShow ? 'NO SHOW' : isPending ? 'PENDING' : status;

  return (
    <TouchableOpacity 
      style={[
        styles.bookingCard, 
        isNoShow && { opacity: 0.8, borderColor: isDark ? '#222' : '#ccc' }
      ]} 
      activeOpacity={0.9}
      onPress={() => router.push({ pathname: '/customer/booking/confirm', params: { code: displayId, id: booking.id } })}
    >
      {/* Removed LinearGradient to revert to old background */}
      {/* Top Section */}
      <View style={styles.ticketSectionTop}>
        <View style={styles.statusRow}>
          <View style={styles.statusPill}>
            <View style={[styles.statusDot, { backgroundColor: getStatusColor(status) }]} />
            <Text style={styles.statusText}>
              {statusLabel}
            </Text>
          </View>
        </View>
        
        <View style={styles.ticketInfoRow}>
          <View>
            <Text style={styles.ticketTime}>{timeStr}</Text>
            <Text style={styles.ticketDate}>{formatDisplayDate(dateValue)}</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.ticketDuration}>{hoursCount}h</Text>
            <Text style={styles.ticketLabel}>DURATION</Text>
          </View>
        </View>
      </View>

      {/* Divider */}
      <View style={styles.ticketDividerWrap}>
        <View style={styles.ticketNotchLeft} />
        <DashedLine color={isDark ? 'rgba(174,234,0,0.15)' : 'rgba(0,0,0,0.1)'} />
        <View style={styles.ticketNotchRight} />
      </View>

      {/* Bottom Section */}
      <View style={styles.ticketSectionBottom}>
        <View style={styles.bottomMainRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.ticketTurfName} numberOfLines={1}>{turfName}</Text>
            <View style={styles.metaRow}>
              <Text style={styles.ticketBookingId}>#{displayId}</Text>
              <View style={styles.sportTag}>
                <Text style={styles.sportTagText}>{sportType}</Text>
              </View>
            </View>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.ticketPrice}>₹{total.toLocaleString()}</Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionRow}>
          {isUpcoming ? (
            <View style={{ flexDirection: 'row', gap: 10, width: '100%', marginTop: 8 }}>
              <TouchableOpacity 
                style={[styles.detailsBtn, { flex: 1, borderColor: isDark ? COLORS.kiwi : '#1a4a00' }]} 
                activeOpacity={0.8}
                onPress={() => router.push({ pathname: '/customer/booking/split', params: { id: booking.id } })}
              >
                <MaterialCommunityIcons name="bank-transfer" size={16} color={isDark ? COLORS.kiwi : '#1a4a00'} style={{ marginRight: 4 }} />
                <Text style={[styles.detailsBtnText, { color: isDark ? COLORS.kiwi : '#1a4a00', fontSize: 11 }]}>
                  View Split
                </Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.detailsBtn, { flex: 1, borderColor: isDark ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)' }]} 
                activeOpacity={0.8}
                onPress={() => router.push({ pathname: '/customer/booking/invoice', params: { bookingId: booking.id } })}
              >
                <Feather name="file-text" size={14} color={isDark ? '#fff' : '#000'} style={{ marginRight: 4 }} />
                <Text style={[styles.detailsBtnText, { color: isDark ? '#fff' : '#000', fontSize: 11 }]}>Invoice</Text>
              </TouchableOpacity>
            </View>
          ) : isCompleted ? (
            <View style={{ flexDirection: 'row', gap: 10, width: '100%', marginTop: 8 }}>
              {!booking.rating ? (
                <TouchableOpacity 
                  style={[styles.actionBtn, { flex: 1, backgroundColor: COLORS.kiwi }]} 
                  activeOpacity={0.8}
                  onPress={() => onRatePress && onRatePress(booking)}
                >
                  <Ionicons name="star" size={12} color="#000" style={{ marginRight: 4 }} />
                  <Text style={[styles.actionBtnText, { color: '#000', fontSize: 11 }]}>Rate Turf</Text>
                </TouchableOpacity>
              ) : (
                <View style={[styles.actionBtn, { flex: 1, backgroundColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)' }]}>
                  <Ionicons name="star" size={12} color={isDark ? COLORS.kiwi : '#000'} style={{ marginRight: 4 }} />
                  <Text style={[styles.actionBtnText, { color: isDark ? '#fff' : '#000', fontSize: 11 }]}>
                    Rated {typeof booking.rating === 'object' ? (booking.rating as any).rating : booking.rating}★
                  </Text>
                </View>
              )}
              <TouchableOpacity 
                style={[styles.actionBtn, { flex: 1, backgroundColor: isDark ? '#fff' : '#000' }]} 
                activeOpacity={0.8}
                onPress={() => router.push({ 
                  pathname: '/customer/booking/book', 
                  params: { 
                    id: booking.turfId, 
                    rebookId: booking.id,
                    startTime: booking.startTime,
                    endTime: booking.endTime
                  } 
                })}
              >
                <Feather name="refresh-cw" size={12} color={isDark ? '#000' : '#fff'} style={{ marginRight: 4 }} />
                <Text style={[styles.actionBtnText, { color: isDark ? '#000' : '#fff', fontSize: 11 }]}>Rebook</Text>
              </TouchableOpacity>
            </View>
          ) : isPending ? (
            <View style={{ flexDirection: 'row', gap: 10, width: '100%', marginTop: 8 }}>
              <TouchableOpacity 
                style={[styles.detailsBtn, { flex: 1, borderColor: isDark ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)' }]} 
                activeOpacity={0.8}
                onPress={() => router.push({ pathname: '/customer/booking/invoice', params: { bookingId: booking.id } })}
              >
                <Feather name="file-text" size={14} color={isDark ? '#fff' : '#000'} style={{ marginRight: 4 }} />
                <Text style={[styles.detailsBtnText, { color: isDark ? '#fff' : '#000', fontSize: 11 }]}>Invoice</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.detailsBtn, { flex: 1, borderColor: isDark ? COLORS.kiwi : '#1a4a00' }]} 
                activeOpacity={0.8}
                onPress={() => router.push({ pathname: '/customer/booking/split', params: { id: booking.id } })}
              >
                <MaterialCommunityIcons name="bank-transfer" size={16} color={isDark ? COLORS.kiwi : '#1a4a00'} style={{ marginRight: 4 }} />
                <Text style={[styles.detailsBtnText, { color: isDark ? COLORS.kiwi : '#1a4a00', fontSize: 11 }]}>
                  View Split
                </Text>
              </TouchableOpacity>
            </View>
          ) : (isCancelled || isNoShow) ? (
            <View style={{ flexDirection: 'row', gap: 10, width: '100%', marginTop: 8 }}>
              <TouchableOpacity 
                style={[styles.actionBtn, { flex: 1, backgroundColor: isDark ? '#fff' : '#000' }]} 
                activeOpacity={0.8}
                onPress={() => router.push({ 
                  pathname: '/customer/booking/book', 
                  params: { 
                    id: booking.turfId, 
                    rebookId: booking.id,
                    startTime: booking.startTime,
                    endTime: booking.endTime
                  } 
                })}
              >
                <Feather name="refresh-cw" size={12} color={isDark ? '#000' : '#fff'} style={{ marginRight: 4 }} />
                <Text style={[styles.actionBtnText, { color: isDark ? '#000' : '#fff', fontSize: 11 }]}>Rebook</Text>
              </TouchableOpacity>
            </View>
          ) : null}
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default function BookingsScreen() {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);

  const TABS = ['All', 'Upcoming', 'Pending', 'Completed', 'Cancelled', 'Missed'] as const;
  type TabType = typeof TABS[number];
  const [activeTab, setActiveTab] = useState<TabType>('All');
  
  const { bookings, setBookings } = useApp();
  const [loading, setLoading] = useState(true);

  // Rating States
  const [ratingModalVisible, setRatingModalVisible] = useState(false);
  const [ratingBooking, setRatingBooking] = useState<Booking | null>(null);
  const [ratingValue, setRatingValue] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [submittingRating, setSubmittingRating] = useState(false);

  const openRatingModal = useCallback((booking: Booking) => {
    setRatingBooking(booking);
    setRatingValue(0);
    setReviewText('');
    setRatingModalVisible(true);
  }, []);

  const submitRating = async () => {
    if (!ratingBooking || ratingValue === 0) return;
    setSubmittingRating(true);
    try {
      const res = await BookingService.rateTurf(ratingBooking.id, { rating: ratingValue, review: reviewText || undefined });
      if (res.success || res.message === 'Thank you for your review!') {
        Alert.alert("Success", res.message || "Thank you for your review!");
        setRatingModalVisible(false);
        fetchBookings(false); // refresh bookings
      } else {
        Alert.alert("Error", res.message || "Failed to submit rating.");
      }
    } catch (err: any) {
      Alert.alert("Error", err.message || "Network error");
    } finally {
      setSubmittingRating(false);
    }
  };

  const fetchBookings = useCallback(async (showLoading = true) => {
    if (showLoading) setLoading(true);
    try {
      const res = await BookingService.getUserBookings();
      setBookings(res);
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
    } finally {
      if (showLoading) setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBookings(true);
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchBookings(false); // Refresh without showing full screen loader
    }, [])
  );

  const filtered = bookings.filter(b => {
    if (activeTab === 'All') return true;
    const status = (b.bookingStatus || b.status || '').toUpperCase();
    
    if (activeTab === 'Upcoming') return status === 'CONFIRMED' || status === 'UPCOMING';
    if (activeTab === 'Pending') return status === 'PENDING' || status === 'PENDING_APPROVAL';
    if (activeTab === 'Completed') return status === 'COMPLETED';
    if (activeTab === 'Cancelled') return status === 'CANCELLED';
    if (activeTab === 'Missed') return status === 'NO_SHOW';
    return false;
  });

  const getTabCount = (tab: TabType) => {
    if (tab === 'All') return bookings.length;
    return bookings.filter(b => {
      const status = (b.bookingStatus || b.status || '').toUpperCase();
      if (tab === 'Upcoming') return status === 'CONFIRMED' || status === 'UPCOMING';
      if (tab === 'Pending') return status === 'PENDING' || status === 'PENDING_APPROVAL';
      if (tab === 'Completed') return status === 'COMPLETED';
      if (tab === 'Cancelled') return status === 'CANCELLED';
      if (tab === 'Missed') return status === 'NO_SHOW';
      return false;
    }).length;
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle={COLORS.isDark ? "light-content" : "dark-content"} />
      <View style={styles.ambientGlow} />

      <View style={styles.header}>
        <Text style={styles.headerSub}>YOUR SCHEDULE</Text>
        <Text style={styles.headerTitle}>My Bookings</Text>
      </View>

      <View style={styles.tabWrapper}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabScrollContent}
        >
          {TABS.map((tab) => {
            const isActive = activeTab === tab;
            const count = getTabCount(tab);
            
            return (
              <TouchableOpacity
                key={tab}
                onPress={() => setActiveTab(tab)}
                style={[styles.tabItem, isActive && styles.activeTabItem]}
                activeOpacity={0.7}
              >
                <Text style={[styles.tabText, isActive && styles.activeTabText]}>{tab}</Text>
                {count > 0 && (
                  <View style={[styles.countBadge, isActive && styles.countBadgeActive]}>
                    <Text style={[styles.countText, isActive && styles.countTextActive]}>{count}</Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {filtered.length === 0 ? (
          <View style={styles.emptyContainer}>
            <View style={styles.iconCircle}>
              <Feather name="calendar" size={42} color={COLORS.kiwi} />
              <View style={styles.glowRing} />
            </View>
            <Text style={styles.emptyTitle}>No {activeTab.toLowerCase()} sessions</Text>
            <Text style={styles.emptySub}>
              Your roster is empty for now.{'\n'}Time to book your next match!
            </Text>
            <TouchableOpacity style={styles.exploreBtn} activeOpacity={0.9} onPress={() => router.push('/customer/explore')}>
              <LinearGradient colors={[COLORS.kiwi, '#00B386']} style={styles.gradientBtn} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                <Text style={styles.exploreBtnText}>Find a Venue</Text>
                <Ionicons name="arrow-forward" size={18} color="#000" style={{ marginLeft: 8 }} />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.cardList}>
            {filtered.map(b => <BookingCard key={b.id} booking={b} onRatePress={openRatingModal} />)}
          </View>
        )}
      </ScrollView>

      {/* Rating Modal */}
      <Modal visible={ratingModalVisible} animationType="fade" transparent={true} onRequestClose={() => setRatingModalVisible(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: COLORS.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: Platform.OS === 'ios' ? 40 : 24 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <Text style={{ color: COLORS.textMain, fontSize: 20, fontWeight: '800' }}>Rate Your Experience</Text>
              <TouchableOpacity onPress={() => setRatingModalVisible(false)}>
                <Ionicons name="close" size={24} color={COLORS.textMain} />
              </TouchableOpacity>
            </View>
            <Text style={{ color: COLORS.textMuted, fontSize: 14 }}>
              How was your match at {ratingBooking?.turf?.name || ratingBooking?.turfName}?
            </Text>
            
            <View style={{ flexDirection: 'row', gap: 10, justifyContent: 'center', marginVertical: 20 }}>
              {[1, 2, 3, 4, 5].map(star => (
                <TouchableOpacity key={star} onPress={() => setRatingValue(star)}>
                  <Ionicons 
                    name={ratingValue >= star ? 'star' : 'star-outline'} 
                    size={40} 
                    color={ratingValue >= star ? '#FFD700' : '#888'} 
                  />
                </TouchableOpacity>
              ))}
            </View>
            
            <TextInput
              style={{ backgroundColor: COLORS.isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)', borderRadius: 12, padding: 16, color: COLORS.textMain, minHeight: 100, textAlignVertical: 'top', marginBottom: 20 }}
              placeholder="Leave a review (optional)"
              placeholderTextColor={COLORS.textMuted}
              multiline
              value={reviewText}
              onChangeText={setReviewText}
              maxLength={500}
            />
            
            <TouchableOpacity 
              style={{ backgroundColor: ratingValue > 0 ? COLORS.kiwi : 'rgba(137,233,0,0.3)', padding: 16, borderRadius: 16, alignItems: 'center', justifyContent: 'center' }}
              disabled={ratingValue === 0 || submittingRating}
              onPress={submitRating}
            >
              {submittingRating ? (
                <ActivityIndicator color="#000" />
              ) : (
                <Text style={{ color: '#000', fontSize: 16, fontWeight: '800' }}>Submit Review</Text>
              )}
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const getStyles = (COLORS: any) => {
  const isDark = COLORS.isDark;
  
  return StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.night },
  ambientGlow: { position: 'absolute', top: -100, left: -50, width: 300, height: 300, backgroundColor: COLORS.kiwi, borderRadius: 150, opacity: 0.04 },
  header: { paddingHorizontal: 24, paddingTop: Platform.OS === 'ios' ? 60 : 40, marginBottom: 12 },
  headerSub: { color: COLORS.kiwi, fontSize: 13, fontWeight: '900', letterSpacing: 2, marginBottom: 4, fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System' },
  headerTitle: { color: COLORS.textMain, fontSize: 34, fontWeight: '900', letterSpacing: -1, fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System' },

  tabWrapper: { 
    backgroundColor: COLORS.surface,
    marginHorizontal: 16,
    borderRadius: 24,
    padding: 6,
    marginBottom: 24,
    borderWidth: 1.5,
    borderColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.08)',
  },
  tabScrollContent: {
    gap: 8,
    paddingRight: 10,
  },
  tabItem: { 
    paddingHorizontal: 22, 
    paddingVertical: 12, 
    alignItems: 'center', 
    borderRadius: 18, 
    flexDirection: 'row', 
    justifyContent: 'center', 
    gap: 8,
  },
  activeTabItem: { 
    backgroundColor: COLORS.kiwi, 
    borderWidth: 1,
    borderColor: '#00B386',
  },
  tabText: { color: COLORS.textMuted, fontWeight: '900', fontSize: 13, textTransform: 'uppercase', letterSpacing: 0.8 },
  activeTabText: { color: '#000' },
  countBadge: { 
    backgroundColor: isDark ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.08)', 
    borderRadius: 8, 
    paddingHorizontal: 8, 
    paddingVertical: 3, 
    minWidth: 26, 
    alignItems: 'center', 
    justifyContent: 'center' 
  },
  countBadgeActive: { backgroundColor: 'rgba(0,0,0,0.12)' },
  countText: { color: COLORS.textMuted, fontSize: 10, fontWeight: '900' },
  countTextActive: { color: '#000' },

  content: { flexGrow: 1, paddingBottom: 140 },
  cardList: { paddingHorizontal: 16, gap: 16 },

  bookingCard: {
    backgroundColor: isDark ? '#1a2a0a' : COLORS.kiwi,
    borderRadius: 20,
    minHeight: 140,
    width: '100%',
    position: 'relative',
    borderWidth: 1.5,
    borderColor: isDark ? COLORS.kiwi : 'rgba(0,0,0,0.05)',
    overflow: 'visible',
    // Shadow
    ...Platform.select({
      ios: {
        shadowColor: '#7ED321',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: isDark ? 0.2 : 0.25,
        shadowRadius: 15,
      },
      android: {
        elevation: 6,
      },
    }),
  },
  
  ticketSectionTop: { 
    paddingHorizontal: 16, 
    paddingTop: 10, 
    paddingBottom: 2 
  },
  statusRow: {
    marginBottom: 8,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    alignSelf: 'flex-start',
    gap: 6,
    backgroundColor: isDark ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 0, 0, 0.08)',
    borderWidth: 1,
    borderColor: isDark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.03)',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: 9,
    fontWeight: '900',
    color: isDark ? '#fff' : '#000',
    letterSpacing: 0.6,
  },
  ticketSectionBottom: { 
    paddingHorizontal: 16, 
    paddingTop: 2, 
    paddingBottom: 10 
  },
  ticketInfoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  ticketTime: { 
    color: isDark ? '#fff' : '#0d0d0d', 
    fontSize: 18, 
    fontWeight: '900', 
    letterSpacing: -0.4,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },
  ticketDuration: { 
    color: isDark ? '#fff' : '#0d0d0d', 
    fontSize: 18, 
    fontWeight: '800',
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },
  ticketDate: {
    color: isDark ? COLORS.kiwi : '#1a4a00',
    fontSize: 11,
    fontWeight: '800',
    marginTop: 0,
    opacity: isDark ? 1 : 0.8,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },
  ticketLabel: { 
    color: isDark ? COLORS.kiwi : '#1a4a00', 
    fontSize: 9, 
    fontWeight: '900', 
    textTransform: 'uppercase', 
    letterSpacing: 1.5, 
    marginTop: 0,
    opacity: isDark ? 0.9 : 0.8,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },
  
  ticketDividerWrap: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center',
    height: 1, 
    width: '100%',
    position: 'relative',
    marginVertical: 2,
    paddingHorizontal: 12,
  },
  ticketNotchLeft: { 
    position: 'absolute',
    left: -11.5,
    top: '50%',
    marginTop: -10,
    width: 20, 
    height: 20, 
    borderRadius: 10, 
    backgroundColor: isDark ? COLORS.night : '#f5f5f5',
    borderRightWidth: 1.5,
    borderColor: isDark ? COLORS.kiwi : 'rgba(0,0,0,0.05)',
    zIndex: 10,
  },
  ticketNotchRight: { 
    position: 'absolute',
    right: -11.5,
    top: '50%',
    marginTop: -10,
    width: 20, 
    height: 20, 
    borderRadius: 10, 
    backgroundColor: isDark ? COLORS.night : '#f5f5f5',
    borderLeftWidth: 1.5,
    borderColor: isDark ? COLORS.kiwi : 'rgba(0,0,0,0.05)',
    zIndex: 10,
  },

  bottomMainRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  ticketTurfName: { 
    color: isDark ? '#fff' : '#0d0d0d', 
    fontSize: 16, 
    fontWeight: '900', 
    marginBottom: 0,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
  },
  ticketBookingId: {
    color: isDark ? COLORS.kiwi : '#1a4a00',
    fontSize: 10,
    fontWeight: '800',
    backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },
  sportTag: {
    backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  sportTagText: {
    fontSize: 9,
    fontWeight: '800',
    color: isDark ? COLORS.kiwi : '#1a4a00',
    textTransform: 'uppercase',
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },
  ticketPrice: { 
    color: isDark ? '#fff' : '#0d0d0d', 
    fontSize: 26, 
    fontWeight: '900', 
    letterSpacing: -0.5,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },

  actionRow: {
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  actionBtn: {
    height: 38,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionBtnText: {
    fontSize: 12,
    fontWeight: '800',
  },
  detailsBtn: {
    height: 38,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.1)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  detailsBtnText: {
    color: isDark ? '#fff' : '#000',
    fontSize: 14,
    fontWeight: '800',
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System'
  },

  emptyContainer: { alignItems: 'center', paddingHorizontal: 40, flex: 1, justifyContent: 'center', paddingTop: 60 },
  iconCircle: { width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(137, 233, 0, 0.05)', justifyContent: 'center', alignItems: 'center', marginBottom: 32, borderWidth: 1, borderColor: 'rgba(137, 233, 0, 0.1)' },
  glowRing: { position: 'absolute', width: 140, height: 140, borderRadius: 70, borderWidth: 1, borderColor: 'rgba(137, 233, 0, 0.03)' },
  emptyTitle: { color: COLORS.textMain, fontSize: 24, fontWeight: '900', marginBottom: 12 },
  emptySub: { color: COLORS.textMuted, fontSize: 16, textAlign: 'center', lineHeight: 24, marginBottom: 32 },
  exploreBtn: { width: '85%', height: 60, borderRadius: 20, overflow: 'hidden' },
  gradientBtn: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  exploreBtnText: { color: '#000', fontSize: 16, fontWeight: '900', letterSpacing: 0.5 },
});
}
