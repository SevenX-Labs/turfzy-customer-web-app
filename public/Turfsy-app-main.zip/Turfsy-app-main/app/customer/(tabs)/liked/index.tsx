import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Image, Platform, ActivityIndicator, RefreshControl, FlatList, InteractionManager } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useApp } from '@/src/context/AppContext';
import { TurfService } from '@/src/services/turfService';
import { TurfCard } from '@/src/services/homeService';

export default function LikedScreen() {
  const { COLORS, toggleFavoriteTurf } = useApp();
  const styles = useMemo(() => getStyles(COLORS), [COLORS]);

  const [savedTurfs, setSavedTurfs] = useState<{
    savedId: string;
    savedAt: string;
    notes?: string;
    turfDetails: TurfCard;
  }[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchSavedTurfs = useCallback(async (isRefresh = false) => {
    if (!isRefresh) setLoading(true);
    InteractionManager.runAfterInteractions(async () => {
      try {
        const response = await TurfService.getSavedTurfs();
        if (response.success) {
          setSavedTurfs(response.data);
        }
      } catch (error) {
        console.error('Failed to fetch saved turfs:', error);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    });
  }, []);

  useEffect(() => {
    fetchSavedTurfs();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchSavedTurfs(true);
  };

  const onToggleFavorite = useCallback(async (turfId: string) => {
    // Call the global toggle
    await toggleFavoriteTurf(turfId);
    // Refresh local list after toggle
    setTimeout(() => fetchSavedTurfs(true), 100);
  }, [toggleFavoriteTurf, fetchSavedTurfs]);

  const renderItem = useCallback(({ item }: { item: any }) => {
    const turf = item.turfDetails;
    return (
      <TouchableOpacity
        style={styles.card}
        activeOpacity={0.9}
        onPress={() => router.push({ pathname: '/customer/booking/detail', params: { id: turf.id } })}
      >
        <Image 
          source={{ uri: turf.images?.[0] }} 
          style={[styles.cardImage, turf.status !== 'ACTIVE' && { opacity: 0.6 }]} 
        />
        {turf.status !== 'ACTIVE' && (
          <View style={{ position: 'absolute', top: 12, left: 12, backgroundColor: 'rgba(255,149,0,0.9)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, zIndex: 10 }}>
            <Text style={{ color: '#fff', fontSize: 10, fontWeight: '900' }}>{turf.status.replace('_', ' ')}</Text>
          </View>
        )}
        <View style={styles.cardBody}>
          <View style={styles.titleRow}>
            <Text style={styles.cardTitle}>{turf.name}</Text>
            <TouchableOpacity onPress={() => onToggleFavorite(turf.id)} style={styles.heartButton}>
              <Ionicons name="heart" size={18} color="#FF453A" />
            </TouchableOpacity>
          </View>
          <Text style={styles.cardMeta} numberOfLines={1}>{turf.address}</Text>
          <Text style={styles.cardMeta}>
            {turf.sportsType} • {turf.city}
            {turf.distanceKm ? ` • ${turf.distanceKm} km` : ''}
          </Text>
          <View style={styles.footerRow}>
            <Text style={styles.price}>₹{turf.weekdayDayPrice.toLocaleString()}<Text style={styles.perHr}>/hr</Text></Text>
            <View style={styles.ratingPill}>
              <Ionicons name="star" size={12} color={COLORS.kiwi} />
              <Text style={styles.ratingText}>{Number(turf.rating || 0).toFixed(1)}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  }, [COLORS, styles, onToggleFavorite]);

  const HeaderComponent = useMemo(() => (
    <View style={styles.header}>
      <Text style={styles.headerSub}>YOUR PICKS</Text>
      <Text style={styles.headerTitle}>Liked Turfs</Text>
      <Text style={styles.headerText}>
        {savedTurfs.length} venue{savedTurfs.length === 1 ? '' : 's'} saved for quick booking.
      </Text>
    </View>
  ), [styles, savedTurfs.length]);

  const EmptyComponent = useMemo(() => (
    <View style={styles.emptyState}>
      <View style={styles.emptyIcon}>
        <Ionicons name="heart-outline" size={28} color={COLORS.kiwi} />
      </View>
      <Text style={styles.emptyTitle}>No liked turfs yet</Text>
      <Text style={styles.emptyText}>Tap the heart on any turf to save it here.</Text>
      <TouchableOpacity style={styles.exploreButton} onPress={() => router.push('/customer/explore')}>
        <Text style={styles.exploreButtonText}>Explore Turfs</Text>
      </TouchableOpacity>
    </View>
  ), [COLORS, styles]);

  return (
    <View style={styles.container}>
      <View style={styles.ambientGlow} />

      <FlatList
        data={savedTurfs}
        renderItem={renderItem}
        keyExtractor={(item) => item.savedId}
        contentContainerStyle={styles.scrollPadding}
        ListHeaderComponent={HeaderComponent}
        ListEmptyComponent={loading && !refreshing ? (
          <View style={{ padding: 40, alignItems: 'center' }}>
            <ActivityIndicator size="large" color={COLORS.kiwi} />
          </View>
        ) : EmptyComponent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.kiwi} />
        }
        showsVerticalScrollIndicator={false}
        initialNumToRender={5}
        maxToRenderPerBatch={5}
        windowSize={10}
        removeClippedSubviews={true}
      />
    </View>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.night },
  ambientGlow: {
    position: 'absolute',
    top: -90,
    left: -60,
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: COLORS.kiwi,
    opacity: 0.05,
  },
  scrollPadding: { paddingTop: Platform.OS === 'ios' ? 80 : 60, paddingBottom: 140 },
  header: { paddingHorizontal: 24, marginBottom: 24 },
  headerSub: { color: COLORS.kiwi, fontSize: 12, fontWeight: '900', letterSpacing: 2, marginBottom: 6 },
  headerTitle: { color: COLORS.textMain, fontSize: 32, fontWeight: '800', marginBottom: 8 },
  headerText: { color: COLORS.textMuted, fontSize: 14, lineHeight: 22 },
  list: { paddingHorizontal: 24, gap: 16 },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: 28,
    borderWidth: 1,
    borderColor: COLORS.border,
    overflow: 'hidden',
  },
  cardImage: { width: '100%', height: 180 },
  cardBody: { padding: 18 },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6, gap: 12 },
  cardTitle: { flex: 1, color: COLORS.textMain, fontSize: 20, fontWeight: '800' },
  heartButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 69, 58, 0.12)',
  },
  cardMeta: { color: COLORS.textMuted, fontSize: 13, marginTop: 3 },
  footerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 14 },
  price: { color: COLORS.textMain, fontSize: 20, fontWeight: '800' },
  perHr: { color: COLORS.textMuted, fontSize: 13, fontWeight: '500' },
  ratingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(137,233,0,0.1)',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  ratingText: { color: COLORS.kiwi, fontSize: 12, fontWeight: '800' },
  emptyState: {
    marginHorizontal: 24,
    marginTop: 60,
    backgroundColor: COLORS.surface,
    borderRadius: 28,
    borderWidth: 1,
    borderColor: COLORS.border,
    padding: 28,
    alignItems: 'center',
  },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(137,233,0,0.08)',
    marginBottom: 16,
  },
  emptyTitle: { color: COLORS.textMain, fontSize: 20, fontWeight: '800', marginBottom: 8 },
  emptyText: { color: COLORS.textMuted, fontSize: 14, textAlign: 'center', lineHeight: 22, marginBottom: 20 },
  exploreButton: {
    backgroundColor: COLORS.kiwi,
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 14,
  },
  exploreButtonText: { color: '#000', fontSize: 14, fontWeight: '900' },
});
