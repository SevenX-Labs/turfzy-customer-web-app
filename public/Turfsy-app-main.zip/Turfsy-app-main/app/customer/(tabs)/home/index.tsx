import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Dimensions, StatusBar, Platform, RefreshControl, ActivityIndicator, FlatList, InteractionManager } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { router, useFocusEffect } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import * as SplashScreen from 'expo-splash-screen';
import { Turf } from '@/src/types/turf.types';
import { useApp } from '@/src/context/AppContext';
import { UserService } from '@/src/services/userService';
import { HomeService, HomeResponse, TurfCard } from '@/src/services/homeService';
import { GamificationService, OverallGamificationResponse } from '@/src/services/gamificationService';
import { BookingService } from '@/src/services/bookingService';
import { Booking } from '@/src/types/booking.types';
import SkeletonLoader from '@/src/components/SkeletonLoader';
import { getNotificationInbox, NotificationInboxResponse } from '@/src/services/notificationService';


const { width } = Dimensions.get('window');

const CATEGORIES = [
  { name: 'All', icon: 'apps-outline' },
  { name: 'Football', icon: 'football-outline' },
  { name: 'Cricket', icon: 'tennisball-outline' },
  { name: 'Basketball', icon: 'basketball-outline' },
  { name: 'Tennis', icon: 'analytics-outline' },
];

const parseDistance = (distance: string) => Number.parseFloat(distance.replace(/[^\d.]/g, '')) || 0;

// Throttle fetches on focus: prevent continuous re-fetching within 60 seconds
let lastHomeFetchTime = 0;
const FETCH_THROTTLE_MS = 60000;

export default function HomeScreen() {
  const {
    COLORS, userLocation, refreshLocation, userProfile, setUserProfile,
    favoriteTurfIds, bookings, setBookings, homeData: cachedHomeData, setHomeData,
    setIsManualRefreshing, unreadCount, setUnreadCount
  } = useApp();
  const styles = useMemo(() => getStyles(COLORS), [COLORS]);

  const [homeData, setHomeDataLocal] = useState<HomeResponse | null>(cachedHomeData);
  const [gamification, setGamification] = useState<OverallGamificationResponse | null>(null);
  const [activeBookings, setActiveBookings] = useState<Booking[]>([]);
  const [recentNotifications, setRecentNotifications] = useState<NotificationInboxResponse['data']>([]);
  const [loading, setLoading] = useState(!cachedHomeData);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');

  const fetchHomeData = async (isRefreshing = false, forceRefresh = false) => {
    // If not a force/pull refresh, check throttle threshold
    const now = Date.now();
    if (!forceRefresh && !isRefreshing && homeData && (now - lastHomeFetchTime < FETCH_THROTTLE_MS)) {
      if (__DEV__) {
        console.log('[Home] Throttling fetchHomeData to prevent redundant requests');
      }
      return;
    }

    lastHomeFetchTime = now;
    if (!isRefreshing) setLoading(true);
    
    InteractionManager.runAfterInteractions(async () => {
      try {
        // 1. Home Data
        try {
          const homeResponse = await HomeService.getHomeData(userLocation ? {
            lat: userLocation.coords.lat,
            lng: userLocation.coords.lng,
            refresh: forceRefresh,
          } : { refresh: forceRefresh });
          if (homeResponse.success) {
            setHomeDataLocal(homeResponse);
            setHomeData(homeResponse); // Update cache
          }
        } catch (err: any) {
          console.error('[HomeService Error]', err);
        }

        // 2. Gamification
        try {
          const gamificationResponse = await GamificationService.getOverallStats();
          if (gamificationResponse.success) {
            setGamification(gamificationResponse.data);
          }
        } catch (err: any) {
          console.error('[GamificationService Error]', err);
        }

        // 3. Bookings
        try {
          const bookingsResponse = await BookingService.getUserBookings();
          setBookings(bookingsResponse);

          // 3a. Active Bookings for Today
          const activeRes = await BookingService.getActiveBooking();
          if (activeRes.success) {
            setActiveBookings(activeRes.data);
          }
        } catch (err: any) {
          console.error('[BookingService Error]', err);
        }

        // 4. Profile
        try {
          const profileResponse = await UserService.getProfile();
          if (profileResponse.success) {
            setUserProfile(profileResponse.data);
          }
        } catch (err: any) {
          console.error('[UserService Error]', err);
        }

        // 5. Recent Notifications
        try {
          const notifRes = await getNotificationInbox(1, 3);
          if (notifRes.success) {
            let list = notifRes.data;
            let currentCount = notifRes.meta.unreadCount;

            setUnreadCount(currentCount);
            setRecentNotifications(list);
          }
        } catch (err: any) {
          console.error('[Notification Error]', err);
        }
      } catch (globalError: any) {
        console.error('CRITICAL: fetchHomeData failed:', globalError);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    });
  };

  useEffect(() => {
    fetchHomeData(false, false);
  }, [userLocation]); // Re-fetch when location changes

  useFocusEffect(
    useCallback(() => {
      fetchHomeData(false, false); // Throttled silent refresh on focus
    }, [userLocation, homeData])
  );

  const handleRefresh = async () => {
    setRefreshing(true);
    await refreshLocation();
    
    // Sync location to server if available
    if (userLocation) {
      try {
        await UserService.updateLocation(
          userLocation.coords.lat,
          userLocation.coords.lng,
          userLocation.address.city
        );
      } catch (error) {}
    }
    
    await fetchHomeData(true, true);
  };


  const handlePress = (route: string, params?: any) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({ pathname: route as any, params });
  };

  // Sections from real API
  const sections = useMemo(() => {
    if (!homeData) return [];
    
    return homeData.sections.map(section => {
      // Filter by category if needed
      const filteredTurfs = selectedCategory === 'All' 
        ? section.turfs 
        : section.turfs.filter(t => t.sportsType === selectedCategory.toUpperCase());
      
      return {
        ...section,
        turfs: filteredTurfs
      };
    }).filter(s => s.turfs.length > 0);
  }, [homeData, selectedCategory]);

  const topRecommendedSection = sections.find(s => s.sectionType === 'top_recommended');
  const otherSections = sections.filter(s => s.sectionType !== 'top_recommended');

  // Derive display name
  const firstName = userProfile?.name?.split(' ')[0] || 'Player';
  // Derive city name cleanly
  const cityName = userLocation?.address?.city || homeData?.userCity || userProfile?.currentCity || null;
  const locationLine = userLocation?.address?.displayLine1 || null;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      {loading && !refreshing ? (
        <HomeSkeleton COLORS={COLORS} />
      ) : (
        <ScrollView 
          showsVerticalScrollIndicator={false} 
          contentContainerStyle={styles.scrollPadding}
          refreshControl={
            <RefreshControl 
              refreshing={refreshing} 
              onRefresh={handleRefresh} 
              tintColor={COLORS.primary}
              colors={[COLORS.primary]}
            />
          }
        >
          {/* ─── Header ─── */}
          <View style={styles.header}>
            <View style={styles.headerLeft}>
              <View style={styles.greetRow}>
                <Text 
                  style={styles.greetText}
                  numberOfLines={1}
                  adjustsFontSizeToFit
                >
                  Hi, {firstName}
                </Text>
                <Text style={styles.wave}>👋</Text>
              </View>
              {cityName && (
                <TouchableOpacity
                  style={styles.locationChip}
                  activeOpacity={0.7}
                  onPress={() => { Haptics.selectionAsync(); refreshLocation(); }}
                >
                  <Ionicons name="location" size={13} color={COLORS.primary} />
                  <Text style={styles.locationChipText} numberOfLines={1}>{cityName}</Text>
                </TouchableOpacity>
              )}
            </View>
            <View style={styles.headerRight}>
              <TouchableOpacity style={styles.iconBtn} onPress={() => handlePress('/customer/notifications')}>
                <Ionicons name="notifications-outline" size={20} color={COLORS.textMain} />
                {unreadCount > 0 && (
                  <View style={styles.notifBadge}>
                    <Text style={styles.notifBadgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
                  </View>
                )}
              </TouchableOpacity>
              <TouchableOpacity style={styles.iconBtn} onPress={() => handlePress('/customer/liked')}>
                <Ionicons name="heart-outline" size={20} color={COLORS.textMain} />
              </TouchableOpacity>
            </View>
          </View>

          {/* ─── Stats Row ─── */}
          <View style={styles.statsCard}>
            <View style={styles.statsBox}>
              <Text style={styles.statsNum} numberOfLines={1} adjustsFontSizeToFit>
                {bookings.filter(b => (b.bookingStatus || b.status)?.toUpperCase() === 'CONFIRMED' || (b.bookingStatus || b.status)?.toUpperCase() === 'UPCOMING' || (b.bookingStatus || b.status)?.toUpperCase() === 'PENDING').length}
              </Text>
              <Text style={styles.statsLabel} numberOfLines={1} adjustsFontSizeToFit>Upcoming</Text>
            </View>
            <View style={styles.statsSep} />
            <View style={styles.statsBox}>
              <Text style={styles.statsNum} numberOfLines={1} adjustsFontSizeToFit>{favoriteTurfIds.length}</Text>
              <Text style={styles.statsLabel} numberOfLines={1} adjustsFontSizeToFit>Saved</Text>
            </View>
            <View style={styles.statsSep} />
            <View style={styles.statsBox}>
              <Text style={styles.statsNum} numberOfLines={1} adjustsFontSizeToFit>{gamification?.totalMatches ?? 0}</Text>
              <Text style={styles.statsLabel} numberOfLines={1} adjustsFontSizeToFit>Played</Text>
            </View>
            <View style={styles.statsSep} />
            <View style={styles.statsBox}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={styles.statsNum} numberOfLines={1} adjustsFontSizeToFit>{gamification?.streak ?? 0}</Text>
                <Ionicons name="flame" size={14} color={COLORS.kiwi} style={{ marginLeft: 2 }} />
              </View>
              <Text style={styles.statsLabel}>Streak</Text>
            </View>
          </View>

          {/* ─── Category Filter ─── */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catScroll}>
            {CATEGORIES.map((cat) => {
              const isActive = selectedCategory === cat.name;
              return (
                <TouchableOpacity
                  key={cat.name}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setSelectedCategory(cat.name);
                  }}
                  style={[styles.catPill, isActive && styles.catPillActive]}
                >
                  <Ionicons name={cat.icon as any} size={15} color={isActive ? COLORS.night : COLORS.textMuted} style={{ marginRight: 6 }} />
                  <Text style={[styles.catText, isActive && styles.catTextActive]}>{cat.name}</Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {/* ─── Active Match / Missed Action ─── */}
          {activeBookings.length > 0 && (() => {
            const relevant = activeBookings.sort((a, b) => {
              const sA = (a.bookingStatus || a.status || '').toUpperCase();
              const sB = (b.bookingStatus || b.status || '').toUpperCase();
              if (sA === 'CONFIRMED' && sB !== 'CONFIRMED') return -1;
              if (sB === 'CONFIRMED' && sA !== 'CONFIRMED') return 1;
              return 0;
            }).find(b => {
              const s = (b.bookingStatus || b.status || '').toUpperCase();
              return s === 'CONFIRMED' || s === 'UPCOMING' || s === 'NO_SHOW';
            });
            if (!relevant) return null;
            return <ActiveBookingCard booking={relevant} />;
          })()}

          {/* ─── Hero Card ─── */}
          {topRecommendedSection && topRecommendedSection.turfs[0] && (
            <HeroTurf turf={topRecommendedSection.turfs[0]} />
          )}

          {/* ─── Turf Sections ─── */}
          {otherSections.map((section) => (
            <HomeSection
              key={section.sectionType}
              title={section.title}
              subtitle={section.subtitle || ''}
              turfs={section.turfs}
              badgeMode={getBadgeMode(section.sectionType)}
            />
          ))}

          {/* ─── Quick Actions ─── */}
          <QuickActions />

          {/* ─── Recent Notifications ─── */}
          <RecentNotifications notifications={recentNotifications} />
        </ScrollView>
      )}
    </View>
  );
}

const HeroTurf = React.memo(({ turf }: { turf: TurfCard }) => {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);
  const mainImage = turf.images?.[0];
  const distanceStr = turf.distanceKm ? `${turf.distanceKm} km` : 'Near you';

  return (
    <TouchableOpacity
      style={styles.heroCard}
      activeOpacity={0.9}
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        router.push({ pathname: '/customer/booking/detail', params: { id: turf.id } });
      }}
    >
      <Image source={{ uri: mainImage }} style={[styles.heroImage, turf.status !== 'ACTIVE' && { opacity: 0.6 }]} />
      <LinearGradient colors={['transparent', 'rgba(0,0,0,0.85)']} style={styles.heroGradient} />
      <View style={styles.heroContent}>
        <View style={[styles.heroBadge, turf.status !== 'ACTIVE' && { backgroundColor: 'rgba(255, 149, 0, 0.8)', borderColor: '#FF9500' }]}>
          <Text style={[styles.heroBadgeText, turf.status !== 'ACTIVE' && { color: '#fff' }]}>
            {turf.status !== 'ACTIVE' ? turf.status.replace('_', ' ') : 'TOP RECOMMENDED'}
          </Text>
        </View>
        <Text style={styles.heroTitle} numberOfLines={2} adjustsFontSizeToFit>{turf.name}</Text>

        <View style={styles.heroMeta}>
          <Ionicons name="location" size={14} color={COLORS.primary} />
          <Text style={styles.heroMetaText}>{turf.city} • {distanceStr}</Text>
        </View>
        <View style={styles.heroFooter}>
          <Text style={styles.heroPrice}>₹{turf.weekdayDayPrice}<Text style={{ fontSize: 14, fontWeight: '500' }}> /hr</Text></Text>
          <View style={styles.heroBtn}>
            <Text style={styles.heroBtnText}>BOOK NOW</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
});

const ActiveBookingCard = React.memo(({ booking }: { booking: Booking }) => {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);
  const turf = booking.turf;
  const status = (booking.bookingStatus || booking.status || '').toUpperCase();
  const isNoShow = status === 'NO_SHOW';

  return (
    <View style={styles.activeSection}>
      <Text style={[styles.activeLabel, isNoShow && { color: '#FF453A' }]}>
        {isNoShow ? 'MISSED SESSION' : 'UPCOMING TODAY'}
      </Text>
      <TouchableOpacity
        style={[styles.activeCard, isNoShow && { opacity: 0.9 }]}
        activeOpacity={0.9}
        onPress={() => router.push({ pathname: '/customer/booking/confirm', params: { code: booking.displayId, id: booking.id } })}
      >
        <LinearGradient
          colors={isNoShow ? ['#FF453A', '#C0392B'] : ['#7ED321', '#5A9E00']}
          style={styles.activeGradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={styles.activeContent}>
            <View style={styles.activeTextGroup}>
              <Text style={styles.activeTurfName} numberOfLines={1}>{turf?.name || 'Your Match'}</Text>
              <View style={styles.activeTimeRow}>
                <Ionicons name={isNoShow ? "alert-circle" : "time"} size={14} color="#000" />
                <Text style={styles.activeTimeText}>
                  {isNoShow ? `Expired at ${booking.endTime}` : `${booking.startTime} - ${booking.endTime}`}
                </Text>
              </View>
            </View>
            <View style={styles.activeCodeGroup}>
              <Text style={styles.activeIdLabel}>ID</Text>
              <Text style={styles.activeIdValue}>#{booking.displayId.split('-')[1] || booking.displayId}</Text>
            </View>
          </View>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );
});

const QuickActions = React.memo(() => {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);
  const ACTIONS = [
    { label: 'Book Now', icon: 'football-outline', route: '/customer/explore', color: COLORS.kiwi },
    { label: 'My Games', icon: 'calendar-outline', route: '/customer/bookings', color: '#5B9EF5' },
    { label: 'Rankings', icon: 'trophy-outline', route: '/customer/leaderboard', color: '#F6C453' },
    { label: 'Saved', icon: 'heart-outline', route: '/customer/liked', color: '#FF6B8A' },
  ];

  return (
    <View style={styles.qaSection}>
      <Text style={styles.qaSectionTitle}>Quick Actions</Text>
      <View style={styles.qaGrid}>
        {ACTIONS.map((a, i) => (
          <TouchableOpacity key={i} style={styles.qaItem} activeOpacity={0.8} onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            router.push(a.route as any);
          }}>
            <View style={[styles.qaIcon, { backgroundColor: `${a.color}12` }]}>
              <Ionicons name={a.icon as any} size={24} color={a.color} />
            </View>
            <Text 
              style={styles.qaLabel} 
              numberOfLines={1} 
              adjustsFontSizeToFit
            >
              {a.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
});

const RecentNotifications = React.memo(({ notifications }: { notifications: any[] }) => {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);
  
  if (!notifications || notifications.length === 0) return null;

  const getIconForType = (type: string) => {
    switch (type) {
      case 'BOOKING_CONFIRMED': return 'checkmark-circle-outline';
      case 'PAYMENT_PARTIAL': return 'cash-outline';
      case 'PAYMENT_FULL': return 'cash';
      case 'NO_SHOW': return 'alert-circle-outline';
      case 'SPLIT_ADDED': return 'people-outline';
      case 'GAME_COMPLETED': return 'trophy-outline';
      case 'PAYMENT_NUDGE': return 'alert-circle';
      default: return 'notifications-outline';
    }
  };

  const handleNotifPress = (item: any) => {
    if (item.type === 'PAYMENT_NUDGE') {
      router.push('/customer/profile/payment');
      return;
    }
    router.push('/customer/notifications');
  };

  return (
    <View style={styles.recentNotifSection}>
      <View style={styles.sectionHeader}>
        <View style={styles.sectionTitleWrap}>
          <Text style={styles.sectionTitle}>Recent Updates</Text>
        </View>
        <TouchableOpacity onPress={() => router.push('/customer/notifications')}>
          <Text style={styles.seeAll}>See all</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.recentNotifList}>
        {notifications.map((item) => (
          <TouchableOpacity 
            key={item.id} 
            style={[
              styles.notifCard, 
              !item.isRead && styles.unreadNotifCard, 
              item.type === 'PAYMENT_NUDGE' && styles.nudgeNotifCard
            ]}
            activeOpacity={0.8}
            onPress={() => handleNotifPress(item)}
          >
            <View style={[
              styles.notifIconWrap, 
              !item.isRead && styles.unreadNotifIconWrap, 
              item.type === 'PAYMENT_NUDGE' && styles.nudgeNotifIconWrap
            ]}>
              <Ionicons 
                name={getIconForType(item.type)} 
                size={16} 
                color={(!item.isRead || item.type === 'PAYMENT_NUDGE') ? COLORS.night : COLORS.textMain} 
              />
            </View>
            <View style={styles.notifContent}>
              <Text 
                style={[styles.notifTitle, !item.isRead && styles.unreadNotifText]} 
                numberOfLines={1}
              >
                {item.title}
              </Text>
              <Text style={styles.notifMessage} numberOfLines={2}>{item.body}</Text>
              <View style={styles.notifFooter}>
                <Ionicons name="time-outline" size={10} color={COLORS.textMuted} />
                <Text style={styles.notifTime}>{new Date(item.createdAt).toLocaleDateString()}</Text>
                {!item.isRead && item.type !== 'PAYMENT_NUDGE' && (
                  <View style={styles.statusTag}>
                    <Text style={styles.statusTagText}>NEW</Text>
                  </View>
                )}
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
});

const TurfItem = React.memo(({ turf, badgeMode, COLORS, styles }: any) => {
  const onPress = useCallback(() => {
    router.push({ pathname: '/customer/booking/detail', params: { id: turf.id } });
  }, [turf.id]);

  return (
    <TouchableOpacity
      style={[styles.turfCard, { width: width * 0.72 }]}
      activeOpacity={0.9}
      onPress={onPress}
    >
      <Image 
        source={{ uri: turf.images?.[0] }} 
        style={[styles.cardImage, turf.status !== 'ACTIVE' && { opacity: 0.6 }]} 
      />

      <View style={styles.cardBody}>
        <View style={styles.cardTopRow}>
          <View style={[styles.badge, turf.status !== 'ACTIVE' && { backgroundColor: 'rgba(255, 149, 0, 0.1)', borderColor: 'rgba(255, 149, 0, 0.3)' }]}>
            <Text style={[styles.badgeText, turf.status !== 'ACTIVE' && { color: '#FF9500' }]}>{getBadgeText(turf, badgeMode)}</Text>
          </View>
          <View style={styles.ratingBox}>
            <Ionicons name="star" size={11} color={COLORS.primary} />
            <Text style={styles.ratingVal}>{Number(turf.rating || 0).toFixed(1)}</Text>
          </View>
        </View>

        <Text style={styles.cardTitle} numberOfLines={1} adjustsFontSizeToFit>{turf.name}</Text>

        <Text style={styles.cardLocation} numberOfLines={1}>{turf.address}</Text>

        <View style={styles.metaRow}>
          <Text style={styles.metaText}>{turf.sportsType}</Text>
          <Text style={styles.metaDot}>•</Text>
          <Text style={styles.metaText}>{turf.distanceKm ? `${turf.distanceKm} km` : 'Nearby'}</Text>
        </View>

        <View style={styles.cardFooter}>
          <Text style={styles.priceText}>
            ₹{turf.weekdayDayPrice.toLocaleString()}
            <Text style={styles.perHr}>/hr</Text>
          </Text>
          <TouchableOpacity
            style={styles.bookBtn}
            onPress={onPress}
          >
            <Text style={styles.bookBtnText}>BOOK</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
});

const HomeSection = React.memo(({
  title,
  subtitle,
  turfs,
  badgeMode,
}: {
  title: string;
  subtitle: string;
  turfs: TurfCard[];
  badgeMode: 'budget' | 'rating' | 'availability' | 'recommended' | 'nearby' | 'demanded' | 'new';
}) => {
  const { COLORS } = useApp();
  const styles = useMemo(() => getStyles(COLORS), [COLORS]);

  const renderItem = useCallback(({ item }: { item: TurfCard }) => (
    <TurfItem turf={item} badgeMode={badgeMode} COLORS={COLORS} styles={styles} />
  ), [badgeMode, COLORS, styles]);

  const keyExtractor = useCallback((item: TurfCard) => `${title}-${item.id}`, [title]);

  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <View style={styles.sectionTitleWrap}>
          <Text style={styles.sectionTitle}>{title}</Text>
          {subtitle ? <Text style={styles.sectionSubtitle}>{subtitle}</Text> : null}
        </View>
        <TouchableOpacity onPress={() => router.push('/customer/explore')}>
          <Text style={styles.seeAll}>See all</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        decelerationRate="fast"
        snapToInterval={width * 0.72 + 14}
        contentContainerStyle={styles.sectionScroll}
        data={turfs}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        initialNumToRender={4}
        maxToRenderPerBatch={4}
        windowSize={5}
        removeClippedSubviews={true}
        getItemLayout={(data, index) => (
          { length: width * 0.72 + 14, offset: (width * 0.72 + 14) * index, index }
        )}
      />
    </View>
  );
});

function getBadgeText(turf: TurfCard, mode: any) {
  if (turf.status !== 'ACTIVE') return turf.status.replace('_', ' ');
  if (mode === 'budget') return 'BEST VALUE';
  if (mode === 'recommended') return 'TOP CHOICE';
  if (mode === 'nearby') return 'NEARBY';
  if (mode === 'demanded') return 'MOST POPULAR';
  if (mode === 'new') return 'NEW ARRIVAL';
  if (mode === 'rating') return `${turf.reviewCount || 0}+ REVIEWS`;
  return turf.status.toUpperCase();
}

function getBadgeMode(sectionType: string): any {
  switch (sectionType) {
    case 'budget_friendly': return 'budget';
    case 'top_recommended': return 'recommended';
    case 'most_rated': return 'rating';
    case 'nearby': return 'nearby';
    case 'most_demanded': return 'demanded';
    case 'newly_opened': return 'new';
    default: return 'availability';
  }
}

const HomeSkeleton = ({ COLORS }: { COLORS: any }) => {
  const styles = getStyles(COLORS);
  return (
    <View style={[styles.container, { backgroundColor: COLORS.night }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollPadding}>
        <View style={[styles.header, { marginTop: Platform.OS === 'ios' ? 56 : 46 }]}>
          <View style={styles.headerLeft}>
            <SkeletonLoader width={120} height={28} borderRadius={8} style={{ marginBottom: 8 }} />
            <SkeletonLoader width={80} height={20} borderRadius={10} />
          </View>
          <View style={styles.headerRight}>
            <SkeletonLoader width={42} height={42} borderRadius={14} />
            <SkeletonLoader width={42} height={42} borderRadius={14} style={{ marginLeft: 8 }} />
          </View>
        </View>

        <View style={[styles.statsCard, { paddingVertical: 20 }]}>
          <View style={{ flex: 1, alignItems: 'center' }}><SkeletonLoader width={40} height={25} style={{ marginBottom: 4 }} /><SkeletonLoader width={50} height={10} /></View>
          <View style={{ flex: 1, alignItems: 'center' }}><SkeletonLoader width={40} height={25} style={{ marginBottom: 4 }} /><SkeletonLoader width={50} height={10} /></View>
          <View style={{ flex: 1, alignItems: 'center' }}><SkeletonLoader width={40} height={25} style={{ marginBottom: 4 }} /><SkeletonLoader width={50} height={10} /></View>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingLeft: 20, marginBottom: 20 }}>
          {[1, 2, 3, 4].map(i => (
            <SkeletonLoader key={i} width={100} height={40} borderRadius={12} style={{ marginRight: 8 }} />
          ))}
        </ScrollView>

        <View style={{ marginHorizontal: 20, marginBottom: 20 }}>
          <SkeletonLoader width={150} height={15} style={{ marginBottom: 12 }} />
          <SkeletonLoader width="100%" height={250} borderRadius={24} />
        </View>

        {[1, 2].map(s => (
          <View key={s} style={{ marginTop: 24, paddingLeft: 20 }}>
            <SkeletonLoader width={180} height={20} style={{ marginBottom: 16 }} />
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {[1, 2, 3].map(i => (
                <SkeletonLoader key={i} width={width * 0.72} height={240} borderRadius={20} style={{ marginRight: 14 }} />
              ))}
            </ScrollView>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const getStyles = (COLORS: any) => {

  const sm = width < 380;
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: COLORS.night },
    scrollPadding: { paddingBottom: 120 },

    activeSection: { marginHorizontal: 20, marginTop: 10, marginBottom: 10 },
    activeLabel: { color: COLORS.kiwi, fontSize: 10, fontWeight: '900', letterSpacing: 2, marginBottom: 10 },
    activeCard: { borderRadius: 20, overflow: 'hidden', height: 85 },
    activeGradient: { flex: 1, padding: 18 },
    activeContent: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    activeTextGroup: { flex: 1 },
    activeTurfName: { color: '#000', fontSize: 20, fontWeight: '900', letterSpacing: -0.5 },
    activeTimeRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
    activeTimeText: { color: '#000', fontSize: 14, fontWeight: '700' },
    activeCodeGroup: { alignItems: 'flex-end', backgroundColor: 'rgba(0,0,0,0.08)', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12 },
    activeIdLabel: { color: 'rgba(0,0,0,0.5)', fontSize: 9, fontWeight: '800' },
    activeIdValue: { color: '#000', fontSize: 16, fontWeight: '900' },
    loaderContainer: {
      ...StyleSheet.absoluteFillObject,
      backgroundColor: 'rgba(0,0,0,0.5)',
      zIndex: 999,
      justifyContent: 'center',
      alignItems: 'center',
    },

    // ─── Header ───
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      paddingHorizontal: 20,
      marginTop: Platform.OS === 'ios' ? 56 : 46,
      marginBottom: 20,
    },
    headerLeft: {
      flex: 1,
      marginRight: 12,
    },
    greetRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      marginBottom: 6,
    },
    greetText: {
      color: COLORS.textMain,
      fontSize: sm ? 22 : 26,
      fontWeight: '800',
      letterSpacing: -0.5,
    },
    wave: {
      fontSize: sm ? 20 : 24,
    },
    locationChip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
      alignSelf: 'flex-start',
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 20,
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
    },
    locationChipText: {
      color: COLORS.textMuted,
      fontSize: 12,
      fontWeight: '600',
      maxWidth: 140,
    },
    headerRight: {
      flexDirection: 'row',
      gap: 8,
      marginTop: 2,
    },
    iconBtn: {
      width: 42,
      height: 42,
      borderRadius: 14,
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
      alignItems: 'center',
      justifyContent: 'center',
    },
    notifBadge: {
      position: 'absolute',
      top: -5,
      right: -5,
      minWidth: 18,
      height: 18,
      borderRadius: 9,
      backgroundColor: COLORS.kiwi,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 4,
      borderWidth: 1.5,
      borderColor: COLORS.surface,
    },
    notifBadgeText: {
      color: COLORS.night,
      fontSize: 9,
      fontWeight: '900',
    },

    // ─── Stats ───
    statsCard: {
      flexDirection: 'row',
      marginHorizontal: 20,
      paddingVertical: 14,
      paddingHorizontal: 4,
      borderRadius: 20,
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
      marginBottom: 20,
    },
    statsBox: {
      flex: 1,
      alignItems: 'center',
    },
    statsNum: {
      color: COLORS.textMain,
      fontSize: sm ? 18 : 20,
      fontWeight: '900',
    },
    statsLabel: {
      color: COLORS.textMuted,
      fontSize: sm ? 9 : 10,
      fontWeight: '700',
      marginTop: 3,
      textTransform: 'uppercase',
      letterSpacing: 0.5,
    },
    statsSep: {
      width: 1,
      height: 30,
      backgroundColor: COLORS.border,
    },

    // ─── Categories ───
    catScroll: { paddingLeft: 20, paddingRight: 10, marginBottom: 6 },
    catPill: {
      paddingHorizontal: sm ? 14 : 18,
      paddingVertical: 10,
      borderRadius: 12,
      backgroundColor: COLORS.surface,
      marginRight: 8,
      borderWidth: 1,
      borderColor: COLORS.border,
      flexDirection: 'row',
      alignItems: 'center',
    },
    catPillActive: { backgroundColor: COLORS.kiwi, borderColor: COLORS.kiwi },
    catText: { color: COLORS.textMuted, fontWeight: '700', fontSize: sm ? 12 : 13 },
    catTextActive: { color: COLORS.night },

    // ─── Sections ───
    section: { marginTop: 24 },
    sectionHeader: {
      paddingHorizontal: 20,
      marginBottom: 14,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 12,
    },
    sectionTitleWrap: { flex: 1 },
    sectionTitle: { color: COLORS.textMain, fontSize: sm ? 20 : 22, fontWeight: '800', letterSpacing: -0.3 },
    sectionSubtitle: { color: COLORS.textMuted, fontSize: 12, marginTop: 3, lineHeight: 17 },
    seeAll: { color: COLORS.kiwi, fontWeight: '700', fontSize: 13 },
    sectionScroll: { paddingLeft: 20, paddingRight: 6 },

    // ─── Turf Card ───
    turfCard: {
      marginRight: 14,
      backgroundColor: COLORS.surface,
      borderRadius: 20,
      overflow: 'hidden',
      borderWidth: 1,
      borderColor: COLORS.border,
    },
    cardImage: { width: '100%', height: 130 },
    cardBody: { padding: 12 },
    cardTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
    badge: {
      backgroundColor: 'rgba(137,233,0,0.12)',
      borderWidth: 1,
      borderColor: 'rgba(137,233,0,0.2)',
      borderRadius: 8,
      paddingHorizontal: 8,
      paddingVertical: 4,
    },
    badgeText: { color: COLORS.kiwi, fontSize: 9, fontWeight: '900', letterSpacing: 0.5 },
    ratingBox: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: COLORS.surfaceSoft || 'rgba(0,0,0,0.05)',
      paddingHorizontal: 7,
      paddingVertical: 4,
      borderRadius: 8,
      gap: 3,
    },
    ratingVal: { color: COLORS.textMain, fontSize: 11, fontWeight: '800' },
    cardTitle: { color: COLORS.textMain, fontSize: sm ? 15 : 16, fontWeight: '800', marginBottom: 3 },
    cardLocation: { color: COLORS.textMuted, fontSize: 11, marginBottom: 6 },
    metaRow: { flexDirection: 'row', alignItems: 'center' },
    metaText: { color: COLORS.textMuted, fontSize: 11 },
    metaDot: { color: COLORS.textMuted, marginHorizontal: 5, fontSize: 11 },
    cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 },
    priceText: { color: COLORS.textMain, fontSize: sm ? 16 : 17, fontWeight: '800' },
    perHr: { color: COLORS.textMuted, fontSize: 11, fontWeight: '500' },
    bookBtn: {
      backgroundColor: COLORS.kiwi,
      paddingHorizontal: 14,
      paddingVertical: 8,
      borderRadius: 10,
    },
    bookBtnText: { color: COLORS.night, fontWeight: '900', fontSize: 12 },

    // ─── Hero ───
    heroCard: {
      marginHorizontal: 20,
      height: sm ? 220 : 250,
      borderRadius: 24,
      overflow: 'hidden',
      marginTop: 10,
      borderWidth: 1,
      borderColor: COLORS.border,
    },
    heroImage: { width: '100%', height: '100%' },
    heroGradient: { ...StyleSheet.absoluteFillObject },
    heroContent: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20 },
    heroBadge: {
      backgroundColor: COLORS.kiwi,
      alignSelf: 'flex-start',
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 8,
      marginBottom: 10,
    },
    heroBadgeText: { color: '#000', fontSize: 9, fontWeight: '900', letterSpacing: 1 },
    heroTitle: { color: '#FFF', fontSize: sm ? 22 : 26, fontWeight: '800', marginBottom: 6 },
    heroMeta: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 14 },
    heroMetaText: { color: 'rgba(255,255,255,0.7)', fontSize: 13, fontWeight: '500' },
    heroFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    heroPrice: { color: '#FFF', fontSize: sm ? 20 : 22, fontWeight: '800' },
    heroBtn: { backgroundColor: '#FFF', paddingHorizontal: 18, paddingVertical: 10, borderRadius: 12 },
    heroBtnText: { color: '#000', fontWeight: '900', fontSize: 12 },

    // ─── Quick Actions ───
    qaSection: { paddingHorizontal: 20, marginTop: 28, marginBottom: 8 },
    qaSectionTitle: { color: COLORS.textMain, fontSize: sm ? 20 : 22, fontWeight: '800', letterSpacing: -0.3, marginBottom: 14 },
    qaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'space-between' },
    qaItem: {
      width: (width - 50) / 2,
      height: (width - 50) / 3.5,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: COLORS.surface,
      borderWidth: 1,
      borderColor: COLORS.border,
      borderRadius: 18,
      padding: 8,
    },
    qaIcon: {
      width: 44,
      height: 44,
      borderRadius: 12,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 6,
    },
    qaLabel: {
      color: COLORS.textMain,
      fontSize: sm ? 11 : 13,
      fontWeight: '700',
      textAlign: 'center',
      width: '100%',
    },

    // ─── Recent Notifications ───
    recentNotifSection: { marginTop: 20, marginBottom: 20 },
    recentNotifList: { paddingHorizontal: 20, gap: 10 },
    notifCard: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: COLORS.surface,
      borderRadius: 18,
      padding: 14,
      marginBottom: 10,
      borderWidth: 1,
      borderColor: COLORS.border,
      gap: 12,
    },
    unreadNotifCard: {
      backgroundColor: COLORS.isDark ? 'rgba(137,233,0,0.03)' : 'rgba(137,233,0,0.05)',
      borderColor: 'rgba(137,233,0,0.2)',
    },
    nudgeNotifCard: {
      backgroundColor: 'rgba(137,233,0,0.06)',
      borderColor: COLORS.kiwi,
      borderWidth: 1.5,
    },
    notifIconWrap: {
      width: 40,
      height: 40,
      borderRadius: 12,
      backgroundColor: COLORS.isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    unreadNotifIconWrap: {
      backgroundColor: COLORS.kiwi,
    },
    nudgeNotifIconWrap: {
      backgroundColor: COLORS.kiwi,
    },
    notifContent: { flex: 1 },
    notifTitle: { color: COLORS.textMain, fontSize: 14, fontWeight: '800', marginBottom: 2 },
    notifFooter: { flexDirection: 'row', alignItems: 'center', marginTop: 8, gap: 4 },
    notifTime: { color: COLORS.textMuted, fontSize: 9, fontWeight: '700', textTransform: 'uppercase' },
    statusTag: { backgroundColor: COLORS.kiwi, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, marginLeft: 'auto' },
    statusTagText: { color: COLORS.night, fontSize: 8, fontWeight: '900' },
    unreadNotifText: { color: COLORS.textMain },
    notifMessage: { color: COLORS.textMuted, fontSize: 11, lineHeight: 16, opacity: 0.8 },

  });
};
