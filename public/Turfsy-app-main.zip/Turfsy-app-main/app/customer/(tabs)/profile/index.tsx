import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Image, Platform, Alert, StatusBar, useWindowDimensions, Modal, InteractionManager, Clipboard } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { BlurView } from 'expo-blur';
import * as Haptics from 'expo-haptics';
import { Animated } from 'react-native';
import { useApp } from '@/src/context/AppContext';

import { UserService } from '@/src/services/userService';


const FALLBACK = '';

export default function ProfileScreen() {
  const { width: W } = useWindowDimensions();
  const { bookings, COLORS, theme, setTheme, userProfile, setUserProfile, userInfo, setAuthToken, setUserInfo, setRole } = useApp();
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  useEffect(() => {
    if (!userProfile) {
      InteractionManager.runAfterInteractions(() => {
        UserService.getProfile().then(r => { if (r.success) setUserProfile(r.data); }).catch(() => {});
      });
    }
  }, []);

  const getImg = useCallback((url?: string | null) => {
    if (!url) return null;
    if (url.startsWith('http') || url.startsWith('file') || url.startsWith('data')) return url;
    return `https://turfsy.onrender.com${url.startsWith('/') ? '' : '/'}${url}`;
  }, []);

  const stats = useMemo(() => {
    const totalGames = bookings.length;
    const uniqueVenues = new Set(bookings.map(b => b.turfName)).size;
    const totalSpend = bookings.reduce((s, b) => s + (b.totalAmount || 0), 0);

    // Gamification: level based on bookings
    const level = Math.max(1, Math.floor(totalGames / 3) + 1);
    const levelNames = ['Rookie', 'Amateur', 'Regular', 'Sportsman', 'Pro Player', 'Legend'];
    const levelName = levelNames[Math.min(level - 1, levelNames.length - 1)];
    const progressToNext = totalGames > 0 ? (totalGames % 3) / 3 : 0;
    const bookingsToNext = 3 - (totalGames % 3);

    return { totalGames, uniqueVenues, totalSpend, level, levelName, progressToNext, bookingsToNext };
  }, [bookings]);

  const { totalGames, uniqueVenues, totalSpend, level, levelName, progressToNext, bookingsToNext } = stats;

  const logout = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setShowLogoutModal(true);
  }, []);

  const confirmLogout = useCallback(() => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowLogoutModal(false);
    setTimeout(() => {
      setAuthToken(null);
      setUserInfo(null);
      setRole(null);
      setUserProfile(null);
    }, 300);
  }, []);

  const memberSinceDate = useMemo(() => {
    if (!userProfile?.createdAt) return 'July 2024';
    try {
      const date = new Date(userProfile.createdAt);
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return `${months[date.getMonth()]} ${date.getFullYear()}`;
    } catch {
      return 'July 2024';
    }
  }, [userProfile?.createdAt]);

  const handleCopyPhone = useCallback(() => {
    if (userInfo?.phone) {
      Clipboard.setString(userInfo.phone);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Success', 'Phone number copied to clipboard!');
    }
  }, [userInfo?.phone]);

  // Stat bar fill (max 100% at 20 bookings / 10 venues / ₹50k)
  const bFill = Math.min(1, totalGames / 20);
  const vFill = Math.min(1, uniqueVenues / 10);
  const sFill = Math.min(1, totalSpend / 50000);

  const BAR_W = W - 40 - 20 - 70; // section padding + card padding + label col

  // Quick action cells: 3 per row, 2 rows = 6
  const cellW = Math.floor((W - 40 - 20) / 3); // 2 gaps of 10

  return (
    <View style={[S.root, { backgroundColor: COLORS.background }]}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 140 }}>

        {/* ── HERO ───────────────────────────────────── */}
        <LinearGradient
          colors={['rgba(137,233,0,0.18)', 'rgba(137,233,0,0.04)', 'transparent']}
          style={[S.hero, { paddingTop: Platform.OS === 'ios' ? 64 : (StatusBar.currentHeight || 0) + 16 }]}
        >
          <View style={S.heroBar}>
            <Text style={[S.heroLabel, { color: COLORS.textMuted }]}>MY PROFILE</Text>
          </View>

          <View style={[S.profileCard, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            {/* Avatar Section */}
            <View style={S.avatarSection}>
              {/* Outer dotted/dashed circle */}
              <View style={[S.outerRing, { borderColor: COLORS.kiwi + '50' }]}>
                {/* Middle ring */}
                <View style={[S.middleRing, { borderColor: COLORS.kiwi }]}>
                  {/* Avatar wrapper */}
                  <View style={S.avatarContainer}>
                    {userProfile?.avatarUrl ? (
                      <Image source={{ uri: getImg(userProfile?.avatarUrl)! }} style={S.avatarImage} />
                    ) : (
                      <View style={[S.avatarImage, { backgroundColor: COLORS.background, justifyContent: 'center', alignItems: 'center' }]}>
                        <Ionicons name="person" size={38} color={COLORS.textMuted} />
                      </View>
                    )}
                  </View>
                </View>
              </View>
              {/* Camera edit button */}
              <TouchableOpacity
                style={[S.cameraButton, { backgroundColor: COLORS.kiwi, borderColor: COLORS.background }]}
                onPress={() => router.push('/customer/profile/edit')}
                activeOpacity={0.8}
              >
                <Ionicons name="camera" size={14} color="#000" />
              </TouchableOpacity>
            </View>

            {/* Profile details */}
            <View style={S.detailsSection}>
              {/* Name & Edit button row */}
              <View style={S.nameRow}>
                <Text style={[S.profileName, { color: COLORS.textMain }]} numberOfLines={2}>
                  {userProfile?.name || 'Player'}
                </Text>
                <TouchableOpacity 
                  onPress={() => router.push('/customer/profile/edit')} 
                  activeOpacity={0.7}
                  style={S.editPencilBtn}
                >
                  <Ionicons name="pencil" size={16} color={COLORS.kiwi} style={{ opacity: 0.8 }} />
                </TouchableOpacity>
              </View>

              {/* Username */}
              {userProfile?.username && (
                <Text style={[S.profileUsername, { color: COLORS.kiwi }]}>
                  @{userProfile.username}
                </Text>
              )}

              {/* Info Container (Phone & Member since) */}
              <View style={S.infoContainer}>
                {/* Phone pill */}
                <View style={[S.infoPill, { backgroundColor: COLORS.isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)', borderColor: COLORS.border }]}>
                  <View style={S.infoPillLeft}>
                    <Ionicons name="call-outline" size={16} color={COLORS.kiwi} />
                    <Text style={[S.infoPillText, { color: COLORS.textMain }]}>
                      +91 {userInfo?.phone ? `${userInfo.phone.slice(0, 4)}••••${userInfo.phone.slice(-3)}` : 'XXXXXXXXXX'}
                    </Text>
                  </View>
                  {userInfo?.phone ? (
                    <TouchableOpacity onPress={handleCopyPhone} style={S.copyBtn} activeOpacity={0.7}>
                      <Ionicons name="copy-outline" size={16} color={COLORS.kiwi} />
                    </TouchableOpacity>
                  ) : null}
                </View>

                {/* Member since pill */}
                <View style={[S.infoPill, { backgroundColor: COLORS.isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)', borderColor: COLORS.border }]}>
                  <View style={S.infoPillLeft}>
                    <Ionicons name="calendar-outline" size={16} color={COLORS.kiwi} />
                    <Text style={[S.infoPillText, { color: COLORS.textMain }]}>
                      Member since {memberSinceDate}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </LinearGradient>

        {/* ── ACTIVITY STATS ─────────────────────────── */}
        <View style={S.sectionPad}>
          <View style={[S.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            <View style={S.cardHeader}>
              <Ionicons name="stats-chart-outline" size={16} color={COLORS.kiwi} />
              <Text style={[S.cardTitle, { color: COLORS.textMain }]}>Activity</Text>
              <View style={[S.chip, { backgroundColor: COLORS.kiwi + '18' }]}>
                <Text style={[S.chipText, { color: COLORS.kiwi }]}>All Time</Text>
              </View>
            </View>

            {/* Bookings */}
            <StatBar
              label="Bookings"
              value={`${totalGames}`}
              fill={bFill}
              sub={totalGames === 0 ? 'No bookings yet' : `${totalGames} total booked`}
              barW={BAR_W}
              COLORS={COLORS}
            />
            {/* Venues */}
            <StatBar
              label="Venues"
              value={`${uniqueVenues}`}
              fill={vFill}
              sub={uniqueVenues === 0 ? 'No venues visited' : `${uniqueVenues} unique venues`}
              barW={BAR_W}
              COLORS={COLORS}
            />
            {/* Spent */}
            <StatBar
              label="Spent"
              value={`₹${totalSpend >= 1000 ? (totalSpend / 1000).toFixed(1) + 'k' : totalSpend}`}
              fill={sFill}
              sub={totalSpend === 0 ? 'No spending recorded' : `₹${(totalSpend / 1000).toFixed(1)}k total`}
              barW={BAR_W}
              COLORS={COLORS}
              isLast
            />
          </View>
        </View>

        {/* ── LEVEL / GAMIFICATION ────────────────────── */}
        <View style={S.sectionPad}>
          <View style={[S.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            <View style={S.levelHeader}>
              <View style={[S.levelBadgeBox, { backgroundColor: COLORS.kiwi }]}>
                <MaterialCommunityIcons name="trophy-outline" size={18} color="#000" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[S.levelName, { color: COLORS.textMain }]}>Level {level} — {levelName}</Text>
                <Text style={[S.levelSub, { color: COLORS.textMuted }]}>
                  {totalGames === 0 ? 'Make your first booking to level up' : `${bookingsToNext} booking${bookingsToNext !== 1 ? 's' : ''} to next level`}
                </Text>
              </View>
              <Text style={[S.levelPct, { color: COLORS.kiwi }]}>{Math.round(progressToNext * 100)}%</Text>
            </View>
            {/* progress bar */}
            <View style={[S.progressTrack, { backgroundColor: COLORS.background }]}>
              <View style={[S.progressFill, { width: `${Math.round(progressToNext * 100)}%`, backgroundColor: COLORS.kiwi }]} />
            </View>
            {/* badges row */}
            <View style={S.achieveRow}>
              <View style={S.achieveItem}>
                <MaterialCommunityIcons name="medal-outline" size={15} color={COLORS.kiwi} />
                <Text style={[S.achieveText, { color: COLORS.textMuted }]}>{Math.max(0, level - 1)} Badges</Text>
              </View>
              <View style={[S.achieveDot, { backgroundColor: COLORS.border }]} />
              <View style={S.achieveItem}>
                <Ionicons name="location-outline" size={14} color={COLORS.kiwi} />
                <Text style={[S.achieveText, { color: COLORS.textMuted }]}>{uniqueVenues} Cities</Text>
              </View>
              <View style={[S.achieveDot, { backgroundColor: COLORS.border }]} />
              <View style={S.achieveItem}>
                <Ionicons name="flame-outline" size={14} color={COLORS.kiwi} />
                <Text style={[S.achieveText, { color: COLORS.textMuted }]}>{totalGames} Sessions</Text>
              </View>
            </View>
          </View>
        </View>

        {/* ── SETTINGS ───────────────────────────────── */}
        <View style={S.sectionPad}>
          <SectionLabel label="Account" COLORS={COLORS} />
          <View style={[S.group, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            <Row icon="person-outline" label="Personal Information" COLORS={COLORS} onPress={() => router.push('/customer/profile/view' as any)} />
            <Row icon="create-outline" label="Edit Profile" COLORS={COLORS} onPress={() => router.push('/customer/profile/edit' as any)} />
            <Row icon="wallet-outline" label="Payments & Payouts" COLORS={COLORS} onPress={() => router.push('/customer/profile/payment' as any)} />
            <Row icon="notifications-outline" label="Notifications" COLORS={COLORS} onPress={() => router.push('/customer/profile/notifications' as any)} />
            <Row icon="lock-closed-outline" label="Security & Privacy" COLORS={COLORS} onPress={() => router.push('/customer/profile/security' as any)} />
            <Row icon="location-outline" label="Saved Locations" COLORS={COLORS} onPress={() => router.push('/customer/profile/locations' as any)} isLast />
          </View>
        </View>

        {/* ── APPEARANCE ─────────────────────────────── */}
        <View style={S.sectionPad}>
          <SectionLabel label="Appearance" COLORS={COLORS} />
          <View style={[S.card, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            <View style={S.themeRow}>
              <View style={[S.themeIcon, { backgroundColor: COLORS.kiwi + '18' }]}>
                <Ionicons name="color-palette-outline" size={18} color={COLORS.kiwi} />
              </View>
              <Text style={[S.themeTitle, { color: COLORS.textMain }]}>App Theme</Text>
              <Text style={[S.themeVal, { color: COLORS.kiwi }]}>
                {theme === 'system' ? 'Auto' : theme.charAt(0).toUpperCase() + theme.slice(1)}
              </Text>
            </View>
            <View style={[S.seg, { backgroundColor: COLORS.background }]}>
              {(['light', 'dark', 'system'] as const).map(t => (
                <TouchableOpacity key={t} style={[S.segBtn, theme === t && { backgroundColor: COLORS.kiwi }]} onPress={() => setTheme(t)} activeOpacity={0.8}>
                  <MaterialCommunityIcons
                    name={t === 'light' ? 'weather-sunny' : t === 'dark' ? 'moon-waning-crescent' : 'brightness-6'}
                    size={14} color={theme === t ? '#000' : COLORS.textMuted}
                  />
                  <Text style={[S.segLabel, { color: theme === t ? '#000' : COLORS.textMuted }]}>
                    {t === 'system' ? 'Auto' : t.charAt(0).toUpperCase() + t.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>

        {/* ── SUPPORT & LEGAL ────────────────────────── */}
        <View style={S.sectionPad}>
          <SectionLabel label="Support & Legal" COLORS={COLORS} />
          <View style={[S.group, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}>
            <Row icon="help-circle-outline" label="Help Center" COLORS={COLORS} onPress={() => {}} />
            <Row icon="shield-checkmark-outline" label="Privacy Policy" COLORS={COLORS} onPress={() => {}} />
            <Row icon="document-text-outline" label="Terms of Service" COLORS={COLORS} onPress={() => {}} isLast />
          </View>
        </View>

        {/* ── LOG OUT ────────────────────────────────── */}
        <View style={{ paddingHorizontal: 20, marginBottom: 24 }}>
          <TouchableOpacity
            style={[S.logoutRow, { backgroundColor: COLORS.surface, borderColor: 'rgba(255,55,55,0.2)' }]}
            onPress={logout}
            activeOpacity={0.8}
          >
            <View style={[S.logoutRowIcon, { backgroundColor: 'rgba(255,55,55,0.08)' }]}>
              <Ionicons name="log-out-outline" size={20} color="#FF3737" />
            </View>
            <Text style={S.logoutText}>Log Out Account</Text>
            <Ionicons name="chevron-forward" size={16} color="#FF3737" style={{ opacity: 0.3 }} />
          </TouchableOpacity>
        </View>

        <View style={S.footer}>
          <Text style={[S.footerTop, { color: COLORS.textMuted }]}>Turfsy v1.0.0</Text>
          <Text style={[S.footerBot, { color: COLORS.textMuted }]}>Innovox Software Solutions</Text>
        </View>

      </ScrollView>

      {/* ── CUSTOM LOGOUT MODAL ────────────────────── */}
      <Modal visible={showLogoutModal} transparent animationType="fade" onRequestClose={() => setShowLogoutModal(false)}>
        <View style={S.modalOverlay}>
          <BlurView intensity={Platform.OS === 'ios' ? 30 : 100} tint="dark" style={StyleSheet.absoluteFill} />
          <Animated.View
            style={[S.logoutCard, { backgroundColor: COLORS.surface, borderColor: COLORS.border }]}
          >
            <View style={[S.logoutIconBox, { backgroundColor: 'rgba(255,55,55,0.12)' }]}>
              <Ionicons name="log-out" size={32} color="#FF3737" />
            </View>
            <Text style={[S.logoutModalTitle, { color: COLORS.textMain }]}>Log Out of Turfsy?</Text>
            <Text style={[S.logoutModalSub, { color: COLORS.textMuted }]}>
              You'll need to sign in again to book turfs and view your profile activity.
            </Text>

            <View style={S.modalActions}>
              <TouchableOpacity
                style={[S.modalBtn, { backgroundColor: COLORS.background, borderColor: COLORS.border, borderWidth: 1 }]}
                onPress={() => setShowLogoutModal(false)}
                activeOpacity={0.7}
              >
                <Text style={[S.modalBtnText, { color: COLORS.textMain }]}>Stay Signed In</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[S.modalBtnMain, { backgroundColor: '#FF3737' }]}
                onPress={confirmLogout}
                activeOpacity={0.8}
              >
                <Text style={S.modalBtnTextMain}>Yes, Log Out</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      </Modal>
    </View>
  );
}

/* ── Sub-components ─────────────────────────────────────────── */

const SectionLabel = React.memo(({ label, COLORS }: { label: string; COLORS: any }) => {
  return <Text style={[S.sLabel, { color: COLORS.textMuted }]}>{label}</Text>;
});

const StatBar = React.memo(({ label, value, fill, sub, barW, COLORS, isLast }: {
  label: string; value: string; fill: number; sub: string; barW: number; COLORS: any; isLast?: boolean;
}) => {
  const filledW = Math.max(4, Math.round(fill * barW));
  return (
    <View style={[S.statRow, !isLast && { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}>
      <Text style={[S.statLbl, { color: COLORS.textMuted }]}>{label}</Text>
      <View style={{ flex: 1 }}>
        <View style={[S.barTrack, { backgroundColor: COLORS.background }]}>
          <View style={[S.barFill, { width: filledW, backgroundColor: COLORS.kiwi }]} />
        </View>
        <Text style={[S.statSub, { color: COLORS.textMuted }]}>{sub}</Text>
      </View>
      <Text style={[S.statVal, { color: COLORS.textMain }]}>{value}</Text>
    </View>
  );
});

const Row = React.memo(({ icon, label, onPress, COLORS, badge, isLast }: {
  icon: any; label: string; onPress: () => void; COLORS: any; badge?: string; isLast?: boolean;
}) => {
  return (
    <TouchableOpacity
      style={[S.row, !isLast && { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}
      onPress={onPress} activeOpacity={0.7}
    >
      <View style={[S.rowIcon, { backgroundColor: COLORS.kiwi + '14' }]}>
        <Ionicons name={icon} size={18} color={COLORS.kiwi} />
      </View>
      <Text style={[S.rowLabel, { color: COLORS.textMain }]}>{label}</Text>
      {badge
        ? <View style={[S.rowBadge, { backgroundColor: COLORS.kiwi }]}><Text style={S.rowBadgeText}>{badge}</Text></View>
        : <Ionicons name="chevron-forward" size={16} color={COLORS.textMuted} style={{ opacity: 0.45 }} />
      }
    </TouchableOpacity>
  );
});

/* ── Styles ─────────────────────────────────────────────────── */

const S = StyleSheet.create({
  root: { flex: 1 },

  hero: { paddingHorizontal: 20, paddingBottom: 24 },
  heroBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  heroLabel: { fontSize: 11, fontWeight: '900', letterSpacing: 1.5 },
  iconBtn: { width: 36, height: 36, borderRadius: 12, borderWidth: 1, justifyContent: 'center', alignItems: 'center' },

  profileCard: {
    flexDirection: 'column',
    alignItems: 'center',
    borderRadius: 28,
    borderWidth: 1,
    padding: 24,
    marginTop: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.05,
    shadowRadius: 12,
    elevation: 3,
  },
  avatarSection: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    marginBottom: 16,
  },
  outerRing: {
    width: 114,
    height: 114,
    borderRadius: 57,
    borderWidth: 1,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
  },
  middleRing: {
    width: 98,
    height: 98,
    borderRadius: 49,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarContainer: {
    width: 86,
    height: 86,
    borderRadius: 43,
    overflow: 'hidden',
  },
  avatarImage: {
    width: 86,
    height: 86,
    borderRadius: 43,
  },
  cameraButton: {
    position: 'absolute',
    bottom: -2,
    right: 6,
    width: 30,
    height: 30,
    borderRadius: 15,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  detailsSection: {
    width: '100%',
    alignItems: 'center',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 4,
    width: '100%',
    paddingHorizontal: 12,
  },
  profileName: {
    fontSize: 22,
    fontWeight: '800',
    textAlign: 'center',
    lineHeight: 28,
  },
  profileUsername: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 16,
    textAlign: 'center',
  },
  editPencilBtn: {
    padding: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoContainer: {
    width: '100%',
    gap: 10,
    marginTop: 4,
  },
  infoPill: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 12,
    width: '100%',
  },
  infoPillLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  infoPillText: {
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 18,
  },
  copyBtn: {
    padding: 4,
  },

  sectionPad: { paddingHorizontal: 20, marginBottom: 20 },
  sLabel: { fontSize: 10, fontWeight: '900', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 10, marginLeft: 2 },

  card: { borderRadius: 20, borderWidth: 1, padding: 16 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  cardTitle: { flex: 1, fontSize: 14, fontWeight: '800' },
  chip: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  chipText: { fontSize: 10, fontWeight: '800' },

  statRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, gap: 10 },
  statLbl: { width: 62, fontSize: 11, fontWeight: '700' },
  barTrack: { height: 5, borderRadius: 3, marginBottom: 4, overflow: 'hidden' },
  barFill: { height: 5, borderRadius: 3 },
  statSub: { fontSize: 10, fontWeight: '500' },
  statVal: { width: 44, fontSize: 13, fontWeight: '800', textAlign: 'right' },

  levelHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  levelBadgeBox: { width: 36, height: 36, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  levelName: { fontSize: 14, fontWeight: '800', marginBottom: 2 },
  levelSub: { fontSize: 11 },
  levelPct: { fontSize: 18, fontWeight: '900' },
  progressTrack: { height: 8, borderRadius: 4, overflow: 'hidden', marginBottom: 12 },
  progressFill: { height: 8, borderRadius: 4 },
  achieveRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  achieveItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  achieveText: { fontSize: 11, fontWeight: '600' },
  achieveDot: { width: 4, height: 4, borderRadius: 2 },

  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  quickCell: { borderRadius: 18, borderWidth: 1, alignItems: 'center', justifyContent: 'center', gap: 8 },
  quickIcon: { justifyContent: 'center', alignItems: 'center' },
  quickLabel: { fontWeight: '700', textAlign: 'center' },

  group: { borderRadius: 20, borderWidth: 1, overflow: 'hidden' },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 13, gap: 12 },
  rowIcon: { width: 34, height: 34, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  rowLabel: { flex: 1, fontSize: 14, fontWeight: '600' },
  rowBadge: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 6 },
  rowBadgeText: { color: '#000', fontSize: 10, fontWeight: '800' },

  themeRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  themeIcon: { width: 34, height: 34, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  themeTitle: { flex: 1, fontSize: 14, fontWeight: '700' },
  themeVal: { fontSize: 10, fontWeight: '900', textTransform: 'uppercase' },
  seg: { flexDirection: 'row', borderRadius: 12, padding: 3, gap: 3 },
  segBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 9, borderRadius: 9, gap: 5 },
  segLabel: { fontSize: 12, fontWeight: '700' },

  logoutRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderRadius: 20,
    borderWidth: 1,
    gap: 12,
  },
  logoutRowIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoutText: {
    flex: 1,
    color: '#FF3737',
    fontSize: 15,
    fontWeight: '700',
  },

  footer: { alignItems: 'center', gap: 3, paddingBottom: 10 },
  footerTop: { fontSize: 11, fontWeight: '700' },
  footerBot: { fontSize: 10, opacity: 0.4 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', padding: 24 },
  logoutCard: { width: '100%', maxWidth: 340, borderRadius: 28, borderWidth: 1, padding: 24, alignItems: 'center' },
  logoutIconBox: { width: 64, height: 64, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  logoutModalTitle: { fontSize: 20, fontWeight: '800', marginBottom: 8, textAlign: 'center' },
  logoutModalSub: { fontSize: 14, fontWeight: '500', textAlign: 'center', lineHeight: 20, marginBottom: 24, paddingHorizontal: 10 },
  modalActions: { width: '100%', gap: 12 },
  modalBtn: { width: '100%', height: 54, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  modalBtnMain: { width: '100%', height: 54, borderRadius: 16, justifyContent: 'center', alignItems: 'center', shadowColor: '#FF3737', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 },
  modalBtnText: { fontSize: 15, fontWeight: '700' },
  modalBtnTextMain: { fontSize: 15, fontWeight: '800', color: '#FFF' },
});
