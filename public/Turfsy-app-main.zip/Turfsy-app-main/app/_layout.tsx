import { useCallback, useEffect, useState, useRef } from 'react';
import { Platform, View, Image, StyleSheet, useColorScheme, AppState } from 'react-native';
import { Stack, router, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import * as NavigationBar from 'expo-navigation-bar';
import { AppProvider, useApp } from '@/src/context/AppContext';
import { setupPushNotifications } from '@/src/services/notificationService';
import { AppLockService } from '@/src/services/appLockService';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import {
  useFonts,
  Inter_100Thin,
  Inter_200ExtraLight,
  Inter_300Light,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  Inter_800ExtraBold,
  Inter_900Black,
} from '@expo-google-fonts/inter';
import { applyGlobalFont } from '@/src/utils/applyGlobalFont';

// Apply the global font default props
applyGlobalFont();

SplashScreen.preventAutoHideAsync().catch(() => {
  /* ignore */
});

// Remove console logs in production
if (!__DEV__) {
  console.log = () => {};
  console.info = () => {};
  console.warn = () => {};
  console.error = () => {};
}

let isLockScreenActive = false;
export const setLockScreenActive = (val: boolean) => { isLockScreenActive = val; };

function NavigationContent() {
  const { isAuthLoaded, isInitialDataLoaded, isManualRefreshing, authToken, userInfo } = useApp();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const segments = useSegments();

  useEffect(() => {
    if (Platform.OS === 'android') {
      NavigationBar.setVisibilityAsync('hidden').catch(() => {});
    }
  }, []);

  useEffect(() => {
    if (isAuthLoaded && isInitialDataLoaded) {
      SplashScreen.hideAsync().catch(() => {});
    }
  }, [isAuthLoaded, isInitialDataLoaded]);

  // This effect runs once auth is resolved
  useEffect(() => {
    if (!isAuthLoaded) return;

    const segs = segments as string[];

    if (authToken) {
      // If we have a token but no userInfo yet, wait
      if (!userInfo) return;

      // Allow staying on app-lock setup screens
      const isAppLockPath = segs.includes('app-lock-prompt') || segs.includes('mpin-setup');
      if (isAppLockPath) return;

      // If we are currently on OTP screen, let the OTP screen handle its own navigation
      if (segs.includes('otp')) return;

      if (userInfo.isNewUser) {
        if (!segs.includes('profile-creation')) {
          router.replace('/auth/profile-creation/profile');
        }
      } else {
        // Already on the dashboard — do nothing
        const isCustomerPath = segs[0] === 'customer';
        if (isCustomerPath) return; // Allow staying on any customer sub-route
        router.replace('/customer/(tabs)/home');
      }
    } else {
      // No token — go to login
      const isAuthPath = segs.includes('auth');
      if (isAuthPath && !segs.includes('profile-creation')) return;
      router.replace('/auth/phone');
    }
  }, [isAuthLoaded, authToken, userInfo]);
  
  // Initialize Push Notifications when user is authenticated
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    
    if (authToken && isAuthLoaded) {
      setupPushNotifications().then(unsub => {
        unsubscribe = unsub;
      });
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [authToken, isAuthLoaded]);

  // App Lock Global Listener
  const appState = useRef(AppState.currentState);
  const hasRunColdStart = useRef(false);

  useEffect(() => {
    if (!authToken || !isAuthLoaded) return;

    // Run cold-start check ONLY ONCE
    const runColdStartCheck = async () => {
      if (hasRunColdStart.current) return;
      
      const settings = await AppLockService.getSettings();
      const isLocked = settings.enabled;
      
      if (isLocked) {
        const currentSegs = segments as string[];
        const isAllowedPath = currentSegs.includes('lock-screen') || currentSegs.includes('change-mpin') || currentSegs.includes('app-lock-prompt') || currentSegs.includes('mpin-setup');
        
        if (!isAllowedPath && currentSegs.length > 0 && !isLockScreenActive) {
          hasRunColdStart.current = true; // Mark as run
          isLockScreenActive = true;
          setTimeout(() => router.push('/auth/lock-screen'), 100);
        }
      } else {
        hasRunColdStart.current = true; // Mark as run
        isLockScreenActive = false;
        await AppLockService.updateLastActive();
      }
    };
    
    if (segments.length > 0) {
      runColdStartCheck();
    }

    const subscription = AppState.addEventListener('change', async nextAppState => {
      // App went to background
      if (appState.current.match(/active/) && nextAppState.match(/inactive|background/)) {
        await AppLockService.updateLastActive();
      }
      
      // App came to foreground
      if (appState.current.match(/inactive|background/) && nextAppState === 'active') {
        const isLocked = await AppLockService.isLockScreenRequired();
        if (isLocked) {
          const currentSegs = segments as string[];
          const isAllowedPath = currentSegs.includes('lock-screen') || currentSegs.includes('change-mpin') || currentSegs.includes('app-lock-prompt') || currentSegs.includes('mpin-setup');
          if (!isAllowedPath && !isLockScreenActive) {
            isLockScreenActive = true;
            router.push('/auth/lock-screen');
          }
        }
      }

      appState.current = nextAppState;
    });

    return () => {
      subscription.remove();
    };
  }, [authToken, isAuthLoaded, segments]);

  if (!isAuthLoaded) {
    return null;
  }

  return (
    <View style={{ flex: 1 }}>
      {authToken ? (
        // Authenticated Stack - Cannot go back to Auth screens from here
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="customer" />
          <Stack.Screen name="auth/profile-creation/profile" />
          <Stack.Screen name="auth/app-lock-prompt" />
          <Stack.Screen name="auth/mpin-setup" />
          <Stack.Screen name="auth/lock-screen" options={{ animation: 'fade' }} />
          {/* Prevent accidental navigation back to auth if it's still in route tree */}
          <Stack.Screen name="auth/phone" options={{ redirect: true } as any} />
          <Stack.Screen name="auth/otp" options={{ redirect: true } as any} />
        </Stack>
      ) : (
        // Unauthenticated Stack
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="auth/phone" />
          <Stack.Screen name="auth/otp" />
          {/* Prevent navigation to customer screens if not logged in */}
          <Stack.Screen name="customer" options={{ redirect: true } as any} />
        </Stack>
      )}

      {(!isInitialDataLoaded && !authToken) && (
        <View style={[styles.splashContainer, { backgroundColor: isDark ? '#000000' : '#FFFFFF' }]}>
          <Image 
            source={require('@/assets/images/logo.png')} 
            style={styles.splashLogo} 
            resizeMode="contain" 
          />
        </View>
      )}
    </View>
  );
}


const styles = StyleSheet.create({
  splashContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999,
  },
  splashLogo: {
    width: '60%',
    height: '60%',
  },
});

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    Inter: Inter_400Regular,
    'Inter-Thin': Inter_100Thin,
    'Inter-ExtraLight': Inter_200ExtraLight,
    'Inter-Light': Inter_300Light,
    'Inter-Medium': Inter_500Medium,
    'Inter-SemiBold': Inter_600SemiBold,
    'Inter-Bold': Inter_700Bold,
    'Inter-ExtraBold': Inter_800ExtraBold,
    'Inter-Black': Inter_900Black,
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AppProvider>
        <NavigationContent />
      </AppProvider>
    </GestureHandlerRootView>
  );
}

