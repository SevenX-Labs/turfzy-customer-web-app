import React, { useState, useRef, useEffect, useCallback } from 'react';
import { View, TextInput, TouchableOpacity, SafeAreaView, KeyboardAvoidingView, Platform, StatusBar, StyleSheet, Dimensions, Animated, Keyboard, TouchableWithoutFeedback, ActivityIndicator, Alert } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '@/src/context/AppContext';
import { AuthService } from '@/src/services/authService';

const { width, height } = Dimensions.get('window');

export default function OtpScreen() {
  const { COLORS, setRole, setAuthToken, setUserInfo, showStatusModal } = useApp();
  const styles = getStyles(COLORS);
  const { phone } = useLocalSearchParams<{ phone: string }>();

  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [focusedIndex, setFocusedIndex] = useState(0);
  const [timer, setTimer] = useState(60);
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const inputRefs = useRef<Array<TextInput | null>>([]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 20, friction: 7, useNativeDriver: true }),
    ]).start();

    const timerId = setTimeout(() => {
      inputRefs.current[0]?.focus();
    }, 500);

    const countdown = setInterval(() => {
      setTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', () => setKeyboardVisible(true));
    const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', () => setKeyboardVisible(false));

    return () => {
      clearTimeout(timerId);
      clearInterval(countdown);
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  const handleTextChange = (text: string) => {
    const cleanText = text.replace(/[^0-9]/g, '').slice(0, 6);
    const newOtp = ['', '', '', '', '', ''];
    for (let i = 0; i < cleanText.length; i++) {
      newOtp[i] = cleanText[i];
    }
    setOtp(newOtp);
    setFocusedIndex(cleanText.length); // Keep focus on the next empty box

    if (cleanText.length === 6) {
      Keyboard.dismiss();
      // Use the newly constructed OTP string directly for immediate verification
      handleVerify(cleanText); 
    }
  };

  const handleBoxPress = () => {
    inputRefs.current[0]?.focus();
  };

  // handleKeyPress is no longer needed with the single input pattern
  const handleKeyPress = () => {};

  const handleVerify = useCallback(async (codeOverride?: string) => {
    const otpString = codeOverride || otp.join('');
    if (otpString.length !== 6 || !phone || isLoading) return;

    setIsLoading(true);
    try {
      const response = await AuthService.verifyOtp(phone, otpString);
      if (response.success) {
        setAuthToken(response.accessToken);
        setUserInfo({
          ...response.auth,
          isNewUser: response.isNewUser
        });
        setRole(response.auth.role as any);

        if (response.isNewUser) {
          router.replace({ pathname: '/auth/app-lock-prompt', params: { next: '/auth/profile-creation/profile' } });
        } else {
          router.replace({ pathname: '/auth/app-lock-prompt', params: { next: '/customer/(tabs)/home' } });
        }
      } else {
        showStatusModal({
          type: 'error',
          title: 'Verification Failed',
          message: response.message || 'The code you entered is incorrect. Please try again.'
        });
      }
    } catch (error: any) {
      showStatusModal({
        type: 'error',
        title: 'Verification Error',
        message: 'There was a problem verifying your code. Please try again.'
      });
    } finally {
      setIsLoading(false);
    }
  }, [otp, phone, isLoading, setAuthToken, setUserInfo, setRole, showStatusModal]);

  const handleResend = async () => {
    if (!phone) return;
    try {
      const response = await AuthService.resendOtp(phone);
      if (response.success) {
        setTimer(60);
        setOtp(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      } else {
        showStatusModal({
          type: 'error',
          title: 'Resend Failed',
          message: response.message || 'We could not resend the code. Please try again later.'
        });
      }
    } catch (error: any) {
      showStatusModal({
        type: 'error',
        title: 'Error',
        message: 'Something went wrong. Please check your connection.'
      });
    }
  };

  const isComplete = otp.every(digit => digit !== '');

  useEffect(() => {
    if (isComplete && !isLoading) {
      // Small delay to let user see the last digit filled
      setTimeout(() => {
        handleVerify();
      }, 300);
    }
  }, [isComplete]);

  const formatTime = (seconds: number) => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={[styles.glow, { top: -100, left: -100, backgroundColor: COLORS.primary, opacity: 0.08 }]} />

      <SafeAreaView style={styles.safeArea}>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.inner}>
            <View style={styles.navHeader}>
              <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
              </TouchableOpacity>
              <Text style={styles.navTitle}>VERIFICATION</Text>
              <View style={{ width: 44 }} />
            </View>

            <Animated.View style={[styles.content, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
              <Text style={styles.mainHeading}>Check your{'\n'}<Text style={{color: COLORS.primary}}>Inbox.</Text></Text>
              <Text style={styles.subHeading}>We've sent a 6-digit code to +91 {phone}.</Text>

              <TouchableOpacity 
                activeOpacity={1} 
                onPress={handleBoxPress} 
                style={styles.otpWrapper}
              >
                <TextInput
                  ref={(ref) => { inputRefs.current[0] = ref; }}
                  keyboardType="numeric"
                  maxLength={6}
                  value={otp.filter(d => d !== '').join('')}
                  onChangeText={handleTextChange}
                  onFocus={() => setFocusedIndex(otp.filter(d => d !== '').length)}
                  onBlur={() => setFocusedIndex(-1)}
                  textContentType="oneTimeCode"
                  autoComplete="sms-otp"
                  style={styles.hiddenInput}
                  caretHidden
                />
                {otp.map((digit, index) => (
                  <View 
                    key={index} 
                    style={[
                      styles.inputBox,
                      focusedIndex === index ? styles.inputBoxFocused : 
                      digit !== '' ? styles.inputBoxActive : null
                    ]}
                  >
                    <Text style={styles.inputText}>{digit}</Text>
                    {focusedIndex === index && digit === '' && <View style={styles.cursor} />}
                  </View>
                ))}
              </TouchableOpacity>
            </Animated.View>

            {!isKeyboardVisible && (
              <View style={styles.actionArea}>
                <View style={styles.resendContainer}>
                  {timer > 0 ? (
                    <View style={styles.resendPill}>
                      <Text style={styles.resendPillText}>Resend in {formatTime(timer)}</Text>
                    </View>
                  ) : (
                    <TouchableOpacity onPress={handleResend} style={styles.resendPill}>
                      <Text style={styles.resendPillTextActive}>Resend OTP</Text>
                    </TouchableOpacity>
                  )}
                </View>

                <TouchableOpacity
                  onPress={() => handleVerify()}
                  activeOpacity={0.9}
                  style={[styles.primaryButton, { opacity: (isComplete && !isLoading) ? 1 : 0.4 }]}
                  disabled={!isComplete || isLoading}
                >
                  {isLoading ? (
                    <ActivityIndicator color="#000" />
                  ) : (
                    <>
                      <Text style={styles.buttonText}>Verify & Enter</Text>
                      <Ionicons name="arrow-forward" size={20} color="#000" />
                    </>
                  )}
                </TouchableOpacity>
              </View>
            )}
          </KeyboardAvoidingView>
        </TouchableWithoutFeedback>
      </SafeAreaView>
    </View>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  glow: { position: 'absolute', width: 300, height: 300, borderRadius: 150 },
  safeArea: { flex: 1 },
  inner: { flex: 1, paddingHorizontal: 24 },
  content: { flex: 1, justifyContent: 'center' },
  navHeader: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    marginTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 10, 
    marginBottom: 40 
  },
  backButton: { width: 48, height: 48, borderRadius: 16, backgroundColor: COLORS.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  navTitle: { fontSize: 12, fontWeight: '900', color: COLORS.textMuted, letterSpacing: 3 },
  mainHeading: { fontSize: 44, fontWeight: '800', color: COLORS.textMain, lineHeight: 48, letterSpacing: -1.5, marginBottom: 12 },
  subHeading: { fontSize: 16, color: COLORS.textMuted, lineHeight: 24, marginBottom: 40 },
  otpWrapper: { flexDirection: 'row', justifyContent: 'space-between', width: '100%' },
  inputBox: { width: (width - 84) / 6, height: 64, backgroundColor: COLORS.surface, borderRadius: 16, borderWidth: 1.5, borderColor: COLORS.border, justifyContent: 'center', alignItems: 'center' },
  inputBoxFocused: { borderColor: COLORS.primary, backgroundColor: COLORS.background },
  inputBoxActive: { borderColor: COLORS.textMuted },
  inputText: { fontSize: 24, fontWeight: '700', color: COLORS.textMain, textAlign: 'center' },
  hiddenInput: {
    position: 'absolute',
    width: 1,
    height: 1,
    opacity: 0,
  },
  cursor: {
    position: 'absolute',
    width: 2,
    height: 24,
    backgroundColor: COLORS.primary,
  },
  actionArea: { paddingBottom: Platform.OS === 'ios' ? 40 : 30, gap: 20 },
  resendContainer: { alignItems: 'center' },
  resendPill: { backgroundColor: '#1C1D1F', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 30 },
  resendPillText: { color: COLORS.textMuted, fontSize: 14, fontWeight: '600' },
  resendPillTextActive: { color: '#D1D5DB', fontSize: 14, fontWeight: '500' },
  primaryButton: { backgroundColor: COLORS.primary, height: 64, borderRadius: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  buttonText: { color: '#000', fontSize: 17, fontWeight: '800', marginRight: 10 },
});