import React, { useState } from 'react';
import { View, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar, TextInput, ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as Location from 'expo-location';
import { useApp } from '@/src/context/AppContext';
import { UserService } from '@/src/services/userService';
import { registerForPushNotificationsAsync } from '@/src/services/notificationService';
import LoadingOverlay from '@/src/components/LoadingOverlay';

export default function ProfileCompleteScreen() {
  const { COLORS, onboardingData, setUserProfile, userInfo, setUserInfo } = useApp();
  const styles = getStyles(COLORS);
  const [isFinalizing, setIsFinalizing] = useState(false);

  const [houseNumber, setHouseNumber] = useState('');
  const [societyName, setSocietyName] = useState('');
  const [landmark, setLandmark] = useState('');
  const [roadName, setRoadName] = useState('');
  const [city, setCity] = useState(onboardingData.city || '');
  const [state, setState] = useState(onboardingData.state || '');
  const [pincode, setPincode] = useState(onboardingData.pincode || '');

  const [lat, setLat] = useState<number | undefined>();
  const [lng, setLng] = useState<number | undefined>();
  const [detectingLocation, setDetectingLocation] = useState(false);

  const handleDetectLocation = async () => {
    try {
      setDetectingLocation(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        if (location && location.coords) {
          const { latitude, longitude } = location.coords;
          
          setLat(latitude);
          setLng(longitude);
          
          try {
            const geocode = await Location.reverseGeocodeAsync({ latitude, longitude });
            if (geocode && geocode.length > 0) {
              const place = geocode[0];
              
              if (place.name) setSocietyName(place.name);
              if (place.street) setRoadName(place.street);
              if (place.city || place.district) setCity(place.city || place.district || '');
              if (place.region) setState(place.region);
              if (place.postalCode) setPincode(place.postalCode);
            }
          } catch (geoErr) {
            console.log('Geocoding error:', geoErr);
          }
        }
      }
    } catch (err) {
      console.log('Location error:', err);
    } finally {
      setDetectingLocation(false);
    }
  };

  const handleFinish = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsFinalizing(true);
    try {
      const { avatarUri, ...profileData } = onboardingData;
      const pushToken = await registerForPushNotificationsAsync();
      
      // 1. Create Profile
      const response = await UserService.createProfile({
        ...profileData,
        expoPushToken: pushToken || undefined,
        currentLat: lat,
        currentLng: lng,
      } as any);

      if (response.success) {
        if (userInfo) {
          setUserInfo({ ...userInfo, isNewUser: false });
        }
        setUserProfile(response.data);
        
        // 2. Upload Avatar
        if (avatarUri) {
          const formData = new FormData();
          // @ts-ignore
          formData.append('file', {
            uri: avatarUri,
            name: 'avatar.jpg',
            type: 'image/jpeg',
          });
          await UserService.uploadAvatar(formData);
        }

        // 3. Update Address
        if (houseNumber || societyName || landmark || roadName || city || state || pincode) {
          await UserService.updateHomeAddress({
            houseNumber,
            societyName,
            landmark,
            roadName,
            city,
            state,
            pincode,
          });
        }

        // 4. Redirect
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace('/customer/(tabs)/home');
      }
    } catch (error) {
      console.error('Finalize profile failed:', error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsFinalizing(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
      
      {isFinalizing && <LoadingOverlay />}

      {/* Step Indicator */}
      <View style={styles.progressBarContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '100%' }]} />
        </View>
        <Text style={styles.stepText}>STEP 3 OF 3</Text>
      </View>
      
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.keyboardView}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} bounces={false}>
          
          {/* Header Texts */}
          <View style={styles.headerSection}>
            <Text style={styles.titleText}>Where are you located?</Text>
            <Text style={styles.subtitleText}>Add your address so we can find the best turfs near you.</Text>
          </View>

          <TouchableOpacity 
            style={styles.locationButton} 
            activeOpacity={0.8}
            onPress={handleDetectLocation} 
            disabled={detectingLocation}
          >
            {detectingLocation ? (
              <ActivityIndicator color={COLORS.primary} style={{ marginRight: 8 }} />
            ) : (
              <Ionicons name="location" size={20} color={COLORS.primary} style={{ marginRight: 8 }} />
            )}
            <Text style={styles.locationButtonText}>
              {detectingLocation ? 'Detecting Location...' : 'Use Current Location'}
            </Text>
          </TouchableOpacity>

          <View style={styles.formSection}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>House/Flat Number</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="e.g. Flat 402"
                  placeholderTextColor={COLORS.placeholder || '#AAAAAA'}
                  value={houseNumber}
                  onChangeText={setHouseNumber}
                  selectionColor={COLORS.primary}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Society Name</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="e.g. Green Valley Apartments"
                  placeholderTextColor={COLORS.placeholder || '#AAAAAA'}
                  value={societyName}
                  onChangeText={setSocietyName}
                  selectionColor={COLORS.primary}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Landmark (Optional)</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="e.g. Near Central Mall"
                  placeholderTextColor={COLORS.placeholder || '#AAAAAA'}
                  value={landmark}
                  onChangeText={setLandmark}
                  selectionColor={COLORS.primary}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Road Name (Optional)</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="e.g. MG Road"
                  placeholderTextColor={COLORS.placeholder || '#AAAAAA'}
                  value={roadName}
                  onChangeText={setRoadName}
                  selectionColor={COLORS.primary}
                />
              </View>
            </View>

            <View style={styles.rowInputs}>
              <View style={[styles.inputGroup, { flex: 1, marginRight: 10 }]}>
                <Text style={styles.label}>City</Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.inputTextInner}
                    placeholder="e.g. Mumbai"
                    placeholderTextColor={COLORS.placeholder || '#AAAAAA'}
                    value={city}
                    onChangeText={setCity}
                    selectionColor={COLORS.primary}
                  />
                </View>
              </View>
              <View style={[styles.inputGroup, { flex: 1, marginLeft: 10 }]}>
                <Text style={styles.label}>State</Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.inputTextInner}
                    placeholder="e.g. Maharashtra"
                    placeholderTextColor={COLORS.placeholder || '#AAAAAA'}
                    value={state}
                    onChangeText={setState}
                    selectionColor={COLORS.primary}
                  />
                </View>
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Pincode</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="e.g. 400001"
                  placeholderTextColor={COLORS.placeholder || '#AAAAAA'}
                  value={pincode}
                  onChangeText={setPincode}
                  selectionColor={COLORS.primary}
                  keyboardType="numeric"
                />
              </View>
            </View>

          </View>

          <View style={{ flex: 1, minHeight: 40 }} />

          {/* Large Footer Button */}
          <View>
            <TouchableOpacity 
              style={styles.actionButton}
              activeOpacity={0.85}
              onPress={handleFinish}
            >
              <Text style={styles.actionButtonText}>Complete Profile</Text>
              <Ionicons name="checkmark-circle" size={18} color={COLORS.btnDarkText} style={{ marginLeft: 8 }} />
            </TouchableOpacity>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  keyboardView: { flex: 1 },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 40,
  },
  // Progress Bar
  progressBarContainer: {
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 40,
    alignItems: 'center',
    marginBottom: 10,
  },
  progressBar: {
    width: '100%',
    height: 6,
    backgroundColor: COLORS.surfaceSoft || 'rgba(0,0,0,0.05)',
    borderRadius: 3,
    marginBottom: 12,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: COLORS.primary,
    borderRadius: 3,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
  },
  stepText: {
    color: COLORS.primary,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 2.5,
    opacity: 0.8,
  },
  headerSection: {
    alignItems: 'center',
    marginBottom: 35,
  },
  titleText: {
    color: COLORS.textMain,
    fontSize: 27,
    fontWeight: '800',
    letterSpacing: -0.5,
    marginBottom: 8,
  },
  subtitleText: {
    color: COLORS.textMuted,
    fontSize: 14.5,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 22,
  },
  locationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    backgroundColor: `${COLORS.primary}1A`,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: `${COLORS.primary}33`,
    marginBottom: 24,
  },
  locationButtonText: {
    color: COLORS.primary,
    fontSize: 15,
    fontWeight: '700',
  },
  formSection: { width: '100%' },
  inputGroup: { marginBottom: 20 },
  rowInputs: { flexDirection: 'row', justifyContent: 'space-between' },
  label: { color: COLORS.textMain, fontSize: 15, fontWeight: '700', marginBottom: 8 },
  inputWrapper: { backgroundColor: COLORS.surface, flexDirection: 'row', alignItems: 'center', height: 56, borderRadius: 16, paddingHorizontal: 16, borderWidth: 1, borderColor: COLORS.border || 'transparent' },
  inputTextInner: { flex: 1, color: COLORS.textMain, fontSize: 15, fontWeight: '500' },
  
  // Button
  actionButton: {
    width: '100%',
    backgroundColor: COLORS.primary,
    height: 60,
    borderRadius: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 15,
    elevation: 8,
  },
  actionButtonText: {
    color: COLORS.btnDarkText,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
});
