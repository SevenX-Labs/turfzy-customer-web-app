import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import Svg, { Path, Circle } from 'react-native-svg';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getPreciseUserLocation } from '@/src/utils/location';
import { useApp } from '@/src/context/AppContext';


const CheckCircleIcon = ({ COLORS }: any) => (
  <Svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={COLORS.primary} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <Path d="M22 4L12 14.01l-3-3" />
  </Svg>
);

const LocationPin = () => (
  <Svg width={24} height={28} viewBox="0 0 24 24" fill="#D83F3F" stroke="none">
    <Path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/>
  </Svg>
);

const TargetIcon = ({ COLORS }: any) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={COLORS.primary} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <Circle cx="12" cy="12" r="10" />
    <Circle cx="12" cy="12" r="4" />
  </Svg>
);

export default function ContactInformationScreen() {
  const { COLORS, updateOnboardingData, userInfo } = useApp();
  const styles = getStyles(COLORS);

  const [email, setEmail] = useState('');
  
  const [locationData, setLocationData] = useState<{
    street: string;
    area: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
    displayLine1: string;
    displayLine2: string;
    latLng: string;
  } | null>(null);
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);

  // Persistence: Load stored location on mount
  React.useEffect(() => {
    const loadStoredLocation = async () => {
      try {
        const stored = await AsyncStorage.getItem('@user_location_v2');
        if (stored) {
          const parsed = JSON.parse(stored);
          setLocationData(parsed.address);
          setCoords(parsed.coords);
        }
      } catch (e) {
        console.error('Failed to load stored location', e);
      }
    };
    loadStoredLocation();
  }, []);

  const saveLocationToStorage = async (address: typeof locationData, coordsVal: {lat: number, lng: number}) => {
    try {
      await AsyncStorage.setItem('@user_location_v2', JSON.stringify({
        address,
        coords: coordsVal,
        timestamp: Date.now(),
      }));
    } catch (e) {
      console.error('Failed to save location', e);
    }
  };

  const fetchLocation = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsFetchingLocation(true);
    try {
      const result = await getPreciseUserLocation();
      if (!result) return;

      const newCoords = { lat: result.coords.lat, lng: result.coords.lng };
      setCoords(newCoords);
      setLocationData(result.address);

      await saveLocationToStorage(result.address, newCoords);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error(error);
    } finally {
      setIsFetchingLocation(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
      
      {/* Step Indicator */}
      <View style={styles.progressBarContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '66.67%' }]} />
        </View>
        <Text style={styles.stepText}>STEP 2 OF 3</Text>
      </View>
      
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={styles.keyboardView}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContent} 
          showsVerticalScrollIndicator={false}
          bounces={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.title}>Contact Information</Text>
            <Text style={styles.subtitle}>Where should players find you?</Text>
          </View>

          {/* Form */}
          <View style={styles.formSection}>
            {/* Email Input */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email Address</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="Enter your email"
                  placeholderTextColor={COLORS.placeholder}
                  value={email}
                  onChangeText={setEmail}
                  selectionColor={COLORS.primary}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
            </View>

            {/* Contact Number */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Contact Number</Text>
              <View style={[styles.inputWrapper, { pointerEvents: 'none', backgroundColor: COLORS.surfaceSoft || 'rgba(255,255,255,0.03)' }]}>
                <Text style={styles.inputTextInner}>
                  {userInfo?.phone ? userInfo.phone : '+91'}
                </Text>
                <CheckCircleIcon COLORS={COLORS} />
              </View>
              <Text style={styles.verifiedBadgeText}>Verified phone number</Text>
            </View>

            {/* Current Location */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Current Location</Text>
              <View style={styles.locationCard}>

                {/* Location Pin Preview */}
                <View style={styles.mapPlaceholder}>
                  <View style={styles.fakeRiver} />
                  <View style={styles.fakeRoad} />
                  <View style={styles.markerContainer}>
                    <LocationPin />
                    <Text style={styles.markerLabel}>
                      {locationData?.city || 'Tap to detect'}
                    </Text>
                  </View>
                  <Text style={styles.mapSubText}>
                    {locationData?.latLng || 'GPS coordinates appear here'}
                  </Text>
                </View>

                {/* Structured Address Display */}
                {locationData ? (
                  <View style={styles.locationDetails}>
                    {!!locationData.street && (
                      <Text style={styles.locationStreet}>{locationData.street}</Text>
                    )}
                    <Text style={styles.locationArea}>
                      {[locationData.area, locationData.city].filter(Boolean).join(', ')}
                    </Text>
                    <View style={styles.locationRow}>
                      {!!locationData.pincode && (
                        <View style={styles.pincodeBadge}>
                          <Ionicons name="mail-outline" size={11} color={COLORS.primary} />
                          <Text style={styles.pincodeText}>{locationData.pincode}</Text>
                        </View>
                      )}
                      <Text style={styles.locationState}>
                        {[locationData.state, locationData.country].filter(Boolean).join(', ')}
                      </Text>
                    </View>
                    <Text style={styles.locationCoords}>{locationData.latLng}</Text>
                  </View>
                ) : (
                  <View style={styles.locationDetails}>
                    <Text style={styles.locationPlaceholder}>Tap below to auto-detect your location</Text>
                  </View>
                )}

                {/* Use Current Location Button */}
                <TouchableOpacity
                  style={[styles.useLocationBtn, isFetchingLocation && { opacity: 0.7 }]}
                  activeOpacity={0.8}
                  onPress={fetchLocation}
                  disabled={isFetchingLocation}
                >
                  <TargetIcon COLORS={COLORS} />
                  <Text style={styles.useLocationText}>
                    {isFetchingLocation ? 'Detecting location…' : 'Use Current Location'}
                  </Text>
                </TouchableOpacity>

              </View>
            </View>
          </View>

          {/* Spacer to push button down */}
          <View style={{ flex: 1, minHeight: 30 }} />

          {/* Next Button */}
          <View>
            <TouchableOpacity 
              style={styles.nextButton}
              activeOpacity={0.85}
              onPress={() => {
                if (!email) {
                  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
                  return;
                }
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

                // Pass individual fields — backend joins them into address string
                updateOnboardingData({
                  email,
                  currentLat: coords?.lat,
                  currentLng: coords?.lng,
                  city: locationData?.city || locationData?.area || '',
                  state: locationData?.state || '',
                  pincode: locationData?.pincode || '',
                });
                router.push('/auth/profile-creation/complete');
              }}
            >
              <Text style={styles.nextButtonText}>Continue</Text>
              <Ionicons name="arrow-forward" size={18} color={COLORS.btnDarkText} style={{ marginLeft: 8 }} />
            </TouchableOpacity>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 40,
  },
  // Progress Bar
  progressBarContainer: {
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 30,
    alignItems: 'center',
    marginBottom: 10,
  },
  progressBar: {
    width: '100%',
    height: 6,
    backgroundColor: COLORS.surfaceSoft || 'rgba(0,0,0,0.05)',
    borderRadius: 3,
    marginBottom: 12,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: COLORS.primary,
    borderRadius: 3,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
  },
  stepText: {
    color: COLORS.primary,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 2.5,
    opacity: 0.8,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    color: COLORS.textMain,
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.2,
    marginBottom: 6,
  },
  subtitle: {
    color: COLORS.textMuted,
    fontSize: 14,
    fontWeight: '500',
  },
  formSection: {
    width: '100%',
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    color: COLORS.textMain,
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
  },
  inputWrapper: {
    backgroundColor: COLORS.surface,
    flexDirection: 'row',
    alignItems: 'center',
    height: 58,
    borderRadius: 16,
    paddingHorizontal: 20,
  },
  inputTextInner: {
    flex: 1,
    color: COLORS.textMain,
    fontSize: 15,
    fontWeight: '500',
    height: '100%',
    paddingVertical: 0, // fixes Android centering
    textAlignVertical: 'center',
    includeFontPadding: false,
  },
  prefixText: {
    flex: 1,
    color: '#999', // slightly brighter than placeholder for visibility
    fontSize: 16,
    fontWeight: '500',
    textAlignVertical: 'center',
    includeFontPadding: false,
    height: '100%',
  },
  verifiedBadgeText: {
    color: COLORS.primary,
    fontSize: 13,
    fontWeight: '600',
    marginTop: 8,
    marginLeft: 6,
  },
  // Map Styling
  locationCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 24,
    padding: 12,
    paddingBottom: 20,
  },
  mapPlaceholder: {
    height: 160,
    backgroundColor: '#F0F2F5', // Grey map background
    borderRadius: 16,
    borderWidth: 2,
    borderColor: COLORS.primary,
    overflow: 'hidden',
    position: 'relative',
  },
  fakeRiver: {
    position: 'absolute',
    right: '20%',
    top: 0,
    bottom: 0,
    width: 65,
    backgroundColor: '#AEE2EA', // Water colour
  },
  fakeRoad: {
    position: 'absolute',
    left: '10%',
    top: 0,
    bottom: 0,
    width: 6,
    backgroundColor: '#FFFFFF',
    transform: [{ rotate: '15deg' }]
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    position: 'absolute',
    top: '30%',
    left: '20%',
  },
  markerLabel: {
    color: '#D83F3F',
    fontWeight: '800',
    marginLeft: 4,
    fontSize: 11,
    marginTop: -8, // optical alignment with pin
  },
  mapSubText: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    fontSize: 10,
    color: '#70747B',
    fontWeight: '800',
    lineHeight: 14,
  },
  locationDetails: {
    marginTop: 18,
    paddingHorizontal: 8,
    gap: 4,
  },
  locationStreet: {
    color: COLORS.textMain,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  locationArea: {
    color: COLORS.textMain,
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 6,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
    marginBottom: 4,
  },
  pincodeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: COLORS.primary + '22',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  pincodeText: {
    color: COLORS.primary,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  locationState: {
    color: COLORS.textMuted,
    fontSize: 13,
    fontWeight: '600',
  },
  locationCoords: {
    color: COLORS.textMuted,
    fontSize: 11,
    fontWeight: '500',
    letterSpacing: 0.3,
    marginTop: 2,
  },
  locationPlaceholder: {
    color: COLORS.textMuted,
    fontSize: 14,
    fontWeight: '500',
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: 8,
  },
  useLocationBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    backgroundColor: COLORS.surfaceLight || '#202224',
    paddingVertical: 14,
    borderRadius: 16,
    gap: 8,
  },
  useLocationText: {
    color: COLORS.primary,
    fontSize: 15,
    fontWeight: '700',
  },
  // Button
  nextButton: {
    width: '100%',
    backgroundColor: COLORS.primary,
    height: 60,
    borderRadius: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 15,
    elevation: 8,
  },
  nextButtonText: {
    color: COLORS.btnDarkText,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
});
