import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar, KeyboardAvoidingView, Platform, ScrollView, Modal, Image, Dimensions, ActivityIndicator } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import Svg, { Path, Circle, Line, Rect } from 'react-native-svg';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { Animated } from 'react-native';
import { useApp } from '@/src/context/AppContext';
import { UserService } from '@/src/services/userService';
const { width, height } = Dimensions.get('window');

const CameraWithPlusIcon = ({ COLORS }: any) => (
  <Svg width={42} height={42} viewBox="0 0 24 24" fill="none" stroke={COLORS.primary} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M22 10v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h3.5l1.5-2.5h6" />
    <Circle cx="12" cy="12" r="4" />
    <Line x1="19" y1="2" x2="19" y2="8" />
    <Line x1="16" y1="5" x2="22" y2="5" />
  </Svg>
);

const PencilIcon = ({ COLORS }: any) => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={COLORS.background} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
  </Svg>
);

const CalendarIcon = ({ COLORS }: any) => (
  <Svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke={COLORS.primary} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <Rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <Line x1="16" y1="2" x2="16" y2="6" />
    <Line x1="8" y1="2" x2="8" y2="6" />
    <Line x1="3" y1="10" x2="21" y2="10" />
  </Svg>
);

export default function ProfileCreationScreen() {
  const { COLORS, updateOnboardingData } = useApp();
  const styles = getStyles(COLORS);

  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('Male');
  const [preferredSport, setPreferredSport] = useState<'FOOTBALL' | 'CRICKET'>('FOOTBALL');
  const [avatar, setAvatar] = useState<string | null>(null);

  // Username Availability
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameStatus, setUsernameStatus] = useState<'available' | 'taken' | 'invalid' | null>(null);

  React.useEffect(() => {
    if (!username) {
      setUsernameStatus(null);
      return;
    }

    if (username.length < 4) {
      setUsernameStatus('invalid');
      return;
    }

    const timer = setTimeout(async () => {
      setCheckingUsername(true);
      try {
        const res = await UserService.checkUsername(username);
        setUsernameStatus(res.available ? 'available' : 'taken');
      } catch (err) {
        setUsernameStatus(null);
      } finally {
        setCheckingUsername(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [username]);

  // Modal States
  const [showImageSource, setShowImageSource] = useState(false);
  const [dateStep, setDateStep] = useState<'year' | 'month' | 'day' | null>(null);
  
  const [selYear, setSelYear] = useState<number>(new Date().getFullYear() - 18);
  const [selMonth, setSelMonth] = useState<number>(0);
  const [selDay, setSelDay] = useState<number>(1);

  const YEARS = Array.from({ length: 60 }, (_, i) => new Date().getFullYear() - i);
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const handleImagePick = async (useCamera: boolean) => {
    setShowImageSource(false);
    const permissionResult = useCamera 
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("Permission to access camera/gallery is required!");
      return;
    }

    const result = useCamera
      ? await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.5 })
      : await ImagePicker.launchImageLibraryAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.5 });

    if (!result.canceled) {
      setAvatar(result.assets[0].uri);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const finalizeDate = (day: number) => {
    setSelDay(day);
    const date = new Date(selYear, selMonth, day);
    const monthsShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    setDob(`${day} ${monthsShort[selMonth]} ${selYear}`);
    setDateStep(null);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleNext = () => {
    if (!name || !username || !dob) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    if (usernameStatus === 'taken' || usernameStatus === 'invalid') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    // Explicit mapping to match backend enums
    const mappedGender = 
      gender === 'Male' ? 'MALE' : 
      gender === 'Female' ? 'FEMALE' : 'OTHER';

    updateOnboardingData({
      name,
      username,
      dob: new Date(selYear, selMonth, selDay).toISOString().split('T')[0], // YYYY-MM-DD
      gender: mappedGender as any,
      preferredSport,
      avatarUri: avatar || undefined,
    });
    router.push('/auth/profile-creation/contact');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
      
      <View style={styles.progressBarContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '25%' }]} />
        </View>
        <Text style={styles.stepText}>STEP 1 OF 4</Text>
      </View>
      
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.keyboardView}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} bounces={false}>
          
          <View style={styles.header}>
            <Text style={styles.title}>Create Your Profile</Text>
            <Text style={styles.subtitle}>Let's get to know you better to find the best{'\n'}turfs nearby.</Text>
          </View>

          {/* Avatar Upload */}
          <View style={styles.avatarSection}>
            <TouchableOpacity 
              style={[styles.avatarCircle, avatar && { borderStyle: 'solid', borderColor: COLORS.primary }]} 
              activeOpacity={0.8}
              onPress={() => setShowImageSource(true)}
            >
              {avatar ? (
                <Image source={{ uri: avatar }} style={styles.avatarImage} />
              ) : (
                <View style={{ paddingLeft: 4, paddingBottom: 2 }}>
                  <CameraWithPlusIcon COLORS={COLORS} />
                </View>
              )}
              <View style={styles.avatarBadge}>
                <PencilIcon COLORS={COLORS} />
              </View>
            </TouchableOpacity>
            <Text style={styles.avatarLabel}>{avatar ? "Change Photo" : "Upload Profile Photo"}</Text>
          </View>

          <View style={styles.formSection}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Name</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="Enter your name"
                  placeholderTextColor={COLORS.placeholder}
                  value={name}
                  onChangeText={setName}
                  selectionColor={COLORS.primary}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <Text style={styles.label}>Username Handle</Text>
                {checkingUsername && <ActivityIndicator size="small" color={COLORS.primary} />}
                {!checkingUsername && usernameStatus === 'available' && <Text style={{ color: COLORS.primary, fontSize: 10, fontWeight: '900' }}>AVAILABLE</Text>}
                {!checkingUsername && usernameStatus === 'taken' && <Text style={{ color: '#FF453A', fontSize: 10, fontWeight: '900' }}>TAKEN</Text>}
                {!checkingUsername && usernameStatus === 'invalid' && <Text style={{ color: COLORS.textMuted, fontSize: 10, fontWeight: '900' }}>MIN 4 CHARS</Text>}
              </View>
              <View style={[styles.inputWrapper, usernameStatus === 'taken' && { borderColor: '#FF453A', borderWidth: 1 }]}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="unique_handle"
                  placeholderTextColor={COLORS.placeholder}
                  value={username}
                  onChangeText={(val) => setUsername(val.replace(/\s/g, '').toLowerCase())}
                  selectionColor={COLORS.primary}
                  autoCapitalize="none"
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Date of Birth</Text>
              <TouchableOpacity activeOpacity={0.8} onPress={() => setDateStep('year')}>
                <View style={[styles.inputWrapper, { pointerEvents: 'none' }]}>
                  <Text style={[styles.dateValueText, !dob && styles.dateValuePlaceholder]}>
                    {dob || 'Select your date of birth'}
                  </Text>
                  <CalendarIcon COLORS={COLORS} />
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Gender</Text>
              <View style={styles.genderRow}>
                {['Male', 'Female', 'Other'].map((g) => {
                  const isSelected = gender === g;
                  return (
                    <TouchableOpacity
                      key={g}
                      activeOpacity={0.8}
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                        setGender(g);
                      }}
                      style={[styles.genderBtn, isSelected ? styles.genderBtnSelected : styles.genderBtnDefault]}
                    >
                      <Text style={[styles.genderText, isSelected ? styles.genderTextSelected : styles.genderTextDefault]}>
                        {g}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Preferred Sport</Text>
              <View style={styles.genderRow}>
                {[
                  { id: 'FOOTBALL' as const, label: 'Football', icon: 'football' },
                  { id: 'CRICKET' as const, label: 'Cricket', icon: 'tennisball' },
                ].map((s) => {
                  const isSelected = preferredSport === s.id;
                  return (
                    <TouchableOpacity
                      key={s.id}
                      activeOpacity={0.8}
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                        setPreferredSport(s.id);
                      }}
                      style={[
                        styles.genderBtn,
                        isSelected ? styles.genderBtnSelected : styles.genderBtnDefault,
                        { flexDirection: 'row', gap: 8 }
                      ]}
                    >
                      <Ionicons 
                        name={s.icon as any} 
                        size={18} 
                        color={isSelected ? COLORS.primary : COLORS.textMuted} 
                      />
                      <Text style={[
                        styles.genderText,
                        isSelected ? styles.genderTextSelected : styles.genderTextDefault
                      ]}>
                        {s.label}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          </View>

          <View style={{ flex: 1, minHeight: 40 }} />

          <View>
            <TouchableOpacity style={styles.nextButton} activeOpacity={0.9} onPress={handleNext}>
              <Text style={styles.nextButtonText}>Continue</Text>
              <Ionicons name="arrow-forward" size={18} color={COLORS.btnDarkText} style={{ marginLeft: 8 }} />
            </TouchableOpacity>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>

      {/* Image Source Modal */}
      <Modal visible={showImageSource} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.sourcePPR}>
            <Text style={styles.sourceTitle}>Profile Photo</Text>
            <TouchableOpacity style={styles.sourceBtn} onPress={() => handleImagePick(true)}>
              <Ionicons name="camera" size={24} color={COLORS.primary} />
              <Text style={styles.sourceText}>Take a photo</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.sourceBtn} onPress={() => handleImagePick(false)}>
              <Ionicons name="images" size={24} color={COLORS.primary} />
              <Text style={styles.sourceText}>Apply from gallery</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.sourceCancel} onPress={() => setShowImageSource(false)}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Structured Date Picker Modal */}
      <Modal visible={dateStep !== null} transparent animationType="none">
        <View style={styles.modalOverlay}>
          <View style={styles.datePickerContainer}>
            <View style={styles.dateHeader}>
              <Text style={styles.dateStepTitle}>
                {dateStep === 'year' ? 'Select Year' : dateStep === 'month' ? 'Select Month' : 'Select Day'}
              </Text>
              <TouchableOpacity onPress={() => setDateStep(null)}>
                <Ionicons name="close" size={24} color={COLORS.textMain} />
              </TouchableOpacity>
            </View>

            <View style={styles.pickerContent}>
              {dateStep === 'year' && (
                <ScrollView showsVerticalScrollIndicator={false}>
                  <View style={styles.grid}>
                    {YEARS.map(y => (
                      <TouchableOpacity key={y} style={[styles.gridItem, selYear === y && styles.gridItemSelected]} onPress={() => { setSelYear(y); setDateStep('month'); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
                        <Text style={[styles.gridText, selYear === y && styles.gridTextSelected]}>{y}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>
              )}

              {dateStep === 'month' && (
                <ScrollView showsVerticalScrollIndicator={false}>
                  <View style={styles.grid}>
                    {MONTHS.map((m, i) => (
                      <TouchableOpacity key={m} style={[styles.gridItem, selMonth === i && styles.gridItemSelected]} onPress={() => { setSelMonth(i); setDateStep('day'); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
                        <Text style={[styles.gridText, selMonth === i && styles.gridTextSelected]}>{m.slice(0, 3)}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>
              )}

              {dateStep === 'day' && (
                <ScrollView showsVerticalScrollIndicator={false}>
                  <View style={styles.grid}>
                    {Array.from({ length: getDaysInMonth(selMonth, selYear) }, (_, i) => i + 1).map(d => (
                      <TouchableOpacity key={d} style={[styles.gridItem, selDay === d && styles.gridItemSelected]} onPress={() => finalizeDate(d)}>
                        <Text style={[styles.gridText, selDay === d && styles.gridTextSelected]}>{d}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>
              )}
            </View>

            {dateStep !== 'year' && (
              <TouchableOpacity style={styles.backStep} onPress={() => setDateStep(dateStep === 'day' ? 'month' : 'year')}>
                <Text style={styles.backStepText}>Back</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </Modal>

    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  keyboardView: { flex: 1 },
  scrollContent: { flexGrow: 1, paddingHorizontal: 24, paddingTop: 20, paddingBottom: 40 },
  progressBarContainer: { 
    paddingHorizontal: 24, 
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 30, 
    alignItems: 'center', 
    marginBottom: 10 
  },
  progressBar: { width: '100%', height: 6, backgroundColor: COLORS.surfaceSoft || 'rgba(0,0,0,0.05)', borderRadius: 3, marginBottom: 12, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: COLORS.primary, borderRadius: 3 },
  stepText: { color: COLORS.primary, fontSize: 11, fontWeight: '900', letterSpacing: 2.5, opacity: 0.8 },
  header: { alignItems: 'center', marginBottom: 45 },
  title: { color: COLORS.textMain, fontSize: 28, fontWeight: '800', marginBottom: 8 },
  subtitle: { color: COLORS.textMuted, fontSize: 14.5, textAlign: 'center', lineHeight: 22 },
  avatarSection: { alignItems: 'center', marginBottom: 35 },
  avatarCircle: { width: 120, height: 120, borderRadius: 60, borderWidth: 2.5, borderColor: COLORS.borderDark, borderStyle: 'dashed', justifyContent: 'center', alignItems: 'center', position: 'relative', marginBottom: 18, overflow: 'hidden' },
  avatarImage: { width: '100%', height: '100%' },
  avatarBadge: { position: 'absolute', bottom: 5, right: 5, width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center' },
  avatarLabel: { color: COLORS.textMain, fontSize: 17, fontWeight: '700' },
  formSection: { width: '100%' },
  inputGroup: { marginBottom: 24 },
  label: { color: COLORS.textMain, fontSize: 16, fontWeight: '700', marginBottom: 10 },
  inputWrapper: { backgroundColor: COLORS.surface, flexDirection: 'row', alignItems: 'center', height: 58, borderRadius: 16, paddingHorizontal: 20 },
  inputTextInner: { flex: 1, color: COLORS.textMain, fontSize: 15, fontWeight: '500' },
  dateValueText: { flex: 1, color: COLORS.textMain, fontSize: 15, fontWeight: '500' },
  dateValuePlaceholder: { color: COLORS.placeholder },
  genderRow: { flexDirection: 'row', gap: 12 },
  genderBtn: { flex: 1, height: 54, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  genderBtnSelected: { backgroundColor: 'transparent', borderWidth: 1.5, borderColor: COLORS.primary },
  genderBtnDefault: { backgroundColor: COLORS.surfaceLight },
  genderText: { fontSize: 15, fontWeight: '600' },
  genderTextSelected: { color: COLORS.primary },
  genderTextDefault: { color: COLORS.textMuted },
  nextButton: { width: '100%', backgroundColor: COLORS.primary, height: 60, borderRadius: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 20 },
  nextButtonText: { color: COLORS.btnDarkText, fontSize: 18, fontWeight: '900' },
  
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', alignItems: 'center', padding: 24 },
  sourcePPR: { backgroundColor: COLORS.surface, width: '100%', borderRadius: 24, padding: 24, alignItems: 'center' },
  sourceTitle: { fontSize: 20, fontWeight: '800', color: COLORS.textMain, marginBottom: 24 },
  sourceBtn: { flexDirection: 'row', alignItems: 'center', width: '100%', padding: 16, backgroundColor: COLORS.surfaceLight, borderRadius: 16, marginBottom: 12, gap: 16 },
  sourceText: { color: COLORS.textMain, fontSize: 16, fontWeight: '600' },
  sourceCancel: { marginTop: 8, padding: 12 },
  cancelText: { color: COLORS.textMuted, fontSize: 16, fontWeight: '700' },

  datePickerContainer: { backgroundColor: COLORS.surface, width: '100%', borderRadius: 32, padding: 24, maxHeight: height * 0.7 },
  dateHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  dateStepTitle: { color: COLORS.textMain, fontSize: 20, fontWeight: '900' },
  pickerContent: { height: 300 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  gridItem: { width: (width - 110) / 3, height: 50, backgroundColor: COLORS.surfaceLight, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  gridItemSelected: { backgroundColor: COLORS.primary },
  gridText: { color: COLORS.textMuted, fontSize: 14, fontWeight: '700' },
  gridTextSelected: { color: COLORS.background },
  backStep: { marginTop: 20, alignSelf: 'center', padding: 10 },
  backStepText: { color: COLORS.primary, fontWeight: '800', fontSize: 15 },
});
