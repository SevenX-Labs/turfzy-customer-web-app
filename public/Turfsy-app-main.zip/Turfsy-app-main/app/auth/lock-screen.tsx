import React, { useEffect, useState } from 'react';
import { View, StyleSheet, TouchableOpacity, SafeAreaView, Dimensions, ActivityIndicator, BackHandler, Alert } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { useApp } from '@/src/context/AppContext';
import { Ionicons } from '@expo/vector-icons';
import { AppLockService } from '@/src/services/appLockService';
import { setLockScreenActive } from '../_layout';

const { width } = Dimensions.get('window');

export default function LockScreen() {
  const { COLORS, showStatusModal } = useApp();
  const styles = getStyles(COLORS);

  const [mpin, setMpin] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [method, setMethod] = useState<'BIOMETRIC' | 'MPIN'>('MPIN');

  useEffect(() => {
    // Check preferred method on mount
    AppLockService.getSettings().then(settings => {
      if (settings.method === 'BIOMETRIC') {
        setMethod('BIOMETRIC');
        handleBiometric();
      }
    });

    const onBackPress = () => {
      Alert.alert(
        'Unauthorized',
        'You must enter your MPIN or use Biometrics to access the app.',
        [
          { text: 'Cancel (Exit)', onPress: () => BackHandler.exitApp(), style: 'cancel' },
          { text: 'Unlock', onPress: () => {} }
        ],
        { cancelable: false }
      );
      return true; // Prevent default behavior
    };

    const backHandler = BackHandler.addEventListener('hardwareBackPress', onBackPress);

    return () => backHandler.remove();
  }, []);

  const handleBiometric = async () => {
    const success = await AppLockService.authenticateBiometric();
    if (success.success) {
      unlockApp();
    } else {
      setMethod('MPIN');
    }
  };

  const handleKeyPress = (key: string) => {
    if (key === 'delete') {
      setMpin(prev => prev.slice(0, -1));
      return;
    }

    if (mpin.length < 4) {
      const newMpin = mpin + key;
      setMpin(newMpin);
      if (newMpin.length === 4) {
        verifyMpin(newMpin);
      }
    }
  };

  const verifyMpin = async (pin: string) => {
    setIsLoading(true);
    try {
      const response = await AppLockService.verifyMpin(pin);
      if (response.success) {
        unlockApp();
      } else {
        showStatusModal({ type: 'error', title: 'Invalid MPIN', message: 'The MPIN you entered is incorrect.' });
        setMpin('');
      }
    } catch (error) {
      showStatusModal({ type: 'error', title: 'Verification Failed', message: 'Could not verify MPIN.' });
      setMpin('');
    } finally {
      setIsLoading(false);
    }
  };

  const unlockApp = async () => {
    await AppLockService.updateLastActive();
    setLockScreenActive(false);
    if (router.canGoBack()) {
      router.back();
    } else {
      router.replace('/customer/(tabs)/home');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Ionicons name="lock-closed" size={60} color={COLORS.primary} style={{ marginBottom: 20 }} />
        <Text style={styles.title}>Welcome Back</Text>
        <Text style={styles.description}>Enter your MPIN to unlock Turfzy</Text>

        <View style={styles.dotsContainer}>
          {[0, 1, 2, 3].map((i) => (
            <View key={i} style={[styles.dot, mpin.length > i && styles.dotFilled]} />
          ))}
        </View>

        {isLoading && <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 20 }} />}
      </View>

      <View style={styles.actionRow}>
        <TouchableOpacity onPress={() => router.push('/auth/change-mpin' as any)}>
          <Text style={styles.forgotText}>Forgot MPIN?</Text>
        </TouchableOpacity>
        
        {method === 'BIOMETRIC' && (
          <TouchableOpacity onPress={handleBiometric}>
            <Ionicons name="finger-print" size={32} color={COLORS.primary} />
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.keypad}>
        {[
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
          ['', '0', 'delete'],
        ].map((row, rowIndex) => (
          <View key={rowIndex} style={styles.row}>
            {row.map((key) => (
              <TouchableOpacity
                key={key}
                style={styles.key}
                onPress={() => key && handleKeyPress(key)}
                disabled={!key || isLoading}
              >
                {key === 'delete' ? (
                  <Ionicons name="backspace-outline" size={28} color={COLORS.textMain} />
                ) : (
                  <Text style={styles.keyText}>{key}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { flex: 1, alignItems: 'center', paddingTop: 80, paddingHorizontal: 24 },
  title: { fontSize: 28, fontWeight: '800', color: COLORS.textMain, marginBottom: 8 },
  description: { fontSize: 16, color: COLORS.textMuted, marginBottom: 40, textAlign: 'center' },
  dotsContainer: { flexDirection: 'row', gap: 20, marginBottom: 20 },
  dot: { width: 16, height: 16, borderRadius: 8, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  dotFilled: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  actionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 40, marginBottom: 30 },
  forgotText: { color: COLORS.primary, fontSize: 16, fontWeight: '600' },
  keypad: { paddingHorizontal: 40, paddingBottom: 60, gap: 20 },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  key: { width: 70, height: 70, borderRadius: 35, justifyContent: 'center', alignItems: 'center' },
  keyText: { fontSize: 32, fontWeight: '600', color: COLORS.textMain },
});
