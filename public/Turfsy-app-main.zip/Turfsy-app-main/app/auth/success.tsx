import React, { useEffect, useRef } from 'react';
import { TouchableOpacity, StyleSheet, Dimensions, SafeAreaView, StatusBar, Animated } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import Svg, { Path, Defs, LinearGradient, Stop, G } from 'react-native-svg';
import { useApp } from '@/src/context/AppContext';

const { width } = Dimensions.get('window');


/**
 * Perfect Rounded Flower Badge
 * Features 12 extra-round petals using high-curvature quadratic beziers.
 */
function PerfectFlowerTick({ size = 130, COLORS }: { size?: number, COLORS: any }) {
  const cx = size / 2;
  const cy = size / 2;

  const numPetals = 12; 
  const outerR = size * 0.46; // Petal tips
  const innerR = size * 0.38; // Deepness of valleys (higher = rounder petals)

  // Generate points for the flower peaks and valleys
  const points = [];
  for (let i = 0; i < numPetals * 2; i++) {
    const angle = (Math.PI / numPetals) * i - Math.PI / 2;
    const r = i % 2 === 0 ? outerR : innerR;
    points.push({
      x: cx + r * Math.cos(angle),
      y: cy + r * Math.sin(angle),
    });
  }

  // Create the ultra-smooth path
  let d = `M ${(points[0].x + points[points.length - 1].x) / 2},${(points[0].y + points[points.length - 1].y) / 2} `;
  for (let i = 0; i < points.length; i++) {
    const curr = points[i];
    const next = points[(i + 1) % points.length];
    const midX = (curr.x + next.x) / 2;
    const midY = (curr.y + next.y) / 2;
    // Using the point as a control point creates that "bubbly" petal look
    d += `Q ${curr.x} ${curr.y} ${midX} ${midY} `;
  }
  d += 'Z';

  const s = size * 0.01;
  const checkPath = `M ${cx - s * 11} ${cy + s * 1.5} L ${cx - s * 2} ${cy + s * 8.5} L ${cx + s * 12} ${cy - s * 8}`;

  return (
    <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <Defs>
        <LinearGradient id="flowerGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <Stop offset="0%" stopColor="#ADFF4D" />
          <Stop offset="100%" stopColor="#7EE609" />
        </LinearGradient>
      </Defs>

      {/* Subtle outer glow/shadow */}
      <G opacity={0.3}>
        <Path d={d} fill={COLORS.primaryDark} transform={`translate(0, 3)`} />
      </G>

      {/* The Main Rounded Flower Shape */}
      <Path 
        d={d} 
        fill="url(#flowerGrad)" 
        stroke="#69C200" 
        strokeWidth={1.2} 
      />

      {/* The Dark Modern Tick */}
      <Path
        d={checkPath}
        fill="none"
        stroke={COLORS.btnDarkText || '#122602'}
        strokeWidth={size * 0.095}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  );
}

export default function SuccessScreen() {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);

  const cardOpacity = useRef(new Animated.Value(0)).current;
  const cardScale = useRef(new Animated.Value(0.9)).current;
  const badgeScale = useRef(new Animated.Value(0)).current;
  const badgeFloat = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(cardOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(cardScale, { toValue: 1, tension: 20, friction: 8, useNativeDriver: true }),
    ]).start();

    Animated.sequence([
      Animated.delay(200),
      Animated.spring(badgeScale, { toValue: 1, tension: 35, friction: 6, useNativeDriver: true }),
    ]).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(badgeFloat, { toValue: -6, duration: 1600, useNativeDriver: true }),
        Animated.timing(badgeFloat, { toValue: 0, duration: 1600, useNativeDriver: true }),
      ])
    ).start();

    const timer = setTimeout(() => router.replace('/auth/profile-creation/profile'), 3500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      <Animated.View style={[styles.card, { opacity: cardOpacity, transform: [{ scale: cardScale }] }]}>
        
        <TouchableOpacity 
          style={styles.closeBtn} 
          onPress={() => router.replace('/auth/profile-creation/profile')}
        >
          <Svg width={14} height={14} viewBox="0 0 14 14">
            <Path d="M1 1 L13 13 M13 1 L1 13" stroke={COLORS.closeIcon} strokeWidth={2.5} strokeLinecap="round" />
          </Svg>
        </TouchableOpacity>

        <Animated.View style={{ transform: [{ scale: badgeScale }, { translateY: badgeFloat }], marginBottom: 30 }}>
          <PerfectFlowerTick size={130} COLORS={COLORS} />
        </Animated.View>

        <Text style={styles.title}>Successful</Text>
        <Text style={styles.subtitle}>You have been successfully verified</Text>

        <TouchableOpacity 
          style={styles.btn} 
          activeOpacity={0.8} 
          onPress={() => router.replace('/auth/profile-creation/profile')}
        >
          <Text style={styles.btnText}>Continue</Text>
        </TouchableOpacity>

      </Animated.View>
    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: width * 0.88,
    backgroundColor: COLORS.surface,
    borderRadius: 32,
    paddingHorizontal: 24,
    paddingTop: 56,
    paddingBottom: 32,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 12,
  },
  closeBtn: {
    position: 'absolute',
    top: 20,
    right: 20,
    padding: 8,
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: COLORS.textMain,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: COLORS.textMuted,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 44,
  },
  btn: {
    width: '100%',
    backgroundColor: COLORS.primary,
    height: 58,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnText: {
    color: COLORS.btnDarkText || '#122602',
    fontSize: 17,
    fontWeight: '800',
  },
});