import React, { useState } from 'react';
import { View, StyleSheet, TouchableOpacity, SafeAreaView, Dimensions, ActivityIndicator } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { useApp } from '@/src/context/AppContext';
import { Ionicons } from '@expo/vector-icons';
import { AppLockService } from '@/src/services/appLockService';
import { AuthService } from '@/src/services/authService';
import { apiClient } from '@/src/api/apiClient';

const { width } = Dimensions.get('window');

export default function ChangeMpinScreen() {
  const { COLORS, showStatusModal, userInfo } = useApp();
  const styles = getStyles(COLORS);

  const [step, setStep] = useState<'OTP' | 'CREATE' | 'CONFIRM'>('OTP');
  const [otp, setOtp] = useState('');
  const [mpin, setMpin] = useState('');
  const [confirmMpin, setConfirmMpin] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendOtp = async () => {
    if (!userInfo?.phone) return;
    setIsLoading(true);
    try {
      await AuthService.resendOtp(userInfo.phone);
      showStatusModal({ type: 'success', title: 'OTP Sent', message: `Verification code sent to +91 ${userInfo.phone}` });
    } catch (e) {
      showStatusModal({ type: 'error', title: 'Error', message: 'Failed to send OTP' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = async (key: string) => {
    if (key === 'delete') {
      if (step === 'OTP') setOtp(prev => prev.slice(0, -1));
      if (step === 'CREATE') setMpin(prev => prev.slice(0, -1));
      if (step === 'CONFIRM') setConfirmMpin(prev => prev.slice(0, -1));
      return;
    }

    if (step === 'OTP' && otp.length < 6) {
      const newOtp = otp + key;
      setOtp(newOtp);
      if (newOtp.length === 6) {
        verifyOtp(newOtp);
      }
    } else if (step === 'CREATE' && mpin.length < 4) {
      const newMpin = mpin + key;
      setMpin(newMpin);
      if (newMpin.length === 4) {
        setTimeout(() => setStep('CONFIRM'), 300);
      }
    } else if (step === 'CONFIRM' && confirmMpin.length < 4) {
      const newConfirmMpin = confirmMpin + key;
      setConfirmMpin(newConfirmMpin);
      if (newConfirmMpin.length === 4) {
        handleSaveMpin(mpin, newConfirmMpin);
      }
    }
  };

  const verifyOtp = async (code: string) => {
    if (!userInfo?.phone) return;
    setIsLoading(true);
    try {
      const response = await AuthService.verifyOtp(userInfo.phone, code);
      if (response.success) {
        setStep('CREATE');
      } else {
        showStatusModal({ type: 'error', title: 'Invalid OTP', message: 'The OTP entered is incorrect.' });
        setOtp('');
      }
    } catch (e) {
      showStatusModal({ type: 'error', title: 'Error', message: 'Failed to verify OTP' });
      setOtp('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveMpin = async (finalMpin: string, finalConfirmMpin: string) => {
    if (finalMpin !== finalConfirmMpin) {
      showStatusModal({ type: 'error', title: 'Mismatch', message: 'MPINs do not match. Please try again.' });
      setMpin('');
      setConfirmMpin('');
      setStep('CREATE');
      return;
    }

    setIsLoading(true);
    try {
      // Because we verified the OTP, the reset window is open
      await apiClient.post('/api/v3/auth/reset-mpin', { newMpin: finalMpin, confirmMpin: finalConfirmMpin });
      
      await AppLockService.saveSettings({
        enabled: true,
        method: 'MPIN',
        timeout: 5 * 60 * 1000,
        lastActive: Date.now(),
      });

      showStatusModal({ type: 'success', title: 'Success', message: 'Your MPIN has been updated.' });
      router.back();
    } catch (error) {
      showStatusModal({ type: 'error', title: 'Error', message: 'Failed to reset MPIN.' });
      setMpin('');
      setConfirmMpin('');
      setStep('CREATE');
    } finally {
      setIsLoading(false);
    }
  };

  const currentDisplay = step === 'OTP' ? otp : (step === 'CREATE' ? mpin : confirmMpin);
  const maxLength = step === 'OTP' ? 6 : 4;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.title}>
          {step === 'OTP' ? 'Verify Identity' : (step === 'CREATE' ? 'New MPIN' : 'Confirm New MPIN')}
        </Text>
        <Text style={styles.description}>
          {step === 'OTP' ? 'Enter the 6-digit OTP sent to your phone' : 'Enter a new 4-digit MPIN'}
        </Text>

        <View style={styles.dotsContainer}>
          {Array.from({ length: maxLength }).map((_, i) => (
            <View key={i} style={[styles.dot, currentDisplay.length > i && styles.dotFilled]} />
          ))}
        </View>
        
        {step === 'OTP' && (
           <TouchableOpacity onPress={handleSendOtp} style={{ marginTop: 20 }}>
             <Text style={{ color: COLORS.kiwi, fontWeight: '700' }}>Send OTP</Text>
           </TouchableOpacity>
        )}

        {isLoading && <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 20 }} />}
      </View>

      <View style={styles.keypad}>
        {[
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
          ['', '0', 'delete'],
        ].map((row, rowIndex) => (
          <View key={rowIndex} style={styles.row}>
            {row.map((key) => (
              <TouchableOpacity
                key={key}
                style={styles.key}
                onPress={() => key && handleKeyPress(key)}
                disabled={!key || isLoading}
              >
                {key === 'delete' ? (
                  <Ionicons name="backspace-outline" size={28} color={COLORS.textMain} />
                ) : (
                  <Text style={styles.keyText}>{key}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { padding: 24, marginTop: 10 },
  backButton: { width: 48, height: 48, borderRadius: 16, backgroundColor: COLORS.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  content: { flex: 1, alignItems: 'center', paddingTop: 40, paddingHorizontal: 24 },
  title: { fontSize: 28, fontWeight: '800', color: COLORS.textMain, marginBottom: 12 },
  description: { fontSize: 16, color: COLORS.textMuted, marginBottom: 40, textAlign: 'center' },
  dotsContainer: { flexDirection: 'row', gap: 15, marginBottom: 20 },
  dot: { width: 16, height: 16, borderRadius: 8, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  dotFilled: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  keypad: { paddingHorizontal: 40, paddingBottom: 60, gap: 20 },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  key: { width: 70, height: 70, borderRadius: 35, justifyContent: 'center', alignItems: 'center' },
  keyText: { fontSize: 32, fontWeight: '600', color: COLORS.textMain },
});
