import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import Svg, { Path, Circle } from 'react-native-svg';
import { getPreciseUserLocation } from '@/src/utils/location';
import { useApp } from '@/src/context/AppContext';


const CheckCircleIcon = ({ COLORS }: any) => (
  <Svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={COLORS.primary} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <Path d="M22 4L12 14.01l-3-3" />
  </Svg>
);

const LocationPin = () => (
  <Svg width={24} height={28} viewBox="0 0 24 24" fill="#D83F3F" stroke="none">
    <Path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/>
  </Svg>
);

const TargetIcon = ({ COLORS }: any) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={COLORS.primary} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <Circle cx="12" cy="12" r="10" />
    <Circle cx="12" cy="12" r="4" />
  </Svg>
);

export default function ContactInformationScreen() {
  const { COLORS } = useApp();
  const styles = getStyles(COLORS);

  const [email, setEmail] = useState('');
  
  const [locationData, setLocationData] = useState<{
    street: string;
    area: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
    displayLine1: string;
    displayLine2: string;
    latLng: string;
  } | null>(null);
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);

  const fetchLocation = async () => {
    setIsFetchingLocation(true);
    try {
      const result = await getPreciseUserLocation();
      if (!result) return;

      setCoords({ lat: result.coords.lat, lng: result.coords.lng });
      setLocationData(result.address);
    } finally {
      setIsFetchingLocation(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
      
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={styles.keyboardView}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContent} 
          showsVerticalScrollIndicator={false}
          bounces={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.title}>Contact Information</Text>
          </View>

          {/* Form */}
          <View style={styles.formSection}>
            {/* Email Input */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email Address</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.inputTextInner}
                  placeholder="Enter your email"
                  placeholderTextColor={COLORS.placeholder}
                  value={email}
                  onChangeText={setEmail}
                  selectionColor={COLORS.primary}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
            </View>

            {/* Contact Number */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Contact Number</Text>
              <View style={[styles.inputWrapper, { pointerEvents: 'none' }]}>
                <Text style={styles.prefixText}>+91</Text>
                <CheckCircleIcon COLORS={COLORS} />
              </View>
              <Text style={styles.verifiedBadgeText}>Verified phone number</Text>
            </View>

            {/* Current Location */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Current Location</Text>
              <View style={styles.locationCard}>
                
                {/* Location Pin Preview */}
                <View style={styles.mapPlaceholder}>
                  <View style={styles.fakeRiver} />
                  <View style={styles.fakeRoad} />
                  <View style={styles.markerContainer}>
                    <LocationPin />
                    <Text style={styles.markerLabel}>
                      {locationData?.city || 'Tap to detect'}
                    </Text>
                  </View>
                  <Text style={styles.mapSubText}>
                    {locationData?.latLng || 'GPS coordinates appear here'}
                  </Text>
                </View>

                {/* Structured Address Display */}
                {locationData ? (
                  <View style={styles.locationDetails}>
                    {!!locationData.street && (
                      <Text style={styles.locationStreet}>{locationData.street}</Text>
                    )}
                    <Text style={styles.locationArea}>
                      {[locationData.area, locationData.city].filter(Boolean).join(', ')}
                    </Text>
                    <View style={styles.locationRow}>
                      {!!locationData.pincode && (
                        <View style={styles.pincodeBadge}>
                          <Text style={styles.pincodeText}>{locationData.pincode}</Text>
                        </View>
                      )}
                      <Text style={styles.locationState}>
                        {[locationData.state, locationData.country].filter(Boolean).join(', ')}
                      </Text>
                    </View>
                    <Text style={styles.locationCoords}>{locationData.latLng}</Text>
                  </View>
                ) : (
                  <View style={styles.locationDetails}>
                    <Text style={styles.locationPlaceholder}>Tap below to auto-detect your location</Text>
                  </View>
                )}

                {/* Use Current Location Button */}
                <TouchableOpacity 
                  style={[styles.useLocationBtn, isFetchingLocation && { opacity: 0.7 }]} 
                  activeOpacity={0.8}
                  onPress={fetchLocation}
                  disabled={isFetchingLocation}
                >
                  <TargetIcon COLORS={COLORS} />
                  <Text style={styles.useLocationText}>
                    {isFetchingLocation ? 'Fetching location...' : 'Use Current Location'}
                  </Text>
                </TouchableOpacity>

              </View>
            </View>
          </View>

          {/* Spacer to push button down */}
          <View style={{ flex: 1, minHeight: 30 }} />

          {/* Next Button */}
          <TouchableOpacity 
            style={styles.nextButton}
            activeOpacity={0.85}
            onPress={() => router.push('/customer/(tabs)/home')}
          >
            <Text style={styles.nextButtonText}>Next</Text>
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 45,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    color: '#FFF',
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  formSection: {
    width: '100%',
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
  },
  inputWrapper: {
    backgroundColor: COLORS.surface,
    flexDirection: 'row',
    alignItems: 'center',
    height: 58,
    borderRadius: 16,
    paddingHorizontal: 20,
  },
  inputTextInner: {
    flex: 1,
    color: '#FFF',
    fontSize: 15,
    fontWeight: '500',
    height: '100%',
    paddingVertical: 0, // fixes Android centering
    textAlignVertical: 'center',
    includeFontPadding: false,
  },
  prefixText: {
    flex: 1,
    color: '#999', // slightly brighter than placeholder for visibility
    fontSize: 16,
    fontWeight: '500',
    textAlignVertical: 'center',
    includeFontPadding: false,
    height: '100%',
  },
  verifiedBadgeText: {
    color: COLORS.primary,
    fontSize: 13,
    fontWeight: '600',
    marginTop: 8,
    marginLeft: 6,
  },
  // Map Styling
  locationCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 24,
    padding: 12,
    paddingBottom: 20,
  },
  mapPlaceholder: {
    height: 160,
    backgroundColor: '#F0F2F5', // Grey map background
    borderRadius: 16,
    borderWidth: 2,
    borderColor: COLORS.primary,
    overflow: 'hidden',
    position: 'relative',
  },
  fakeRiver: {
    position: 'absolute',
    right: '20%',
    top: 0,
    bottom: 0,
    width: 65,
    backgroundColor: '#AEE2EA', // Water colour
  },
  fakeRoad: {
    position: 'absolute',
    left: '10%',
    top: 0,
    bottom: 0,
    width: 6,
    backgroundColor: '#FFFFFF',
    transform: [{ rotate: '15deg' }]
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    position: 'absolute',
    top: '30%',
    left: '20%',
  },
  markerLabel: {
    color: '#D83F3F',
    fontWeight: '800',
    marginLeft: 4,
    fontSize: 11,
    marginTop: -8, // optical alignment with pin
  },
  mapSubText: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    fontSize: 10,
    color: '#70747B',
    fontWeight: '800',
    lineHeight: 14,
  },
  locationDetails: {
    marginTop: 18,
    paddingHorizontal: 8,
    gap: 4,
  },
  locationStreet: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  locationArea: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 6,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
    marginBottom: 4,
  },
  pincodeBadge: {
    backgroundColor: COLORS.primary + '33',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  pincodeText: {
    color: COLORS.primary,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  locationState: {
    color: '#5B5E63',
    fontSize: 13,
    fontWeight: '600',
  },
  locationCoords: {
    color: '#5B5E63',
    fontSize: 11,
    fontWeight: '500',
    letterSpacing: 0.3,
    marginTop: 2,
  },
  locationPlaceholder: {
    color: '#5B5E63',
    fontSize: 14,
    fontWeight: '500',
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: 8,
  },
  useLocationBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    backgroundColor: '#202224',
    paddingVertical: 14,
    borderRadius: 16,
    gap: 8,
  },
  useLocationText: {
    color: COLORS.primary,
    fontSize: 15,
    fontWeight: '700',
  },
  // Button
  nextButton: {
    width: '100%',
    backgroundColor: COLORS.primary,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  nextButtonText: {
    color: '#182E03',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
});
