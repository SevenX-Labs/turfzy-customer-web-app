import React, { useState, useEffect, useRef } from 'react';
import { View, TextInput, TouchableOpacity, SafeAreaView, KeyboardAvoidingView, Platform, StatusBar, StyleSheet, Dimensions, Animated, ScrollView, TouchableWithoutFeedback, Keyboard, ActivityIndicator, Alert } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '@/src/context/AppContext';
import { AuthService } from '@/src/services/authService';

const { width, height } = Dimensions.get('window');

export default function PhoneScreen() {
  const { COLORS, showStatusModal } = useApp();
  const styles = getStyles(COLORS);

  const [phoneNumber, setPhoneNumber] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const borderAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 20, friction: 7, useNativeDriver: true }),
    ]).start();

    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setKeyboardVisible(true)
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => setKeyboardVisible(false)
    );

    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, []);

  const handlePhoneChange = (text: string) => {
    const numericText = text.replace(/[^0-9]/g, '');
    setPhoneNumber(numericText);
    if (numericText.length === 10) {
      Keyboard.dismiss();
    }
  };

  const handleFocus = () => {
    setIsFocused(true);
    Animated.timing(borderAnim, { toValue: 1, duration: 300, useNativeDriver: false }).start();
  };

  const handleBlur = () => {
    setIsFocused(false);
    Animated.timing(borderAnim, { toValue: 0, duration: 300, useNativeDriver: false }).start();
  };

  const handleGetOtp = async () => {
    if (phoneNumber.length !== 10) return;
    
    setIsLoading(true);
    try {
      const response = await AuthService.login(phoneNumber);
      if (response.success) {
        router.push({
          pathname: '/auth/otp',
          params: { phone: phoneNumber }
        });
      } else {
        showStatusModal({
          type: 'error',
          title: 'Login Failed',
          message: response.message || 'We could not send a code to this number. Please check the number and try again.'
        });
      }
    } catch (error: any) {
      showStatusModal({
        type: 'error',
        title: 'Connection Error',
        message: 'Could not connect to the server. Please check your internet and try again.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const borderColor = borderAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [COLORS.border, COLORS.primary],
  });

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Background Ambient Glows */}
      <View style={[styles.glow, { top: -100, left: -100, backgroundColor: COLORS.primary, opacity: 0.08 }]} />
      <View style={[styles.glow, { bottom: height * 0.2, right: -150, backgroundColor: '#166534', opacity: 0.1 }]} />

      <SafeAreaView style={styles.safeArea}>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
            
            <ScrollView contentContainerStyle={styles.scrollContent} bounces={false} showsVerticalScrollIndicator={false}>
              
              <View style={styles.nav}>
                <View style={styles.brandIcon}>
                  <View style={styles.innerBrandIcon} />
                </View>
                <Text style={styles.navTitle}>TURFSY</Text>
              </View>

              <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>
                <Text style={styles.mainHeading}>Ready to{'\n'}<Text style={{color: COLORS.primary}}>Dominate?</Text></Text>
                <Text style={styles.subHeading}>
                  Enter your mobile number to access elite turfs and community matches.
                </Text>

                <View style={styles.inputSection}>
                  <Text style={styles.inputLabel}>MOBILE NUMBER</Text>
                  
                  <Animated.View style={[styles.modernInputBox, { borderColor: borderColor }]}>
                    <Text style={styles.countryCode}>+91</Text>
                    <View style={styles.divider} />
                    <TextInput
                      placeholder="000 000 0000"
                      placeholderTextColor="#444"
                      keyboardType="numeric"
                      maxLength={10}
                      value={phoneNumber}
                      onFocus={handleFocus}
                      onBlur={handleBlur}
                      onChangeText={handlePhoneChange}
                      style={styles.inputField}
                      selectionColor={COLORS.primary}
                    />
                    {phoneNumber.length === 10 && (
                      <Ionicons name="checkmark-circle" size={22} color={COLORS.primary} />
                    )}
                  </Animated.View>
                </View>
              </Animated.View>
            </ScrollView>

            {!isKeyboardVisible && (
              <View style={styles.actionArea}>
                <TouchableOpacity
                  activeOpacity={0.9}
                  onPress={handleGetOtp}
                  style={[styles.primaryButton, { opacity: (phoneNumber.length === 10 && !isLoading) ? 1 : 0.6 }]}
                  disabled={phoneNumber.length !== 10 || isLoading}
                >
                  {isLoading ? (
                    <ActivityIndicator color="#000" />
                  ) : (
                    <>
                      <Text style={styles.buttonText}>Get Verification Code</Text>
                      <Ionicons name="arrow-forward" size={20} color="#000" />
                    </>
                  )}
                </TouchableOpacity>

                <View style={styles.footer}>
                  <Text style={styles.footerText}>
                    Secured by Turfsy Shield. <Text style={styles.boldWhite}>Terms of Service</Text>
                  </Text>
                </View>
              </View>
            )}

          </KeyboardAvoidingView>
        </TouchableWithoutFeedback>
      </SafeAreaView>
    </View>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  safeArea: { flex: 1 },
  glow: { position: 'absolute', width: 300, height: 300, borderRadius: 150 },
  scrollContent: { 
    flexGrow: 1, 
    paddingHorizontal: 24, 
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 30 
  },
  nav: { flexDirection: 'row', alignItems: 'center', marginBottom: 50 },
  brandIcon: { width: 24, height: 24, backgroundColor: COLORS.primary, borderRadius: 6, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  innerBrandIcon: { width: 10, height: 10, backgroundColor: COLORS.background, borderRadius: 2 },
  navTitle: { fontSize: 12, fontWeight: '900', color: COLORS.textMain, letterSpacing: 3 },
  mainHeading: { fontSize: 44, fontWeight: '800', color: COLORS.textMain, lineHeight: 48, letterSpacing: -1.5, marginBottom: 12 },
  subHeading: { fontSize: 16, color: COLORS.textMuted, lineHeight: 24, marginBottom: 40, paddingRight: 40 },
  inputSection: { marginBottom: 20 },
  inputLabel: { fontSize: 11, fontWeight: '700', color: COLORS.textMuted, letterSpacing: 1, marginBottom: 12 },
  modernInputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    height: 68,
    borderRadius: 20,
    paddingHorizontal: 20,
    borderWidth: 1.5,
  },
  countryCode: { fontSize: 18, fontWeight: '700', color: COLORS.textMain, marginRight: 15 },
  divider: { width: 1, height: 24, backgroundColor: COLORS.border, marginRight: 15 },
  inputField: { flex: 1, color: COLORS.textMain, fontSize: 18, fontWeight: '600', letterSpacing: 2 },
  actionArea: { paddingHorizontal: 24, paddingBottom: Platform.OS === 'ios' ? 40 : 30 },
  primaryButton: {
    backgroundColor: COLORS.primary,
    height: 64,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  buttonText: { color: '#000', fontSize: 17, fontWeight: '800', marginRight: 8 },
  footer: { marginTop: 20, alignItems: 'center' },
  footerText: { color: COLORS.textMuted, fontSize: 12 },
  boldWhite: { color: COLORS.textMain, fontWeight: '600' },
});