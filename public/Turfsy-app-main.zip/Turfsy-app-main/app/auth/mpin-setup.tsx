import React, { useState } from 'react';
import { View, StyleSheet, TouchableOpacity, SafeAreaView, Dimensions, ActivityIndicator } from 'react-native';
import { AppText as Text } from '@/src/components/AppText';;
import { router, useLocalSearchParams } from 'expo-router';
import { useApp } from '@/src/context/AppContext';
import { Ionicons } from '@expo/vector-icons';
import { AppLockService } from '@/src/services/appLockService';

const { width } = Dimensions.get('window');

export default function MpinSetupScreen() {
  const { COLORS, showStatusModal } = useApp();
  const styles = getStyles(COLORS);
  const { next } = useLocalSearchParams<{ next: string }>();

  const [step, setStep] = useState<'CREATE' | 'CONFIRM' | 'BIOMETRIC'>('CREATE');
  const [mpin, setMpin] = useState('');
  const [confirmMpin, setConfirmMpin] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleKeyPress = (key: string) => {
    if (key === 'delete') {
      if (step === 'CREATE') setMpin(prev => prev.slice(0, -1));
      if (step === 'CONFIRM') setConfirmMpin(prev => prev.slice(0, -1));
      return;
    }

    if (step === 'CREATE' && mpin.length < 4) {
      const newMpin = mpin + key;
      setMpin(newMpin);
      if (newMpin.length === 4) {
        setTimeout(() => setStep('CONFIRM'), 300);
      }
    } else if (step === 'CONFIRM' && confirmMpin.length < 4) {
      const newConfirmMpin = confirmMpin + key;
      setConfirmMpin(newConfirmMpin);
      if (newConfirmMpin.length === 4) {
        handleSaveMpin(mpin, newConfirmMpin);
      }
    }
  };

  const handleSaveMpin = async (finalMpin: string, finalConfirmMpin: string) => {
    if (finalMpin !== finalConfirmMpin) {
      showStatusModal({ type: 'error', title: 'Mismatch', message: 'MPINs do not match. Please try again.' });
      setMpin('');
      setConfirmMpin('');
      setStep('CREATE');
      return;
    }

    setIsLoading(true);
    try {
      // Call backend
      const response = await AppLockService.createMpin(finalMpin, finalConfirmMpin);
      
      // Save settings locally
      await AppLockService.saveSettings({
        enabled: true,
        method: 'MPIN',
        timeout: 5 * 60 * 1000, // 5 minutes
        lastActive: Date.now(),
      });

      // Check if biometric is supported
      const isBiometricSupported = await AppLockService.isBiometricSupported();
      if (isBiometricSupported) {
        setStep('BIOMETRIC');
      } else {
        finishSetup();
      }
    } catch (error) {
      showStatusModal({ type: 'error', title: 'Error', message: 'Failed to create MPIN.' });
      setMpin('');
      setConfirmMpin('');
      setStep('CREATE');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEnableBiometric = async () => {
    const success = await AppLockService.authenticateBiometric();
    if (success.success) {
      await AppLockService.saveSettings({
        enabled: true,
        method: 'BIOMETRIC',
        timeout: 5 * 60 * 1000, // 5 minutes
        lastActive: Date.now(),
      });
      finishSetup();
    }
  };

  const finishSetup = () => {
    if (next) {
      router.replace(next as any);
    } else {
      router.replace('/customer/(tabs)/home');
    }
  };

  const currentDisplay = step === 'CREATE' ? mpin : confirmMpin;

  if (step === 'BIOMETRIC') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.content}>
          <Ionicons name="finger-print" size={100} color={COLORS.primary} style={{ marginBottom: 40 }} />
          <Text style={styles.title}>Enable Biometrics</Text>
          <Text style={styles.description}>Use Fingerprint or Face ID for faster access to Turfzy.</Text>
          
          <View style={styles.buttonContainer}>
            <TouchableOpacity style={styles.primaryButton} onPress={handleEnableBiometric}>
              <Text style={styles.primaryButtonText}>Enable</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.secondaryButton} onPress={finishSetup}>
              <Text style={styles.secondaryButtonText}>Skip</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textMain} />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.title}>{step === 'CREATE' ? 'Create MPIN' : 'Confirm MPIN'}</Text>
        <Text style={styles.description}>
          {step === 'CREATE' ? 'Enter a 4-digit MPIN' : 'Re-enter your 4-digit MPIN'}
        </Text>

        <View style={styles.dotsContainer}>
          {[0, 1, 2, 3].map((i) => (
            <View key={i} style={[styles.dot, currentDisplay.length > i && styles.dotFilled]} />
          ))}
        </View>
        
        {isLoading && <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 20 }} />}
      </View>

      <View style={styles.keypad}>
        {[
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
          ['', '0', 'delete'],
        ].map((row, rowIndex) => (
          <View key={rowIndex} style={styles.row}>
            {row.map((key) => (
              <TouchableOpacity
                key={key}
                style={styles.key}
                onPress={() => key && handleKeyPress(key)}
                disabled={!key || isLoading}
              >
                {key === 'delete' ? (
                  <Ionicons name="backspace-outline" size={28} color={COLORS.textMain} />
                ) : (
                  <Text style={styles.keyText}>{key}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
}

const getStyles = (COLORS: any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { padding: 24, marginTop: 10 },
  backButton: { width: 48, height: 48, borderRadius: 16, backgroundColor: COLORS.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  content: { flex: 1, alignItems: 'center', paddingTop: 40, paddingHorizontal: 24 },
  title: { fontSize: 28, fontWeight: '800', color: COLORS.textMain, marginBottom: 12 },
  description: { fontSize: 16, color: COLORS.textMuted, marginBottom: 40, textAlign: 'center' },
  dotsContainer: { flexDirection: 'row', gap: 20, marginBottom: 40 },
  dot: { width: 16, height: 16, borderRadius: 8, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  dotFilled: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  keypad: { paddingHorizontal: 40, paddingBottom: 60, gap: 20 },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  key: { width: 70, height: 70, borderRadius: 35, justifyContent: 'center', alignItems: 'center' },
  keyText: { fontSize: 32, fontWeight: '600', color: COLORS.textMain },
  buttonContainer: { width: '100%', gap: 16, marginTop: 40 },
  primaryButton: { backgroundColor: COLORS.primary, height: 60, borderRadius: 16, justifyContent: 'center', alignItems: 'center', width: '100%' },
  primaryButtonText: { color: '#000', fontSize: 17, fontWeight: '700' },
  secondaryButton: { height: 60, borderRadius: 16, justifyContent: 'center', alignItems: 'center', width: '100%', backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  secondaryButtonText: { color: COLORS.textMain, fontSize: 17, fontWeight: '600' },
});
