const { Text } = require('react-native');
console.log("Text typeof:", typeof Text);
console.log("Text.render typeof:", typeof Text.render);
