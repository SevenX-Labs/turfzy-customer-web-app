const fs = require('fs');
const path = require('path');

const targetFiles = [
  "app/customer/(tabs)/map/index.tsx",
  "app/auth/profile-creation/profile.tsx",
  "app/auth/profile-creation/contact.tsx",
  "app/auth/profile-creation/complete.tsx",
  "app/auth/otp.tsx",
  "app/auth/success.tsx",
  "app/auth/phone.tsx",
  "app/auth/contact.tsx",
  "app/customer/(tabs)/_layout.tsx",
  "app/customer/(tabs)/home/index.tsx",
  "app/customer/(tabs)/leaderboard/index.tsx",
  "app/customer/(tabs)/explore/index.tsx",
  "app/customer/(tabs)/notifications/index.tsx",
  "app/customer/(tabs)/bookings/index.tsx",
  "app/customer/booking/confirm.tsx",
  "app/customer/(tabs)/liked/index.tsx",
  "app/customer/booking/payment.tsx",
  "app/customer/booking/book.tsx",
  "app/customer/booking/detail.tsx"
];

const processFile = (relativeFilePath) => {
  const filePath = path.join(__dirname, relativeFilePath);
  let content = fs.readFileSync(filePath, 'utf8');
  
  if (!content.includes('const COLORS = {') && !content.includes('const COLORS=')) {
    return;
  }

  // 1. Remove the static COLORS definition completely
  content = content.replace(/const\s+COLORS\s*=\s*\{[^}]+\};\n?/g, '');
  
  // Clean up any empty object artifact
  content = content.replace(/const\s+COLORS\s*=\s*\{\s*\};\n?/g, '');

  let depthCount = relativeFilePath.split('/').length - 1;
  let relativePath = Array(depthCount).fill('..').join('/');
  let importPath = `${relativePath}/context/AppContext`;
  if (depthCount === 1) importPath = './context/AppContext';

  // 2. Add useApp import if not exists
  if (!content.includes('useApp')) {
    const importStatement = `import { useApp } from '${importPath}';\n`;
    // Insert after standard imports
    const lastImportIndex = content.lastIndexOf("import ");
    if (lastImportIndex !== -1) {
      const endOfLastImport = content.indexOf('\n', lastImportIndex) + 1;
      content = content.slice(0, endOfLastImport) + importStatement + content.slice(endOfLastImport);
    } else {
      content = importStatement + content;
    }
  }

  // 3. Transform StyleSheet.create to getStyles function
  if (content.includes('const styles = StyleSheet.create')) {
    content = content.replace(/const\s+styles\s*=\s*StyleSheet\.create/g, 'const getStyles = (COLORS: any) => StyleSheet.create');
  }

  // 4. Inject `const { COLORS } = useApp(); const styles = getStyles(COLORS);` inside default export component
  const defaultExportRegex = /(export\s+default\s+function\s+[A-Za-z0-9_]+\s*\([^)]*\)\s*\{|const\s+[A-Za-z0-9_]+\s*=\s*\([^)]*\)\s*=>\s*\{)/g;
  
  // Only inject once per file on the first match
  const match = defaultExportRegex.exec(content);
  if (match) {
    const injectStr = `\n  const { COLORS } = useApp();\n  const styles = getStyles(COLORS);\n`;
    const injectIndex = match.index + match[0].length;
    content = content.slice(0, injectIndex) + injectStr + content.slice(injectIndex);
  } else {
    console.log(`No default export found in ${relativeFilePath}`);
  }

  fs.writeFileSync(filePath, content);
  console.log(`Processed ${relativeFilePath}`);
};

targetFiles.forEach(f => {
  try {
      processFile(f);
  } catch(e) {
      console.error("Error processing " + f, e);
  }
});
